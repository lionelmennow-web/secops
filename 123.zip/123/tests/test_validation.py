"""The validation harness's own contract.

Two promises matter here: the registry has to speak for every class the threat
vocabulary declares, and the lab gate has to refuse anything that is not a lab -
because the scenarios append attacker log lines and plant decoys.
"""

from __future__ import annotations

import os
import tempfile
import unittest

from secops import signals
from secops.validation.node import LabError, Subjects, assert_lab, is_public
from secops.validation.registry import (
    DETECTOR,
    E2E,
    SKIP,
    UNCOVERED,
    Expect,
    Result,
    Run,
    Scenario,
    Score,
    build_registry,
    gaps,
    verdict_for,
)
from secops.validation.report import as_document, failure_count, render

UNPROVEN = "exploit_attempt"


class StubNode:
    """Whatever `assert_lab` reads, and nothing else."""

    def __init__(self, name: str, root: str, *, mode="monitor", backend="none", dry_run=True,
                 logs=None) -> None:
        self.name = name
        self.state_dir = os.path.join(root, name)
        self.socket = os.path.join(self.state_dir, "agent.sock")
        self.auth_logs = logs if logs is not None else [os.path.join(root, f"{name}-auth.log")]
        self._status = {"mode": mode, "firewall": {"backend": backend, "dry_run": dry_run},
                        "control_socket": self.socket}
        os.makedirs(self.state_dir, exist_ok=True)
        open(self.socket, "wb").close()

    def status(self) -> dict:
        return self._status


class TestRegistryCoverage(unittest.TestCase):
    def setUp(self) -> None:
        self.registry = build_registry()

    def test_every_declared_attack_has_an_entry(self) -> None:
        self.assertEqual(set(signals.ATTACKS), {scenario.attack for scenario in self.registry})

    def test_the_only_gap_is_the_one_the_registry_admits(self) -> None:
        self.assertEqual(gaps(self.registry), [UNPROVEN])

    def test_a_gap_explains_itself(self) -> None:
        missing = next(scenario for scenario in self.registry if scenario.attack == UNPROVEN)
        self.assertEqual(missing.level, SKIP)
        self.assertTrue(missing.why, "an uncovered class must say why")

    def test_every_scenario_asks_for_something_visible(self) -> None:
        for scenario in self.registry:
            if scenario.missing():
                continue
            self.assertTrue(scenario.expects, scenario.name)
            for expect in scenario.expects:
                self.assertIn(expect.attack, signals.ATTACKS)
            self.assertGreater(scenario.deadline, 0.0)

    def test_levels_are_only_e2e_detector_or_skip(self) -> None:
        self.assertEqual({scenario.level for scenario in self.registry} - {E2E, DETECTOR, SKIP}, set())

    def test_subjects_never_repeat_within_a_run(self) -> None:
        subjects = Subjects()
        taken = [subjects.take(f"scenario:{index}") for index in range(20)]
        self.assertEqual(len(set(taken)), 20)
        self.assertEqual(subjects.take("scenario:0"), taken[0])
        self.assertTrue(all(address.startswith("203.0.113.") for address in taken))
        # TEST-NET-3 is what a subject is drawn from, and this Python reports it as
        # private - which is precisely why a synthetic c2 address cannot be tested
        # end to end: the outbound watcher filters private peers out of the table.
        self.assertFalse(any(is_public(address) for address in taken))
        with self.assertRaises(LabError):
            for index in range(200):
                subjects.take(f"more:{index}")

    def test_a_live_address_claimed_by_hand_is_released_too(self) -> None:
        # The known-bad c2 scenario blocks an address this host really talks to.
        # That address comes from the connection table, not the documentation pool,
        # so the only thing putting it back is Subjects.note: without it the run
        # would leave a refusal standing on a third party after finishing.
        subjects = Subjects()
        subjects.take("scenario:0")
        subjects.note("93.184.216.34")
        subjects.note("93.184.216.34")
        self.assertIn("93.184.216.34", subjects.used())
        self.assertEqual(subjects.used().count("93.184.216.34"), 1)


class TestScoring(unittest.TestCase):
    def test_nothing_detected_never_passes(self) -> None:
        scenario = Scenario(attack="policy", name="x", level=E2E, run=None,
                            expects=(Expect(attack="policy", blocks=1),))
        self.assertEqual(verdict_for(scenario, Score(), ""), "fail")

    def test_a_missing_block_is_only_partial(self) -> None:
        scenario = Scenario(attack="ssh_bruteforce", name="x", level=E2E, run=None,
                            expects=(Expect(attack="ssh_bruteforce", blocks=1, peers=1),))
        self.assertEqual(verdict_for(scenario, Score(detected=1), ""), "partial")
        self.assertEqual(verdict_for(scenario, Score(detected=1, blocked=1), ""), "partial")
        self.assertEqual(verdict_for(scenario, Score(detected=1, blocked=1, gossiped=1), ""), "pass")

    def test_a_note_about_the_run_keeps_it_from_claiming_a_pass(self) -> None:
        scenario = Scenario(attack="policy", name="x", level=E2E, run=None,
                            expects=(Expect(attack="policy"),))
        self.assertEqual(verdict_for(scenario, Score(detected=1), "node said no"), "partial")


class TestLabGate(unittest.TestCase):
    def test_a_monitor_node_inside_the_root_is_accepted(self) -> None:
        with tempfile.TemporaryDirectory() as root:
            node = StubNode("node-a", root)
            self.assertEqual(assert_lab(node, root), None)
            self.assertEqual(node.socket, os.path.abspath(node.socket))

    def test_enforce_mode_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaises(LabError):
                assert_lab(StubNode("node-a", root, mode="enforce"), root)

    def test_a_real_firewall_backend_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaises(LabError):
                assert_lab(StubNode("node-a", root, backend="iptables"), root)
            with self.assertRaises(LabError):
                assert_lab(StubNode("node-a", root, dry_run=False), root)

    def test_a_state_directory_elsewhere_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as root, tempfile.TemporaryDirectory() as elsewhere:
            node = StubNode("node-a", root)
            node.state_dir = elsewhere
            with self.assertRaises(LabError):
                assert_lab(node, root)

    def test_a_watched_auth_log_outside_the_root_is_refused(self) -> None:
        # A config can keep its state in a lab and its auth log at the real one;
        # the scenarios append attacker lines to that file, so it is checked too.
        with tempfile.TemporaryDirectory() as root:
            node = StubNode("node-a", root, logs=["/var/log/auth.log"])
            with self.assertRaises(LabError):
                assert_lab(node, root)

    def test_the_lab_root_must_be_a_directory(self) -> None:
        with tempfile.TemporaryDirectory() as root:
            node = StubNode("node-a", root)
            with self.assertRaises(LabError):
                assert_lab(node, os.path.join(root, "node-a", "agent.sock"))


class TestReport(unittest.TestCase):
    def test_a_detector_row_is_never_read_as_end_to_end(self) -> None:
        results = [
            Result(attack="policy", name="operator block", level=E2E,
                   expectations=["policy"], score=Score(detected=1, blocked=1, gossiped=1),
                   verdict="pass"),
            Result(attack="port_scan", name="stubbed sweep", level=DETECTOR,
                   expectations=["port_scan"], score=Score(detected=1), verdict="pass",
                   why="real SYN_RECV would need a kernel change"),
            Result(attack=UNPROVEN, name="", level=SKIP, expectations=[],
                   verdict=UNCOVERED, why="no detector emits it"),
        ]
        table = render(results, gaps=[UNPROVEN], started_at=0.0)
        self.assertIn("1 end-to-end", table)
        self.assertIn("1 detector-only", table)
        self.assertIn("detector-only (not end-to-end)", table)
        self.assertIn(UNPROVEN, table)

    def test_the_document_carries_the_same_numbers(self) -> None:
        results = [Result(attack="policy", name="x", level=E2E, expectations=[],
                          score=Score(detected=1), verdict="pass", why="because")]
        document = as_document(results, gaps=[UNPROVEN], lab=["node-a"], started_at=0.0)
        self.assertEqual(document["summary"]["end_to_end"], 1)
        self.assertEqual(document["uncovered"], [UNPROVEN])
        self.assertEqual(document["results"][0]["why"], "because")

    def test_exit_code_counts_failures_and_gaps(self) -> None:
        results = [Result(attack="policy", name="x", level=E2E, expectations=[], verdict="fail")]
        self.assertEqual(failure_count(results, []), 1)
        self.assertEqual(failure_count(results, ["exploit_attempt"]), 2)


class TestRunHelpers(unittest.TestCase):
    def test_a_finisher_runs_once_even_when_every_scenario_needs_it(self) -> None:
        with tempfile.TemporaryDirectory() as root:
            run = Run(nodes={"node-a": StubNode("node-a", root)}, lab_root=root,
                      subjects=Subjects())
            calls: list[int] = []
            for _ in range(5):
                run.add_finisher("auth_log_emptied", lambda: calls.append(1))
            self.assertEqual(len(run.finishers), 1)

    def test_target_and_peer(self) -> None:
        with tempfile.TemporaryDirectory() as root:
            nodes = {name: StubNode(name, root) for name in ("node-a", "node-b")}
            run = Run(nodes=nodes, lab_root=root, subjects=Subjects())
            self.assertIs(run.target, nodes["node-a"])
            self.assertIs(run.peer, nodes["node-b"])
            single = Run(nodes={"node-a": nodes["node-a"]}, lab_root=root, subjects=Subjects())
            self.assertIsNone(single.peer)


if __name__ == "__main__":
    unittest.main()
