"""The console's promises, tested rather than asserted in prose.

Three things this file insists on: the console cannot ask a node to do anything
but read, an off-loopback bind cannot happen without a token, and the gossip
observer cannot speak.
"""

from __future__ import annotations

import json
import os
import queue
import socket
import tempfile
import time
import unittest
import urllib.error
import urllib.request

from secops.console.model import Snapshot
from secops.console.observer import GossipObserver
from secops.console.server import ASSETS, Console, build_server, is_loopback, serve_forever
from secops.console.sources import READONLY, ConsoleTarget, NodeSource, clean_args, clamp_limit
from secops.signature import ThreatSignature

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "secops", "console", "static")

MUTATING_COMMANDS = ("flush", "block", "unblock", "isolate", "release_node", "rollback",
                    "restore_file", "approve_endpoint", "revoke_endpoint", "approve_path")


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return probe.getsockname()[1]


class StubWatch:
    """Just enough of SwarmWatch for the HTTP layer: one cached snapshot."""

    passes = 3
    last_error = ""

    def __init__(self, snapshot: Snapshot | None = None) -> None:
        self.snapshot = snapshot or Snapshot(generated_at=time.time())
        self.clients: list[queue.Queue] = []

    def latest(self) -> Snapshot:
        return self.snapshot

    def detail(self, node: str, incident_id: int) -> dict:
        return {"incident": None} if incident_id > 7 else {"incident": {"id": incident_id, "node": node}}

    def subscribe(self) -> queue.Queue:
        client: queue.Queue = queue.Queue()
        self.clients.append(client)
        return client

    def unsubscribe(self, client: queue.Queue) -> None:
        if client in self.clients:
            self.clients.remove(client)


class HttpCase(unittest.TestCase):
    """A real server on a real loopback port, so headers are the ones a browser gets."""

    token = ""

    def setUp(self) -> None:
        self.watch = StubWatch()
        self.console = Console(self.watch, token=self.token)
        self.server = build_server("127.0.0.1", 0, self.console)
        serve_forever(self.server)
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"

    def tearDown(self) -> None:
        self.console.stop_event.set()
        self.server.shutdown()
        self.server.server_close()

    def get(self, path: str, headers: dict | None = None):
        request = urllib.request.Request(self.base + path, headers=headers or {})
        try:
            with urllib.request.urlopen(request, timeout=5.0) as response:
                return response.status, dict(response.headers), response.read()
        except urllib.error.HTTPError as exc:
            with exc:
                return exc.code, dict(exc.headers), exc.read()


class TestReadOnlyByConstruction(unittest.TestCase):
    def test_no_mutating_command_is_whitelisted(self) -> None:
        self.assertEqual(set(READONLY).intersection(MUTATING_COMMANDS), set())
        self.assertEqual(
            set(READONLY),
            {"status", "incidents", "show", "blocks", "peers", "endpoints", "integrity", "stats"},
        )

    def test_clean_args_rejects_anything_not_whitelisted(self) -> None:
        for command in MUTATING_COMMANDS:
            with self.assertRaises(ValueError):
                clean_args(command, {"address": "203.0.113.9"})

    def test_arguments_are_clamped_not_passed_through(self) -> None:
        args = clean_args("incidents", {"limit": "99999", "state": "resolved; drop tables"})
        self.assertEqual(args["limit"], 200)
        self.assertIsNone(args["state"])
        self.assertEqual(clean_args("show", {"id": "12"})["id"], 12)
        with self.assertRaises(ValueError):
            clean_args("show", {"id": "-1"})

    def test_clamp_limit_accepts_only_integers(self) -> None:
        self.assertEqual(clamp_limit("nonsense", default=25), 25)
        self.assertEqual(clamp_limit(0), 1)

    def test_a_source_refuses_to_send_a_write(self) -> None:
        target = ConsoleTarget(
            name="stub", config_path="x", socket_path="/nonexistent/agent.sock",
            state_dir="/nonexistent", key_file="x", bind_ip="127.0.0.1", bind_port=1,
        )
        with self.assertRaises(ValueError):
            NodeSource(target).query("flush")
        with self.assertRaises(ValueError):
            NodeSource(target).query("block", {"address": "203.0.113.9"})


class TestRoutes(HttpCase):
    def test_every_api_route_is_a_named_read(self) -> None:
        for path in ("/api/snapshot", "/api/nodes", "/api/attacks", "/api/blocks",
                     "/api/subjects", "/api/posture", "/api/health"):
            status, _, body = self.get(path)
            self.assertEqual(status, 200, path)
            json.loads(body)

    def test_there_is_no_route_that_writes(self) -> None:
        for path in ("/api/flush", "/api/block", "/api/isolate", "/api/rollback", "/api/restore"):
            status, _, _ = self.get(path)
            self.assertEqual(status, 404, path)
        self.assertNotIn("/api/flush", "".join(ASSETS))

    def test_incident_lookup_validates_and_404s(self) -> None:
        status, _, _ = self.get("/api/incident?node=a&id=notanumber")
        self.assertEqual(status, 400)
        status, _, _ = self.get("/api/incident?id=1")
        self.assertEqual(status, 400)
        status, _, _ = self.get("/api/incident?node=a&id=99")
        self.assertEqual(status, 404)
        status, _, body = self.get("/api/incident?node=a&id=2")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["incident"]["id"], 2)

    def test_headers_lock_the_page_down(self) -> None:
        status, headers, _ = self.get("/")
        self.assertEqual(status, 200)
        self.assertIn("default-src 'none'", headers["Content-Security-Policy"])
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
        self.assertNotIn("script-src 'unsafe-inline'", headers["Content-Security-Policy"])

    def test_asset_directory_cannot_be_escaped(self) -> None:
        with tempfile.TemporaryDirectory() as outer:
            assets = os.path.join(outer, "assets")
            os.makedirs(assets)
            with open(os.path.join(outer, "secret.js"), "w", encoding="utf-8") as handle:
                handle.write("secret")
            with open(os.path.join(assets, "real.css"), "w", encoding="utf-8") as handle:
                handle.write("body{}")
            os.symlink(os.path.join(outer, "secret.js"), os.path.join(assets, "innocent.js"))
            console = Console(self.watch, static_dir=assets)
            self.assertEqual(console.asset("real.css"), b"body{}")
            self.assertIsNone(console.asset("../secret.js"))
            self.assertIsNone(console.asset("innocent.js"))


class TestTokenGate(HttpCase):
    token = "s3cret-token"

    def test_no_token_no_data(self) -> None:
        self.assertEqual(self.get("/api/snapshot")[0], 403)

    def test_wrong_token_is_forbidden_not_fatal(self) -> None:
        # A browser sends the prompt as UTF-8, and compare_digest on str refuses
        # non-ASCII input: that must be a 403, not a dead handler thread.
        self.assertEqual(self.get("/api/snapshot?token=%C3%98qp")[0], 403)
        self.assertEqual(self.get("/api/snapshot?token=nope")[0], 403)

    def test_token_accepted_from_header_or_query(self) -> None:
        self.assertEqual(self.get("/api/snapshot", {"X-Swarm-Token": self.token})[0], 200)
        self.assertEqual(self.get(f"/api/snapshot?token={self.token}")[0], 200)

    def test_a_public_bind_without_a_token_is_refused(self) -> None:
        with self.assertRaises(ValueError):
            build_server("0.0.0.0", 0, Console(StubWatch(), token=""))
        self.assertFalse(is_loopback("10.0.0.11"))
        self.assertTrue(is_loopback("127.0.0.1"))
        self.assertTrue(is_loopback("localhost"))


class TestStaticHasNoHtmlSinks(unittest.TestCase):
    def test_javascript_touches_the_dom_with_text_only(self) -> None:
        with open(os.path.join(STATIC_DIR, "console.js"), encoding="utf-8") as handle:
            script = handle.read()
        sinks = ("innerHTML", "outerHTML", "insertAdjacentHTML", "document.write",
                 "e" + "val(", "new " + "Function")
        for sink in sinks:
            self.assertNotIn(sink, script, sink)

    def test_page_carries_no_inline_script_or_style(self) -> None:
        with open(os.path.join(STATIC_DIR, "index.html"), encoding="utf-8") as handle:
            page = handle.read()
        self.assertNotIn("<script>", page)
        self.assertNotIn("onclick=", page)
        self.assertNotIn("style=", page)
        self.assertIn('src="/console.js"', page)


class TestObserverCannotSpeak(unittest.TestCase):
    def setUp(self) -> None:
        self.key = b"test-swarm-key-0123456789abcdef"
        self.port = free_port()
        self.observer = GossipObserver(bind=("127.0.0.1", self.port), key=self.key)
        self.observer.start()
        self.sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def tearDown(self) -> None:
        self.sender.close()
        self.observer.stop()

    def send(self, payload: bytes) -> None:
        self.sender.sendto(payload, ("127.0.0.1", self.port))
        for _ in range(40):
            time.sleep(0.05)
            if self.observer.stats()["received"]:
                return

    def test_a_signed_threat_is_recorded_and_stops_there(self) -> None:
        sig = ThreatSignature(subject="203.0.113.9", attack="ssh_bruteforce", node="node-x",
                              reason="4 failed logins", tag="block", direction="in",
                              ttl=60.0, ts=time.time(), hop=1, ports=(22,)).with_auth(self.key)
        self.send(sig.to_json())
        stats = self.observer.stats()
        self.assertEqual(stats["received"], 1)
        self.assertEqual(stats["accepted"], 0)  # the callback refuses, so nothing is "taken"
        self.assertEqual(stats["recent"], 1)
        self.assertEqual(self.observer.recent()[0].subject, "203.0.113.9")
        self.assertEqual(stats["sent"], 0)
        self.assertEqual(stats["forwarded"], 0)

    def test_forged_and_malformed_packets_are_counted_not_believed(self) -> None:
        sig = ThreatSignature(subject="203.0.113.10", attack="ssh_bruteforce", node="node-x",
                              reason="forged", tag="block", direction="in", ttl=60.0,
                              ts=time.time(), hop=1).with_auth(b"someone-elses-key")
        self.send(sig.to_json())
        self.assertEqual(self.observer.stats()["rejected_auth"], 1)
        self.assertEqual(self.observer.stats()["recent"], 0)
        self.send(b"this is not a signature")
        self.assertEqual(self.observer.stats()["rejected_shape"], 1)
        self.assertEqual(self.observer.stats()["sent"], 0)

    def test_it_has_no_peers_and_broadcast_reaches_nobody(self) -> None:
        self.assertEqual(self.observer.transport.peers, [])
        sig = ThreatSignature(subject="203.0.113.11", attack="policy", node="node-x",
                              reason="x", tag="block", direction="in", ttl=60.0,
                              ts=time.time(), hop=1).with_auth(self.key)
        self.assertEqual(self.observer.transport.broadcast(sig), 0)
        self.assertEqual(self.observer.stats()["sent"], 0)


if __name__ == "__main__":
    unittest.main()
