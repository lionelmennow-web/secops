"""Scenario contract, scoring, and the registry that must cover every attack class.

A scenario is one claim the project makes - "we catch a port sweep" - turned into
something that either produces an incident on a real node inside a deadline or
does not. `level` is the honest part: `e2e` means a real agent detected a real
event through its real watchers; `detector` means only the detection function ran,
in this process, over a table of connections or command lines that were never
really there. A coverage report that blurs those two is worse than none.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable

from .. import signals
from .node import Node, Subjects

E2E = "e2e"
DETECTOR = "detector"
SKIP = "skip"

PASS = "pass"
FAIL = "fail"
PARTIAL = "partial"
UNCOVERED = "uncovered"
NOT_E2E = "detector-only (not end-to-end)"


@dataclass
class Expect:
    """What must become visible, and where, for a scenario to count as caught."""

    attack: str
    subject: str = ""
    node: str = ""
    blocks: int = 0
    peers: int = 0
    actions: int = 0
    # Isolation travels as gossip but leaves no incident on the receiving node:
    # its whole effect is the address appearing in that node's isolated set.
    isolates: bool = False

    def describe(self) -> str:
        bits = [self.attack]
        if self.subject:
            bits.append(f"subject {self.subject}")
        if self.node:
            bits.append(f"on {self.node}")
        if self.blocks:
            bits.append(f"{self.blocks} block rule(s)")
        if self.peers:
            bits.append(f"{self.peers} peer(s) learned it")
        if self.actions:
            bits.append(f"{self.actions} action(s)")
        return ", ".join(bits)


@dataclass
class Scenario:
    attack: str
    name: str
    level: str
    run: Callable[["Run", Expect], None] | None
    expects: tuple[Expect, ...]
    deadline: float = 25.0
    why: str = ""
    note: str = ""
    preflight: Callable[["Run", "Scenario"], None] | None = None
    cleanup: Callable[["Run", "Scenario"], None] | None = None

    def missing(self) -> bool:
        return self.run is None or self.level == SKIP


@dataclass
class Score:
    """Four independent questions per scenario, never collapsed into one green tick."""

    detected: int = 0
    actioned: int = 0
    blocked: int = 0
    gossiped: int = 0

    def as_dict(self) -> dict:
        return {"detected": self.detected, "actioned": self.actioned,
                "blocked": self.blocked, "gossiped": self.gossiped}


@dataclass
class Result:
    attack: str
    name: str
    level: str
    expectations: list[str]
    score: Score = field(default_factory=Score)
    verdict: str = UNCOVERED
    detail: str = ""
    why: str = ""
    seconds: float = 0.0

    def as_dict(self) -> dict:
        return {
            "attack": self.attack,
            "scenario": self.name,
            "level": self.level,
            "detected": self.score.detected,
            "actioned": self.score.actioned,
            "blocked": self.score.blocked,
            "gossiped": self.score.gossiped,
            "verdict": self.verdict,
            "detail": self.detail,
            "why": self.why,
            "seconds": round(self.seconds, 2),
        }


@dataclass
class Run:
    """Everything a scenario is allowed to touch."""

    nodes: dict[str, Node]
    lab_root: str
    subjects: Subjects
    children: list = field(default_factory=list)
    scratch: dict = field(default_factory=dict)
    finishers: list = field(default_factory=list)
    public_target: str = ""
    deadline_scale: float = 1.0
    quiet: bool = False
    started_at: float = field(default_factory=time.time)

    @property
    def target(self) -> Node:
        return next(iter(self.nodes.values()))

    @property
    def peer(self) -> Node | None:
        values = list(self.nodes.values())
        return values[1] if len(values) > 1 else None

    def say(self, message: str) -> None:
        if not self.quiet:
            print(message, flush=True)

    def add_finisher(self, key: str, action) -> None:
        """Undo something once, at the end of the whole run.

        Truncating the auth log between scenarios would be wrong even with a
        follower that recovers from shrinkage: the remaining lines get read a
        second time, so every later scenario runs against a node that is
        re-living old events.
        """
        if key in self.scratch:
            return
        self.scratch[key] = True
        self.finishers.append(action)


# ---- scoring ---------------------------------------------------------------
def incidents_for(node: Node, expect: Expect, since: float) -> list[dict]:
    rows = node.incidents()
    return [row for row in rows
            if row.get("attack") == expect.attack
            and (not expect.subject or row.get("subject") == expect.subject)
            and float(row.get("ts", 0) or 0) >= since - 1.0]


def scored(run: Run, scenario: Scenario, since: float) -> tuple[Score, str]:
    """Count what actually appeared on each node; do not infer it from the input."""
    score = Score()
    notes: list[str] = []
    for expect in scenario.expects:
        home = run.nodes.get(expect.node) if expect.node else run.target
        if home is None:
            notes.append(f"no node named {expect.node}")
            continue
        rows = incidents_for(home, expect, since)
        if rows:
            score.detected += 1
            sig_ids = {row.get("sig_id", "") for row in rows if row.get("sig_id")}
        else:
            notes.append(f"{home.name}: no {expect.attack} incident for {expect.subject or 'any subject'}")
            continue

        if expect.actions:
            done = 0
            for row in rows:
                detail = home.show(int(row["id"])) or {}
                done += sum(1 for action in detail.get("actions", []) if action.get("ok"))
            if done >= expect.actions:
                score.actioned += 1
            else:
                notes.append(f"{home.name}: {done}/{expect.actions} actions recorded")

        if expect.blocks:
            rules = [rule for rule in home.blocks() if _covers_rule(rule, expect.subject)]
            if len(rules) >= expect.blocks:
                score.blocked += 1
            else:
                notes.append(f"{home.name}: {len(rules)}/{expect.blocks} rules for {expect.subject}")

        if expect.peers:
            learners = [node.name for node in run.nodes.values()
                        if node is not home and _peer_knows(node, expect, sig_ids, since)]
            if len(learners) >= expect.peers:
                score.gossiped += len(learners)
            else:
                notes.append(f"only {len(learners)}/{expect.peers} peer(s) recorded it"
                             f" (peers: {', '.join(learners) or 'none'})")
    return score, "; ".join(notes)


def _peer_knows(node: Node, expect: Expect, sig_ids: set[str], since: float) -> bool:
    if expect.isolates:
        return expect.subject in (node.peers().get("isolated") or [])
    for row in incidents_for(node, expect, since):
        if row.get("origin", "").startswith("peer:") or (row.get("sig_id") and row.get("sig_id") in sig_ids):
            return True
    return False


def _covers_rule(rule: dict, subject: str) -> bool:
    if not subject:
        return True
    return subject in (rule.get("address"), rule.get("cidr"))


def verdict_for(scenario: Scenario, score: Score, detail: str) -> str:
    wanted = scenario.expects
    if score.detected == 0:
        return FAIL
    if any(expect.blocks and score.blocked == 0 for expect in wanted):
        return PARTIAL
    if any(expect.peers and score.gossiped == 0 for expect in wanted):
        return PARTIAL
    return PASS if not detail else PARTIAL


# ---- registry --------------------------------------------------------------
def build_registry() -> list[Scenario]:
    from .scenarios import integrity, net, policy, procs, ssh

    return [*ssh.scenarios(), *procs.scenarios(), *integrity.scenarios(),
            *net.scenarios(), *policy.scenarios()]


def gaps(registry: list[Scenario]) -> list[str]:
    covered = {scenario.attack for scenario in registry if not scenario.missing()}
    return sorted(set(signals.ATTACKS) - covered)
