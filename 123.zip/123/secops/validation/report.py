"""The coverage matrix: what was claimed, what was proven, and what was not.

The exit code counts the classes that are not covered, in the same shape as
`swarm-selftest`, so this can gate a CI job without parsing the table.
"""

from __future__ import annotations

import time

from .. import signals
from .registry import DETECTOR, E2E, FAIL, PARTIAL, PASS, SKIP, UNCOVERED, Result

COLUMNS = ("attack", "scenario", "level", "detected", "actioned", "blocked", "gossiped", "verdict")
SYMBOL = {PASS: "pass", PARTIAL: "partial", FAIL: "FAIL", UNCOVERED: "uncovered", SKIP: "skipped"}


def render(results: list[Result], *, gaps: list[str], started_at: float) -> str:
    rows = [
        {
            "attack": result.attack,
            "scenario": result.name or "(no scenario)",
            "level": result.level,
            "detected": result.score.detected,
            "actioned": result.score.actioned,
            "blocked": result.score.blocked,
            "gossiped": result.score.gossiped,
            "verdict": SYMBOL.get(result.verdict, result.verdict),
        }
        for result in results
    ]
    widths = {name: max(len(name), *(len(str(row[name])) for row in rows)) for name in COLUMNS} if rows else {}

    def rule(left: str, middle: str, right: str) -> str:
        return left + middle.join("─" * (widths[name] + 2) for name in COLUMNS) + right

    def line(row: dict) -> str:
        return "│ " + " │ ".join(str(row[name]).ljust(widths[name]) for name in COLUMNS) + " │"

    out = [rule("┌", "┬", "┐"), line(dict(zip(COLUMNS, COLUMNS))), rule("├", "┼", "┤")]
    out += [line(row) for row in rows]
    out.append(rule("└", "┴", "┘"))

    end_to_end = [result for result in results if result.level == E2E]
    caught = [result for result in end_to_end if result.verdict in (PASS, PARTIAL)]
    out.append("")
    out.append(f"{len(results)} scenarios: {len(end_to_end)} end-to-end, of which {len(caught)} "
               f"caught the threat; {sum(1 for r in results if r.level == DETECTOR)} detector-only; "
               f"{len(gaps)} class(es) uncovered")
    out.append("each count column is how many expectations were met in that dimension, not a raw total:")
    out.append("detected = a node recorded the incident; actioned = the responder recorded an action;")
    out.append("blocked = a firewall rule exists (in monitor mode it is planned, not installed);")
    out.append("gossiped = another node learned it. detector-only rows never count as end-to-end.")
    out.append(f"run took {time.time() - started_at:.1f}s")

    explained = [result for result in results if result.why]
    if explained:
        out.append("")
        for result in explained:
            label = "detector-only (not end-to-end)" if result.level == DETECTOR else SYMBOL.get(result.verdict, result.verdict)
            out.append(f"  {result.attack}: {label} - {result.why}")
    return "\n".join(out)


def as_document(results: list[Result], *, gaps: list[str], lab: list[str], started_at: float) -> dict:
    return {
        "generated_at": time.time(),
        "seconds": round(time.time() - started_at, 2),
        "lab_nodes": lab,
        "vocabulary": list(signals.ATTACKS),
        "uncovered": gaps,
        "summary": {
            "scenarios": len(results),
            "end_to_end": sum(1 for result in results if result.level == E2E),
            "detector_only": sum(1 for result in results if result.level == DETECTOR),
            "passed": sum(1 for result in results if result.verdict == PASS),
            "partial": sum(1 for result in results if result.verdict == PARTIAL),
            "failed": sum(1 for result in results if result.verdict in (FAIL, UNCOVERED)),
        },
        "results": [result.as_dict() for result in results],
    }


def failure_count(results: list[Result], gaps: list[str]) -> int:
    return sum(1 for result in results if result.verdict in (FAIL, UNCOVERED)) + len(gaps)
