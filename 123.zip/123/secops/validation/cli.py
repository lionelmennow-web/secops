"""`swarmvalidate` - replay the documented attacks against a lab and score them.

Reads the same agent configs the console reads, but this tool *does* write: log
lines, decoy processes, planted keys, operator blocks. Everything it can do is
gated by `assert_lab`, and the point is that a lab node in enforce mode or with a
real firewall backend is refused before the first write.
"""

from __future__ import annotations

import argparse
import json
import sys
import time

from .. import signals
from .node import LabError, Subjects, assert_lab, load_nodes
from .registry import (
    DETECTOR,
    FAIL,
    NOT_E2E,
    PASS,
    Result,
    Run,
    Scenario,
    build_registry,
    gaps,
    scored,
    verdict_for,
)
from .report import as_document, failure_count, render

DEFAULT_LIMIT = 60


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="swarmvalidate",
        description="Replay attacks against a monitored lab and report what was actually caught.",
    )
    parser.add_argument("--node", dest="nodes", action="append", default=[], metavar="AGENT_JSON",
                        help="a lab agent config (repeatable; two make the gossip tests meaningful)")
    parser.add_argument("--lab-root", default="", metavar="DIR",
                        help="every node's state and socket must live under here")
    parser.add_argument("--only", action="append", default=[], metavar="ATTACK",
                        help="run just these attack classes (repeatable)")
    parser.add_argument("--list", action="store_true", help="print the registry and exit")
    parser.add_argument("--json", action="store_true", help="machine-readable report")
    parser.add_argument("--keep", action="store_true",
                        help="skip cleanup: leave the log lines, rules and decoys behind for inspection")
    parser.add_argument("--public-target", default="", metavar="IP:PORT",
                        help="an address you own, to exercise the outbound path for real")
    parser.add_argument("--timeout", type=float, default=12.0, help="per-request control socket timeout")
    parser.add_argument("--deadline-scale", type=float, default=1.0,
                        help="multiply every scenario deadline: raise it on a loaded machine")
    return parser


def resolve_nodes(args) -> list:
    if not args.nodes:
        raise SystemExit("no lab nodes: pass --node AGENT_JSON (at least one, two for gossip)")
    if not args.lab_root:
        raise SystemExit("--lab-root is required: this tool writes to the nodes it tests")
    return load_nodes(args.nodes, timeout=args.timeout)


def run_scenario(run: Run, scenario: Scenario) -> Result:
    started = time.time()
    result = Result(attack=scenario.attack, name=scenario.name, level=scenario.level,
                    expectations=[expect.describe() for expect in scenario.expects],
                    why=scenario.why)
    if scenario.missing():
        result.verdict = "uncovered"
        result.detail = scenario.why
        return result

    try:
        if scenario.preflight:
            scenario.preflight(run, scenario)
        scenario.run(run, scenario.expects[0] if scenario.expects else None)
    except LabError as exc:
        result.verdict = "skipped"
        result.detail = str(exc)
        return result
    except Exception as exc:  # a scenario that cannot run is a claim that did not hold
        result.verdict = FAIL
        result.detail = f"{type(exc).__name__}: {exc}"
        return result

    if scenario.level == DETECTOR:
        result.score.detected = 1
        result.verdict = PASS
        result.detail = NOT_E2E
        return result

    deadline = scenario.deadline * run.deadline_scale
    since = started
    score, detail = _wait_for_score(run, scenario, since, deadline)
    result.score = score
    result.verdict = verdict_for(scenario, score, detail)
    result.detail = detail
    return result


def _wait_for_score(run: Run, scenario: Scenario, since: float, deadline: float):
    """Poll until every node that should have caught it has, or the clock runs out."""
    limit = time.time() + deadline
    score, detail = None, ""
    while True:
        score, detail = scored(run, scenario, since)
        if score.detected >= len(scenario.expects) or time.time() >= limit:
            return score, detail
        time.sleep(0.5)


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    registry = build_registry()

    if args.list:
        for scenario in registry:
            print(f"{scenario.attack:<18} {scenario.level:<9} {scenario.name or '-'}")
        missing = gaps(registry)
        if missing:
            print(f"\nno scenario at all for: {', '.join(missing)}")
        return 0

    selected = [scenario for scenario in registry if not args.only or scenario.attack in args.only]
    unknown = set(args.only) - {scenario.attack for scenario in registry}
    if unknown:
        print(f"unknown attack class(es): {', '.join(sorted(unknown))}", file=sys.stderr)
        print(f"known: {', '.join(signals.ATTACKS)}", file=sys.stderr)
        return 2

    try:
        nodes = resolve_nodes(args)
    except LabError as exc:
        print(f"lab gate: {exc}", file=sys.stderr)
        return 2

    for node in nodes:
        try:
            assert_lab(node, args.lab_root)
        except LabError as exc:
            print(f"lab gate: {exc}", file=sys.stderr)
            return 2

    run = Run(nodes={node.name: node for node in nodes}, lab_root=args.lab_root,
              subjects=Subjects(), public_target=args.public_target,
              deadline_scale=args.deadline_scale, quiet=args.json)

    if not args.json:
        print(f"lab: {', '.join(f'{node.name} ({node.socket})' for node in nodes)}")
        print(f"root: {run.lab_root}")
        print()

    results: list[Result] = []
    problems: list[str] = []
    for scenario in selected:
        if not args.json:
            print(f"  {scenario.attack} - {scenario.name or 'uncovered'} [{scenario.level}]")
        result = run_scenario(run, scenario)
        results.append(result)
        if not args.json and result.detail:
            print(f"      -> {result.verdict}: {result.detail[:150]}")
        if not args.keep and scenario.cleanup:
            try:
                scenario.cleanup(run, scenario)
            except Exception as exc:
                problems.append(f"cleanup of {scenario.attack} failed: {type(exc).__name__}: {exc}")

    if not args.keep:
        for finisher in run.finishers:
            try:
                finisher()
            except Exception as exc:
                problems.append(f"run cleanup failed: {type(exc).__name__}: {exc}")
        for address in run.subjects.used():
            for node in nodes:
                try:
                    node.unblock(address)
                except Exception as exc:
                    problems.append(f"could not release {address} on {node.name}: {type(exc).__name__}")

    covered = gaps(registry)
    if args.json:
        document = as_document(results, gaps=covered, lab=[node.name for node in nodes],
                               started_at=run.started_at)
        document["problems"] = problems
        print(json.dumps(document, indent=2, default=str))
    else:
        print()
        print(render(results, gaps=covered, started_at=run.started_at))
        for problem in problems:
            print(f"  warning: {problem}")
    return failure_count(results, [] if args.only else covered)


if __name__ == "__main__":
    raise SystemExit(main())
