"""Replay the attacks this project claims to catch, against a lab, and score it.

`swarmvalidate` answers one question: does the defense actually fire for each
detection class, or do the rules only look right on paper? It drives real agents
over their own control socket, feeds them real log lines and real processes, and
reports per class whether the threat was detected, actioned, blocked and
gossiped to a peer.

Nothing here writes an exploit. The payloads are the same synthetic
`sshd[...]` lines the README suggests typing by hand, decoy command lines that
only *look* like a reverse shell to the grammar, and files under the lab
directory. Every scenario passes a lab gate first (see `node.assert_lab`): a node
in enforce mode, with a real firewall backend, or with state outside `--lab-root`
is refused before a single byte is written.
"""
