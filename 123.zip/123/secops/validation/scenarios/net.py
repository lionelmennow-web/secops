"""Connection scenarios: call-home correlation and inbound sweeps.

`c2_outbound` can be tested for real, but only against a session this host
actually has open: the agent's own outbound filter drops loopback and private
addresses, so a synthetic address would never reach the rule. Where no such
session exists the scenario reports itself skipped rather than pretending.

`port_scan` cannot be end-to-end here at all: real SYN_RECV rows need the kernel
to be pushed past its accept queue, which is a mutation of the host and outside
the lab gate. It is scored against the watcher's own logic instead.
"""

from __future__ import annotations

from ...detect.net import SCAN_PORTS, NetWatcher
from ...events import TcpConnection
from ...procfs import is_private, read_tcp_connections
from ..node import LabError
from ..registry import DETECTOR, E2E, Expect, Run, Scenario

SCAN_SOURCE = "203.0.113.200"
FAKE_C2 = "93.184.216.34"
FAKE_C2_PORT = 4444
SYN_RECV = "SYN_RECV"


class _Endpoints:
    """Nothing has been seen before, so a first contact stays a first contact."""

    def known(self, endpoint: str) -> bool:
        return False

    def note(self, endpoint: str) -> None:
        return None


class _Firewall:
    def __init__(self, rules=()) -> None:
        self._rules = list(rules)

    def snapshot(self) -> list:
        return self._rules


class _View:
    def __init__(self, connections=()) -> None:
        self.connections = list(connections)

    def outbound(self) -> list:
        return [c for c in self.connections if c.state in ("ESTABLISHED", "CLOSE_WAIT", "SYN_SENT")]

    def connections_of(self, pid: int) -> list:
        return [c for c in self.connections if c.pid == pid]


def _connection(remote: str, remote_port: int, local_port: int, state: str, pid: int = 0, comm: str = ""):
    return TcpConnection(
        local="10.0.0.5", local_port=local_port, remote=remote, remote_port=remote_port,
        state=state, uid=1000, inode=0, family=4, pid=pid, comm=comm,
    )


def _live_public_session(run: Run) -> tuple[str, int] | None:
    """An endpoint this host is really talking to, that the node has seen before."""
    recent = run.target.result("endpoints", limit=40).get("recent", [])
    live = set()
    for family in (4, 6):
        for connection in read_tcp_connections(family):
            if connection.state == "ESTABLISHED":
                live.add((connection.remote, connection.remote_port))
    for entry in recent:
        endpoint = entry[0] if isinstance(entry, (list, tuple)) else entry
        address, _, port = endpoint.rpartition(":")
        if not address or not port.isdigit():
            continue
        if (address, int(port)) in live and not is_private(address):
            return address, int(port)
    return None


def known_bad_session(run: Run, expect: Expect) -> None:
    session = _live_public_session(run)
    if session is None:
        raise LabError("no live public outbound session on this host to correlate a rule against")
    address, port = session
    expect.subject = address
    run.scratch["c2_address"] = address
    # Not drawn from the subject pool, so it has to be claimed by hand or the
    # run-end release would skip it and every peer would keep refusing a host
    # this machine really talks to.
    run.subjects.note(address)
    run.target.block(address, ttl=900.0, reason="validation: pretend this address is refused")
    run.say(f"    refused {address}:{port}, a session this host really has open; "
            "the watcher must now call it a known-bad call-home")


def sweep(run: Run, expect: Expect) -> None:
    """Feed the watcher a half-open sweep it could never see on loopback."""
    threshold = int(run.target.watcher("network").get("scan_threshold", SCAN_PORTS) or 0)
    expect.subject = SCAN_SOURCE
    if threshold <= 0:
        raise LabError(f"{run.target.name} has scan detection switched off (network.scan_ports is false)")

    threats: list = []
    watcher = NetWatcher({"scan_ports": threshold, "grace": 0.0}, _View([]), _Endpoints(),
                         _Firewall(), threats.append)
    rows = [_connection(SCAN_SOURCE, 51000 + index, 2000 + index, SYN_RECV) for index in range(threshold + 2)]
    watcher.netview = _View(rows)
    watcher._watch_scans()
    fired = [threat for threat in threats if threat.attack == "port_scan"]
    run.say(f"    {len(rows)} SYN_RECV rows across {len(rows)} local ports from {SCAN_SOURCE}: "
            f"{'fired' if fired else 'did not fire'} at threshold {threshold}")
    if not fired:
        raise AssertionError(f"{len(rows)} half-open sockets below the sweep threshold {threshold}")
    # The regression this documents: a falsy default once read as "fire on one socket".
    quiet = NetWatcher({"scan_ports": 0}, _View(rows), _Endpoints(), _Firewall(), lambda threat: None)
    if quiet.scan_threshold != 0:
        raise AssertionError("scan_ports=0 no longer means disabled")
    single = []
    quiet_watcher = NetWatcher({"scan_ports": threshold}, _View(rows[:1]), _Endpoints(), _Firewall(), single.append)
    quiet_watcher._watch_scans()
    if single:
        raise AssertionError("one half-open socket was enough to call it a sweep")


def call_home(run: Run, expect: Expect) -> None:
    """The real `_watch_outbound`, over a connection that was never made."""
    if is_private(FAKE_C2):
        raise LabError(f"{FAKE_C2} is not routable from the agent's point of view")
    threats: list = []
    watcher = NetWatcher({"grace": 0.0}, _View([]), _Endpoints(), _Firewall(), threats.append)
    row = _connection(FAKE_C2, FAKE_C2_PORT, 40000, "ESTABLISHED", pid=1, comm="python3")
    watcher.netview = _View([row])
    watcher.reported.clear()
    watcher._watch_outbound()
    fired = [threat for threat in threats if threat.attack == "c2_outbound"]
    expect.subject = FAKE_C2
    run.say(f"    synthetic first-seen session to {FAKE_C2}:{FAKE_C2_PORT} from a 'python3' process: "
            + (f"{fired[0].details.get('confidence')} confidence, actions {fired[0].actions}"
               if fired else "no threat"))
    if not fired:
        raise AssertionError("a risky interpreter on an odd first-seen port scored below the reporting bar")


def scenarios() -> list[Scenario]:
    return [
        Scenario(
            attack="c2_outbound",
            name="live session to an address the swarm already refuses",
            level=E2E,
            run=known_bad_session,
            expects=(Expect(attack="c2_outbound", peers=1),),
            deadline=30.0,
            cleanup=lambda run, scenario: _unblock(run),
            note="no packet is invented here: the session already exists, the rule is planted, "
                 "and the agent's own watcher makes the correlation",
        ),
        Scenario(
            attack="c2_outbound",
            name="first-seen endpoint from a risky interpreter",
            level=DETECTOR,
            run=call_home,
            expects=(Expect(attack="c2_outbound"),),
            why="loopback and every TEST-NET address report is_private, so no synthetic address "
                "can reach the outbound filter end-to-end without opening a real session to a "
                "third party; the watcher's logic is exercised here instead",
        ),
        Scenario(
            attack="port_scan",
            name="half-open sweep across eight local ports",
            level=DETECTOR,
            run=sweep,
            expects=(Expect(attack="port_scan"),),
            why="real SYN_RECV rows need accept-queue overflow or syncookies switched off, which "
                "mutates the kernel - forbidden under the lab gate; this runs the watcher over a "
                "connection table the agent would have read from /proc",
        ),
    ]


def _unblock(run: Run) -> None:
    address = run.scratch.pop("c2_address", "")
    if address:
        try:
            run.target.query("unblock", address=address)
        except Exception as exc:  # a leftover rule is reported, not fatal
            run.say(f"    could not release {address}: {exc}")
