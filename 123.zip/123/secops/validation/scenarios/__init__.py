"""Scenario modules. Import them through `registry.build_registry`."""
