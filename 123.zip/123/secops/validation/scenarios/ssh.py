"""Authentication-log scenarios: the class of attack this project is documented
to catch by appending lines to /var/log/auth.log. Same mechanism, only under the
lab root, and never against an address that belongs to a real host.
"""

from __future__ import annotations

import json
import os
import random

from ..node import LabError, sudo_fail
from ..node import ssh_accept, ssh_exhaust, ssh_fail
from ..registry import E2E, Expect, Run, Scenario

FAILED_LOGINS = 6


def _known_sources(run: Run) -> set[str]:
    """`new_source_login` only fires for an address the node has never seen succeed."""
    path = os.path.join(run.target.state_dir, "approved_login_sources.json")
    try:
        with open(path, encoding="utf-8") as handle:
            return set(json.load(handle).get("sources", []))
    except (OSError, json.JSONDecodeError):
        return set()


def _subject(key: str):
    def preflight(run: Run, scenario: Scenario) -> None:
        scenario.expects[0].subject = run.subjects.take(key)
    return preflight


def _fresh_user(run: Run, scenario: Scenario) -> None:
    """A local account name is the subject here, so it has to change between runs:
    repeat-suppression keys on (attack, subject) and would swallow the second one."""
    user = f"svc{random.randrange(100000):05d}"
    scenario.expects[0].subject = f"local:{user}"


def _unseen_source(run: Run, scenario: Scenario) -> None:
    """Pick an address whose successful login would genuinely be the first."""
    seen = _known_sources(run)
    index = 0
    while True:
        address = run.subjects.take(f"newsource:{index}")
        if address not in seen:
            scenario.expects[0].subject = address
            return
        index += 1


def _prepare_log(run: Run) -> None:
    """A writable auth log, and a promise to empty it after the last scenario.

    Emptied rather than trimmed back to its pre-run size: shrinking to a shorter
    file that still holds text makes the follower re-read that text as new data,
    so every line an earlier run left behind would become a fresh incident again.
    An empty file is what a lab auth log looks like before the test.
    """
    if not run.target.auth_logs:
        raise LabError(f"{run.target.name} watches journald only: there is no auth log file "
                       "for a scenario to write attacker lines into")
    run.add_finisher("auth_log_emptied", lambda: run.target.truncate_auth(0))


def brute_force(run: Run, expect: Expect) -> None:
    _prepare_log(run)
    run.target.append_auth([ssh_fail(index, expect.subject) for index in range(FAILED_LOGINS)])
    run.say(f"    {FAILED_LOGINS} failed passwords from {expect.subject} (threshold is 4)")


def max_attempts(run: Run, expect: Expect) -> None:
    _prepare_log(run)
    run.target.append_auth([ssh_exhaust(0, expect.subject)])
    run.say(f"    sshd stopped negotiating with {expect.subject} after MaxAuthTries")


def credential_breach(run: Run, expect: Expect) -> None:
    _prepare_log(run)
    # Fewer failures than the bruteforce threshold on purpose: the point is the
    # success that follows them, and a bruteforce incident would only muddy it.
    run.target.append_auth([ssh_fail(index, expect.subject) for index in range(2)] + [ssh_accept(9, expect.subject)])
    run.say(f"    two failures, then a successful login from {expect.subject}")


def new_source(run: Run, expect: Expect) -> None:
    _prepare_log(run)
    run.target.append_auth([ssh_accept(0, expect.subject, user="deploy")])
    run.say(f"    first recorded successful login for deploy@{expect.subject}")


def priv_esc(run: Run, expect: Expect) -> None:
    _prepare_log(run)
    user = expect.subject.split(":", 1)[1]
    run.target.append_auth([sudo_fail(user)])
    run.say(f"    three failed sudo attempts by local user {user!r}")


def scenarios() -> list[Scenario]:
    return [
        Scenario(
            attack="ssh_bruteforce",
            name="sshd failed-password burst",
            level=E2E,
            run=brute_force,
            expects=(Expect(attack="ssh_bruteforce", blocks=1, peers=1, actions=1),),
            preflight=_subject("bruteforce"),
            note="six failures watched by the real tailer, parser and window",
        ),
        Scenario(
            attack="ssh_max_attempts",
            name="sshd MaxAuthTries exhausted",
            level=E2E,
            run=max_attempts,
            expects=(Expect(attack="ssh_max_attempts", blocks=1, peers=1, actions=1),),
            preflight=_subject("max_attempts"),
            note="one 'maximum authentication attempts exceeded' line",
        ),
        Scenario(
            attack="credential_breach",
            name="login succeeds after failures",
            level=E2E,
            run=credential_breach,
            expects=(Expect(attack="credential_breach", blocks=1, peers=1),),
            preflight=_subject("breach"),
            note="the guessed-credential case: failure then success from one address",
        ),
        Scenario(
            attack="new_source_login",
            name="first successful login from a new address",
            level=E2E,
            run=new_source,
            expects=(Expect(attack="new_source_login"),),
            preflight=_unseen_source,
            note="alert only by design, so no block and no gossip is expected",
        ),
        Scenario(
            attack="priv_esc_attempt",
            name="local sudo authentication failure",
            level=E2E,
            run=priv_esc,
            expects=(Expect(attack="priv_esc_attempt"),),
            preflight=_fresh_user,
            note="a local account is not network-blockable: alert only",
        ),
    ]
