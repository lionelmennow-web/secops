"""Persistence scenario: append an attacker key to an authorized_keys file the
node is watching, and see whether the agent notices, restores and quarantines.

The file lives under the lab root, so this never touches a real account.
"""

from __future__ import annotations

import os
import time

from ...config import Config
from ..node import LabError
from ..registry import E2E, Expect, Run, Scenario

BASELINE = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILlabbaselinekeylabbaselinekeylabbase lab-baseline"
PLANTED = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPlantedAttackerKeyPlantedAttackerKeyX planted-attacker"


def _watched_path(run: Run) -> str:
    config = Config.load(run.target.config_path)
    paths = [entry for entry in config.integrity.get("paths", []) if not _has_glob(entry)]
    if not paths:
        raise LabError(f"{run.target.name}: no literal integrity path to plant a key in")
    return os.path.realpath(paths[0])


def _has_glob(entry: str) -> bool:
    return any(character in entry for character in "*?[")


def plant_key(run: Run, expect: Expect) -> None:
    path = _watched_path(run)
    expect.subject = path
    baseline_exists = os.path.exists(path)
    run.scratch["integrity_path"] = path
    run.scratch["baseline_exists"] = baseline_exists
    run.scratch["baseline_bytes"] = open(path, "rb").read() if baseline_exists else b""

    with open(path, "w", encoding="utf-8") as handle:
        handle.write(BASELINE + "\n")
    os.chmod(path, 0o600)
    run.say(f"    wrote a baseline key to {path}; waiting for the agent to record it")

    watched = run.target.wait_for(
        lambda: _baselined(run.target, path), timeout=20.0, message="baseline"
    )
    if not watched:
        raise LabError(f"{run.target.name} never baselined {path}: is the integrity watcher running?")

    with open(path, "a", encoding="utf-8") as handle:
        handle.write(PLANTED + "\n")
    run.say(f"    appended an attacker key to {os.path.basename(path)} (interval is 5s)")


def _baselined(node, path: str) -> bool:
    try:
        manifest = os.path.join(node.state_dir, "integrity_manifest.json")
        import json

        with open(manifest, encoding="utf-8") as handle:
            record = json.load(handle).get("files", {}).get(path, {})
        return bool(record.get("sha256")) and bool(record.get("backup"))
    except (OSError, ValueError):
        return False


def restore_file(run: Run, scenario: Scenario) -> None:
    path = run.scratch.pop("integrity_path", "")
    if not path:
        return
    if run.scratch.pop("baseline_exists", False):
        with open(path, "wb") as handle:
            handle.write(run.scratch.pop("baseline_bytes", b""))
    else:
        try:
            os.remove(path)
        except OSError:
            pass


def scenarios() -> list[Scenario]:
    return [
        Scenario(
            attack="persistence",
            name="attacker key appended to a watched authorized_keys",
            level=E2E,
            run=plant_key,
            expects=(Expect(attack="persistence", actions=1),),
            deadline=40.0,
            cleanup=restore_file,
            note="restore_paths is planned by the responder; in monitor mode the file is "
                 "restored from the agent's own backup only if the action really runs",
        ),
    ]
