"""Operator-initiated containment: the two classes a human triggers, not a detector.

Both are real commands sent over the control socket, which is why the lab gate
matters most here - in enforce mode these would block traffic on a live host.
"""

from __future__ import annotations

from ..node import LabError
from ..registry import E2E, Expect, Run, Scenario


def manual_block(run: Run, expect: Expect) -> None:
    address = run.subjects.take("policy")
    expect.subject = address
    run.target.block(address, ttl=900.0, reason="validation: operator block")
    run.say(f"    operator-blocked {address} over the control socket (dry-run backend)")


def rollback_block(run: Run, scenario: Scenario) -> None:
    address = scenario.expects[0].subject
    if address:
        run.target.query("unblock", address=address)


def isolate_node(run: Run, expect: Expect) -> None:
    """Isolate a stand-in address and watch the lesson cross the wire.

    Not the peer's own address: in a loopback lab every node advertises
    127.0.0.1, so isolating "the peer" would isolate the host itself and leave
    the remaining scenarios gossiping into a wall. A documentation address
    exercises the same broadcast and the same receiving branch.
    """
    if run.peer is None:
        raise LabError("node_isolate needs two nodes: pass a second --node config")
    address = run.subjects.take("isolate")
    expect.subject = address
    run.scratch["isolated"] = address
    run.target.isolate(address, ttl=900.0, reason="validation: isolate a node")
    run.say(f"    {run.target.name} told the swarm to refuse everything from {address}")


def release(run: Run, scenario: Scenario) -> None:
    address = run.scratch.pop("isolated", "")
    if not address:
        return
    for node in run.nodes.values():
        if address in (node.peers().get("isolated") or []):
            node.query("release_node", address=address)
    run.say(f"    released {address} on every node that learned it")


def scenarios() -> list[Scenario]:
    return [
        Scenario(
            attack="policy",
            name="operator block through the guard rails",
            level=E2E,
            run=manual_block,
            expects=(Expect(attack="policy", blocks=1, peers=1),),
            cleanup=rollback_block,
            note="the guard must allow a documentation address and refuse 127.0.0.1",
        ),
        Scenario(
            attack="node_isolate",
            name="isolate a node, then release it",
            level=E2E,
            run=isolate_node,
            expects=(Expect(attack="node_isolate", peers=1, isolates=True),),
            deadline=30.0,
            cleanup=release,
            note="gossip-only containment: the peer records the isolation in its own state; "
                 "the isolated address never had an agent to reconfigure",
        ),
    ]
