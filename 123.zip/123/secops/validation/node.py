"""One running agent, driven over its own control socket.

This is the harness's only handle on a node, and every mutation it can perform
(`block`, `isolate`, `rollback`) is gated by `assert_lab` before use.
"""

from __future__ import annotations

import ipaddress
import json
import os
import random
import time

from ..cli import request
from ..config import Config, ConfigError


class LabError(Exception):
    """A node refused to look like a lab: the run stops before it can bite."""


class NodeError(Exception):
    def __init__(self, detail: str) -> None:
        super().__init__(detail)
        self.detail = detail


class Node:
    def __init__(self, config_path: str, *, timeout: float = 12.0) -> None:
        self.config_path = os.path.abspath(config_path)
        self.timeout = timeout
        try:
            self.config = Config.load(self.config_path)
        except (ConfigError, OSError, ValueError) as exc:
            raise LabError(f"{config_path}: unreadable agent config ({exc})")
        self.name = self.config.node_name()
        self.socket = ""
        self.state_dir = os.path.abspath(os.path.expanduser(self.config.audit.get("dir", "")))
        self.auth_logs = [path for path in self.config.ssh.get("logs", []) if not path.startswith("journal:")]

    # ---- transport ---------------------------------------------------------
    def query(self, command: str, **args) -> dict:
        if not self.socket:
            raise NodeError(f"{self.name}: no control socket resolved yet")
        payload = {"command": command, "args": args}
        reply = request(payload, self.socket, timeout=self.timeout)
        if not reply.get("ok", False):
            raise NodeError(f"{self.name} {command}: {reply.get('error', 'no error given')}")
        return reply

    def result(self, command: str, **args):
        return self.query(command, **args).get("result")

    def connect(self) -> None:
        """Resolve the socket from the config first, then re-point at what the agent reports."""
        self.socket = os.path.join(self.state_dir, "agent.sock")
        status = self.status()
        reported = status.get("control_socket") or ""
        if reported and os.path.exists(reported):
            self.socket = reported

    def status(self) -> dict:
        reply = request({"command": "status"}, self.socket, timeout=self.timeout)
        if not reply.get("ok", False):
            raise LabError(f"{self.name}: agent not reachable at {self.socket} "
                           f"({reply.get('error', 'no error given')})")
        return reply["result"]

    # ---- reads -------------------------------------------------------------
    def incidents(self, limit: int = 60) -> list[dict]:
        return self.result("incidents", limit=limit) or []

    def show(self, incident_id: int) -> dict | None:
        return self.result("show", id=incident_id)

    def blocks(self) -> list[dict]:
        return self.result("blocks") or []

    def peers(self) -> dict:
        return self.result("peers") or {}

    def counters(self) -> dict:
        return (self.status().get("swarm") or {}).get("counters", {})

    def watcher(self, section: str) -> dict:
        return (self.status().get("watchers") or {}).get(section, {})

    # ---- writes, all behind the lab gate -----------------------------------
    def block(self, address: str, *, ttl: float = 900.0, reason: str = "validation") -> dict:
        return self.result("block", address=address, ttl=ttl, reason=reason) or {}

    def isolate(self, address: str, *, ttl: float = 900.0, reason: str = "validation") -> dict:
        return self.result("isolate", address=address, ttl=ttl, reason=reason) or {}

    def unblock(self, address: str) -> dict:
        return self.result("unblock", address=address) or {}

    def rollback(self, incident_id: int) -> dict:
        return self.result("rollback", incident=incident_id) or {}

    # ---- lab inputs --------------------------------------------------------
    def append_auth(self, lines: list[str]) -> str:
        path = self.auth_logs[0]
        with open(path, "a", encoding="utf-8") as handle:
            handle.write("".join(line + "\n" for line in lines))
            handle.flush()
        return path

    def truncate_auth(self, size: int) -> None:
        path = self.auth_logs[0]
        with open(path, "r+", encoding="utf-8") as handle:
            handle.truncate(size)

    # ---- waiting -----------------------------------------------------------
    def wait_for(self, predicate, timeout: float = 20.0, message: str = "condition"):
        """Poll until `predicate(value)` is truthy and return it; `None` on timeout."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                value = predicate()
            except (NodeError, LabError):
                value = None
            if value:
                return value
            time.sleep(0.25)
        return None


def ssh_fail(index: int, source: str, user: str = "root") -> str:
    clock = time.strftime("%b %d %H:%M:%S")
    return (f"{clock} target sshd[{4000 + index}]: Failed password for {user} "
            f"from {source} port {40000 + index} ssh2")


def ssh_exhaust(index: int, source: str, user: str = "root") -> str:
    clock = time.strftime("%b %d %H:%M:%S")
    return (f"{clock} target sshd[{4000 + index}]: error: maximum authentication attempts "
            f"exceeded for {user} from {source} port {40000 + index} ssh2")


def ssh_accept(index: int, source: str, user: str = "root") -> str:
    clock = time.strftime("%b %d %H:%M:%S")
    return (f"{clock} target sshd[{4000 + index}]: Accepted password for {user} "
            f"from {source} port {40000 + index} ssh2")


def sudo_fail(user: str = "svc") -> str:
    return f"sudo: {user} : 3 incorrect password attempts ; TTY=pts/0 ; PWD=/home/{user} ; USER=root ; COMMAND=/usr/bin/id"


# TEST-NET-3: reserved for documentation, never routable, and `Guard.may_block`
# lets us refuse it because it is neither loopback nor a configured peer.
SUBJECTS = [f"203.0.113.{last}" for last in range(30, 90)]


class Subjects:
    """One address per scenario: repeat-suppression collapses two runs of the same
    subject/class, so sharing an address between scenarios would hide a result.

    The order is shuffled per run rather than counted off, because a second run
    within the suppression window would otherwise reuse 203.0.113.30 and read a
    perfectly good detection as a miss.
    """

    def __init__(self) -> None:
        self._pool = random.sample(SUBJECTS, len(SUBJECTS))
        self._given: dict[str, str] = {}

    def take(self, key: str) -> str:
        if key not in self._given:
            if not self._pool:
                raise LabError("ran out of documentation addresses for scenarios")
            self._given[key] = self._pool.pop(0)
        return self._given[key]

    def note(self, address: str) -> None:
        """Claim an address the run did not draw from the pool, so cleanup releases
        it too. A scenario that blocks a genuinely live address would otherwise
        leave the refusal standing after the run, on this host and on its peers."""
        self._given.setdefault(f"external:{address}", address)

    def used(self) -> list[str]:
        return sorted(set(self._given.values()))


def is_public(address: str) -> bool:
    try:
        return not ipaddress.ip_address(address).is_private
    except ValueError:
        return False


def assert_lab(node: Node, lab_root: str) -> None:
    """Refuse to touch anything that could be a real host.

    Three things must all be true: the agent is in monitor mode, its firewall
    cannot reach the kernel, and both its control socket and its state directory
    sit inside the lab root the operator named.
    """
    root = os.path.realpath(os.path.abspath(os.path.expanduser(lab_root)))
    if not os.path.isdir(root):
        raise LabError(f"lab root {root} is not a directory")

    status = node.status()
    mode = status.get("mode", "")
    firewall = status.get("firewall") or {}
    backend = firewall.get("backend", "")
    socket_path = status.get("control_socket", "") or node.socket

    if mode != "monitor":
        raise LabError(f"{node.name} is in {mode!r} mode: a validation run would really block, "
                       "kill and quarantine on this host")
    if backend != "none" or not firewall.get("dry_run", False):
        raise LabError(f"{node.name} reports firewall backend {backend!r} (dry_run={firewall.get('dry_run')}): "
                       "rules would reach the kernel. Use backend 'none' for a lab")
    for label, path in (("state directory", node.state_dir), ("control socket", os.path.abspath(socket_path))):
        real = os.path.realpath(path)
        if not (real == root or real.startswith(root + os.sep)):
            raise LabError(f"{node.name}: {label} {real} is outside the lab root {root} - "
                           "this looks like a production agent, refusing to attack-test it")
        if os.path.exists(real) and not _owned_by_us(real):
            raise LabError(f"{node.name}: {label} {real} is not owned by uid {os.getuid()}")
    # The scenarios append attacker log lines here, so this file is written to as
    # surely as the state directory is - and a config can name /var/log/auth.log
    # while keeping its state dir inside a lab.
    for path in node.auth_logs:
        real = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
        if not (real == root or real.startswith(root + os.sep)):
            raise LabError(f"{node.name}: watched auth log {real} is outside the lab root {root}: "
                           "a validation run would forge entries in a real authentication log")
    node.socket = os.path.abspath(socket_path)


def _owned_by_us(path: str) -> bool:
    try:
        return os.stat(path).st_uid == os.getuid()
    except OSError:
        return False


def load_nodes(config_paths: list[str], *, timeout: float = 12.0) -> list[Node]:
    nodes = []
    for path in config_paths:
        node = Node(path, timeout=timeout)
        node.connect()
        nodes.append(node)
    return nodes


def as_json(node: Node) -> str:
    return json.dumps({"name": node.name, "socket": node.socket, "state_dir": node.state_dir})
