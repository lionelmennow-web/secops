"""Entry points: `swarmd` runs the agent, `swarmctl` drives it.

    python -m secops agent --config /etc/swarm/agent.json      # the daemon
    python -m secops control status                            # operator CLI
    python -m secops doctor                                    # self-test
    python -m secops console --node /etc/swarm/agent.json      # read-only dashboard
    python -m secops validate --lab-root .runs/demo           # attack replay
"""

from __future__ import annotations

import argparse
import os
import sys

from .agent import SwarmAgent
from .cli import main as control_main
from .config import Config, ConfigError
from .selftest import run_doctor


def run_agent(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="swarmd", description="Swarm Defense agent")
    parser.add_argument("--config", default=os.environ.get("SWARM_CONFIG", "/etc/swarm/agent.json"))
    parser.add_argument("--mode", choices=("monitor", "enforce"), default=None, help="override config mode")
    parser.add_argument("--state-dir", default=None, help="override audit/state directory")
    args = parser.parse_args(argv)

    try:
        config = Config.load(args.config) if os.path.exists(args.config) else Config.default()
    except (ConfigError, OSError) as exc:
        print(f"config error: {exc}", file=sys.stderr)
        return 2
    if args.mode:
        config.data["mode"] = args.mode
    if args.state_dir:
        config.data["audit"]["dir"] = args.state_dir
        config.data["firewall"]["state_file"] = os.path.join(args.state_dir, "blocks.json")

    if config.enforce and os.geteuid() != 0:
        print("enforce mode needs root (firewall rules, process kill, file restore). Refusing to start.", file=sys.stderr)
        return 1

    agent = SwarmAgent(config)
    agent.run_forever()
    return 0


def control(argv=None) -> int:
    return control_main(argv)


def doctor(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="swarm-doctor")
    parser.add_argument("--config", default=None)
    args = parser.parse_args(argv)
    return run_doctor(args.config)


def console(argv=None) -> int:
    from .console.cli import main as console_main

    return console_main(argv)


def validate(argv=None) -> int:
    from .validation.cli import main as validate_main

    return validate_main(argv)


COMMANDS = {
    "agent": "run the daemon (default)",
    "control": "swarmctl - drive a local agent",
    "doctor": "self-test the detection grammar and guard rails",
    "console": "read-only dashboard for the whole swarm",
    "validate": "replay the documented attacks against a lab and score them",
    "config-example": "print the default configuration as JSON",
}


def usage() -> str:
    lines = ["usage: secops [" + "|".join(COMMANDS) + "] ..."]
    lines += [f"  {name:<15} {summary}" for name, summary in COMMANDS.items()]
    lines.append("\nwith no command, secops runs the agent: secops --config /etc/swarm/agent.json")
    return "\n".join(lines)


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    # The command is picked off by hand rather than with a positional argument so
    # that `secops console --help` reaches the console's own parser instead of
    # being swallowed here.
    if argv and argv[0] in ("-h", "--help"):
        print(usage())
        return 0
    command, rest = ("agent", argv)
    if argv and not argv[0].startswith("-"):
        command, rest = argv[0], argv[1:]
    if command not in COMMANDS:
        print(f"unknown command {command!r}; try: {', '.join(COMMANDS)}", file=sys.stderr)
        return 2

    if command == "agent":
        return run_agent(rest)
    if command == "control":
        return control(rest)
    if command == "doctor":
        return doctor(rest)
    if command == "console":
        return console(rest)
    if command == "validate":
        return validate(rest)
    import json

    from .config import DEFAULTS

    print(json.dumps(DEFAULTS, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
