"""Safe posture checks: what an attacker would see, without attacking anything.

Every check here is local and non-destructive: file modes, readability, the
kernel's own socket table, and what each node reports about itself. Nothing in
this module sends a probe payload, connects to a third party, or tries an
exploit; the only outbound action is a UDP `connect()`, which sets a route
without putting a packet on the wire.
"""

from __future__ import annotations

import os
import socket
import stat
import time
from dataclasses import dataclass, field

from .. import procfs
from ..config import Config, ConfigError
from .sources import ConsoleTarget, NodeError, NodeSource

OK = "ok"
WARN = "warn"
FAIL = "fail"

# Readable by group or other, which for a key file means anyone local can teach the swarm.
LOOSE_KEY = stat.S_IRGRP | stat.S_IROTH | stat.S_IWGRP | stat.S_IWOTH
LOOSE_DIR = stat.S_IRWXG | stat.S_IRWXO


@dataclass
class Check:
    area: str
    verdict: str
    message: str
    node: str = ""

    def as_dict(self) -> dict:
        return {"area": self.area, "verdict": self.verdict, "message": self.message, "node": self.node}


@dataclass
class Posture:
    checks: list[Check] = field(default_factory=list)
    finished_at: float = field(default_factory=time.time)

    def add(self, area: str, verdict: str, message: str, node: str = "") -> None:
        self.checks.append(Check(area=area, verdict=verdict, message=message, node=node))

    def rows(self) -> list[dict]:
        order = {FAIL: 0, WARN: 1, OK: 2}
        return [check.as_dict() for check in sorted(self.checks, key=lambda item: order.get(item.verdict, 3))]


def posture_for(targets: list[ConsoleTarget], sources: list[NodeSource], serve: dict | None = None) -> list[dict]:
    posture = Posture()
    _console_surface(posture, serve or {})
    agent_pids: dict[int, str] = {}
    statuses: dict[str, dict | None] = {}

    for source in sources:
        target = source.target
        try:
            statuses[source.name] = source.status()
        except NodeError as exc:
            statuses[source.name] = None
            posture.add("node reachability", WARN, f"socket dark: {exc.detail}", source.name)

        config = _load_config(target)
        _key_permissions(posture, target, config)
        _state_directory(posture, target)
        _control_socket(posture, target)
        _watched_logs(posture, target, config)
        _integrity_targets(posture, target, config)
        _guard_expectations(posture, target, config)
        _gossip_peers(posture, target, config)
        _node_mode(posture, source.name, statuses[source.name])

        if statuses[source.name]:
            pid = int(statuses[source.name].get("pid", 0) or 0)
            if pid:
                agent_pids[pid] = source.name

    _agent_listens_on_nothing(posture, agent_pids)
    return posture.rows()


# ---- helpers ---------------------------------------------------------------
def _load_config(target: ConsoleTarget) -> Config | None:
    try:
        return Config.load(target.config_path)
    except (ConfigError, OSError, ValueError):
        return None


def _mode(path: str) -> int:
    try:
        return stat.S_IMODE(os.stat(path).st_mode)
    except OSError:
        return -1


def _console_surface(posture: Posture, serve: dict) -> None:
    host = serve.get("host", "")
    if not host:
        return
    tokened = bool(serve.get("token"))
    if host in ("127.0.0.1", "::1", "localhost"):
        posture.add("console surface", OK, f"serving on {host}:{serve.get('port')} - local only")
    elif tokened:
        posture.add("console surface", WARN,
                    f"serving on {host}:{serve.get('port')} with a token; incident evidence is "
                    "attacker-supplied text, so keep this off an untrusted network")
    else:
        posture.add("console surface", FAIL, f"serving the swarm view on {host} with no token")


def _key_permissions(posture: Posture, target: ConsoleTarget, config: Config | None) -> None:
    path = target.key_file
    mode = _mode(path)
    if mode < 0:
        posture.add("swarm key", WARN, f"{path} not readable from here; the agent may still hold it", target.name)
        return
    if mode & LOOSE_KEY:
        posture.add("swarm key", FAIL,
                    f"{path} is mode {oct(mode)}: anyone who can read it can teach this swarm, "
                    "and any host holding it is trusted by every other", target.name)
    else:
        posture.add("swarm key", OK, f"{path} is mode {oct(mode)}", target.name)


def _state_directory(posture: Posture, target: ConsoleTarget) -> None:
    mode = _mode(target.state_dir)
    if mode < 0:
        posture.add("state directory", WARN, f"{target.state_dir} missing", target.name)
    elif mode & LOOSE_DIR:
        posture.add("state directory", FAIL,
                    f"{target.state_dir} is mode {oct(mode)}: quarantined payloads and the incident "
                    "record are world-reachable", target.name)
    else:
        posture.add("state directory", OK, f"{target.state_dir} is mode {oct(mode)}", target.name)


def _control_socket(posture: Posture, target: ConsoleTarget) -> None:
    if not os.path.exists(target.socket_path):
        posture.add("control socket", WARN, f"{target.socket_path} not present (agent stopped?)", target.name)
        return
    mode = _mode(target.socket_path)
    if mode & ~stat.S_IRUSR & ~stat.S_IWUSR:
        posture.add("control socket", FAIL,
                    f"{target.socket_path} is mode {oct(mode)}: control is root-only by design, "
                    "and it has no authentication of its own", target.name)
    else:
        posture.add("control socket", OK, f"{target.socket_path} is mode {oct(mode)}", target.name)


def _watched_logs(posture: Posture, target: ConsoleTarget, config: Config | None) -> None:
    if config is None:
        return
    if not config.ssh.get("enabled", True):
        posture.add("auth log", WARN, "ssh detection is disabled in config", target.name)
        return
    for path in config.ssh.get("logs", []):
        if path.startswith("journal:"):
            continue
        if not os.path.exists(path):
            posture.add("auth log", WARN, f"{path} does not exist: the agent follows it anyway, "
                                          "but nothing is being logged there yet", target.name)
        elif not os.access(path, os.R_OK):
            posture.add("auth log", FAIL, f"{path} is not readable by uid {os.getuid()}: "
                                          "the agent needs this to detect brute force", target.name)
        else:
            posture.add("auth log", OK, f"{path} readable", target.name)


def _integrity_targets(posture: Posture, target: ConsoleTarget, config: Config | None) -> None:
    if config is None:
        return
    if not config.integrity.get("enabled", True):
        posture.add("persistence watch", WARN, "integrity detection is disabled in config", target.name)
        return
    loose = []
    missing = []
    for pattern in config.integrity.get("paths", []):
        if not os.path.exists(pattern):
            missing.append(pattern)
            continue
        mode = _mode(pattern)
        if mode & (stat.S_IWGRP | stat.S_IWOTH):
            loose.append(f"{pattern} ({oct(mode)})")
    if loose:
        posture.add("persistence watch", FAIL,
                    "writable by group/other, so any local account can edit persistence points and "
                    f"the agent would only catch it after the fact: {', '.join(loose[:6])}", target.name)
    else:
        posture.add("persistence watch", OK, f"{len(config.integrity.get('paths', []))} watched paths, none world-writable",
                    target.name)
    if missing:
        posture.add("persistence watch", WARN, f"not present yet: {', '.join(missing[:5])}", target.name)


def _guard_expectations(posture: Posture, target: ConsoleTarget, config: Config | None) -> None:
    if config is None:
        return
    guard = config.guard
    allowlist = guard.get("allowlist", [])
    if not any(entry.startswith("127.") or entry in ("::1", "127.0.0.0/8") for entry in allowlist):
        posture.add("guard rails", FAIL,
                    f"allowlist {allowlist} does not cover loopback: a brute-force report against "
                    "this host's own address would be obeyed", target.name)
    for entry in allowlist:
        if entry in ("0.0.0.0/0", "::/0"):
            posture.add("guard rails", FAIL, f"allowlist contains {entry}: nothing can ever be blocked",
                        target.name)
    if guard.get("never_kill_uids"):
        posture.add("guard rails", WARN,
                    f"config declares never_kill_uids {guard['never_kill_uids']}, but Guard.may_kill "
                    "receives the uid and never checks it: uid-based kill protection is documented, "
                    "not implemented", target.name)
    if not guard.get("protect_ssh_session", True):
        posture.add("guard rails", WARN, "protect_ssh_session is off: a false positive can kill your own login",
                    target.name)


def _gossip_peers(posture: Posture, target: ConsoleTarget, config: Config | None) -> None:
    if config is None:
        return
    peers = config.swarm.get("peers", [])
    discovery = config.swarm.get("discovery", {})
    if not peers and not discovery.get("enabled"):
        posture.add("gossip", WARN,
                    "no peers and no discovery: this agent detects and blocks alone, and an attacker "
                    "refused here is still welcome next door", target.name)
        return
    for peer in peers:
        address, port = peer.get("address", ""), int(peer.get("port", 0) or 0)
        if not address or not port:
            posture.add("gossip", FAIL, f"peer {peer!r} needs address and port", target.name)
            continue
        verdict, detail = _route_probe(address, port)
        posture.add("gossip", verdict, f"peer {peer.get('node', address)} at {address}:{port}: {detail}", target.name)


def _route_probe(address: str, port: int) -> tuple[str, str]:
    """UDP connect() picks a route and sends nothing; it is not a reachability test."""
    family = socket.AF_INET6 if ":" in address else socket.AF_INET
    probe = socket.socket(family, socket.SOCK_DGRAM)
    probe.settimeout(1.0)
    try:
        probe.connect((address, port))
        local = probe.getsockname()
        return OK, f"routed via {local[0]} (no packet sent)"
    except OSError as exc:
        return FAIL, f"no route ({exc})"
    finally:
        probe.close()


def _node_mode(posture: Posture, name: str, status: dict | None) -> None:
    if status is None:
        return
    firewall = status.get("firewall") or {}
    responder = status.get("responder") or {}
    mode = status.get("mode", "")
    planned = int(responder.get("planned_in_monitor", 0) or 0)
    executed = int(responder.get("executed", 0) or 0)
    if mode == "monitor":
        detail = (
            f"monitor mode: nothing is enforced. {planned} action(s) were planned and recorded "
            "but never reached the kernel - the block you can see in the list is a rehearsal"
            if planned
            else "monitor mode: detection and evidence only, no action reaches the kernel"
        )
        posture.add("node mode", WARN, detail, name)
    else:
        posture.add("node mode", OK, f"enforce mode: {executed} action(s) executed", name)
    if firewall.get("last_error"):
        posture.add("firewall", FAIL, f"last backend error: {firewall['last_error']}", name)
    if int(responder.get("denied_by_guard", 0) or 0):
        posture.add("guard rails", OK,
                     f"{responder['denied_by_guard']} action(s) refused by guard rails", name)


def _agent_listens_on_nothing(posture: Posture, agent_pids: dict[int, str]) -> None:
    """The design promise: an agent opens no TCP socket. If this ever fails, say so loudly."""
    if not agent_pids:
        return
    listening = []
    for family in (4, 6):
        listening += [c for c in procfs.read_tcp_connections(family) if c.state == "LISTEN"]
    if not listening:
        posture.add("agent surface", OK, "this host has no TCP listener at all", "console host")
        return
    # One /proc scan for every listener: the owner table is per-host, not per-socket.
    owners = procfs.socket_owner_index()
    if not owners:
        posture.add("agent surface", WARN,
                    f"{len(listening)} listener(s) exist but no socket is attributable to a pid from uid "
                    f"{os.getuid()}: agents run as root, so this check needs privilege to mean anything",
                    "console host")
        return
    offenders = [
        (connection, owners[connection.inode][0])
        for connection in listening
        if connection.inode in owners and owners[connection.inode][0] in agent_pids
    ]
    for connection, pid in offenders:
        posture.add("agent surface", FAIL,
                    f"pid {pid} ({agent_pids[pid]}) is listening on {connection.local}:{connection.local_port} - "
                    "the agent is documented to open no TCP port", agent_pids[pid])
    if not offenders:
        posture.add("agent surface", OK,
                    f"none of the {len(listening)} TCP listeners on this host belongs to an agent "
                    f"({len(agent_pids)} checked)", "console host")
