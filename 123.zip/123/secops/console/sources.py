"""Reading a swarm without touching it.

Everything the console asks for comes from this module, and every command it can
send is listed in READONLY: the wire command string is chosen here, never taken
from a URL, so a console bug cannot reach `do_flush` or `do_block`.
"""

from __future__ import annotations

import json
import os
import sqlite3
import urllib.parse
from dataclasses import dataclass

from ..cli import request
from ..config import Config, ConfigError

READONLY = frozenset(
    {
        "status",
        "incidents",
        "show",
        "blocks",
        "peers",
        "endpoints",
        "integrity",
        "stats",
    }
)

INCIDENT_STATES = ("open", "monitor", "noted", "resolved", "rolled_back")

LIMIT_FIELD = 200
LIMIT_DEFAULT = 25


class NodeError(Exception):
    """The node answered, or refused to; either way this pass has no data."""

    def __init__(self, node: str, detail: str) -> None:
        super().__init__(f"{node}: {detail}")
        self.node = node
        self.detail = detail


@dataclass(frozen=True)
class ConsoleTarget:
    """One agent the console will read, described by that agent's own config file."""

    name: str
    config_path: str
    socket_path: str
    state_dir: str
    key_file: str
    bind_ip: str
    bind_port: int
    address: str = ""

    @staticmethod
    def load(config_path: str, socket_path: str | None = None) -> "ConsoleTarget":
        config = Config.load(config_path)
        state_dir = config.audit["dir"]
        return ConsoleTarget(
            name=config.node_name(),
            config_path=os.path.abspath(config_path),
            socket_path=socket_path or os.path.join(state_dir, "agent.sock"),
            state_dir=state_dir,
            key_file=config.swarm["key_file"],
            bind_ip=str(config.swarm["bind_ip"]),
            bind_port=int(config.swarm["bind_port"]),
            address=str(config.data["node"].get("advertise_ip") or ""),
        )


def clamp_limit(raw, default: int = LIMIT_DEFAULT) -> int:
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return default
    return max(1, min(value, LIMIT_FIELD))


def clean_args(command: str, raw: dict | None) -> dict:
    """Validate arguments for one whitelisted command; nothing else can be sent."""
    raw = raw or {}
    if command in {"status", "peers", "blocks", "integrity", "stats"}:
        return {}
    if command == "incidents":
        state = raw.get("state")
        return {
            "limit": clamp_limit(raw.get("limit")),
            "state": state if state in INCIDENT_STATES else None,
        }
    if command == "endpoints":
        return {"limit": clamp_limit(raw.get("limit"), default=40)}
    if command == "show":
        try:
            incident_id = int(raw["id"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError("show needs an integer incident id") from exc
        if incident_id < 1:
            raise ValueError("incident id must be positive")
        return {"id": incident_id}
    raise ValueError(f"{command!r} is not a read-only command")


class NodeSource:
    """A read-only client for one agent's control socket."""

    def __init__(self, target: ConsoleTarget, timeout: float = 4.0) -> None:
        self.target = target
        self.timeout = timeout

    @property
    def name(self) -> str:
        return self.target.name

    def query(self, command: str, args: dict | None = None) -> object:
        if command not in READONLY:
            raise ValueError(f"refusing to send non read-only command {command!r}")
        payload = {"command": command, "args": clean_args(command, args)}
        reply = request(payload, self.target.socket_path, timeout=self.timeout)
        if not reply.get("ok"):
            raise NodeError(self.name, str(reply.get("error", "no reply")))
        return reply.get("result")

    def status(self) -> dict:
        result = self.query("status")
        # An agent knows where its own socket is; believe it over our guess.
        reported = (result or {}).get("control_socket")
        if reported and reported != self.target.socket_path and os.path.exists(reported):
            object.__setattr__(self.target, "socket_path", reported)
        return result

    def incidents(self, limit: int = LIMIT_DEFAULT, state: str | None = None) -> list[dict]:
        return list(self.query("incidents", {"limit": limit, "state": state}) or [])

    def show(self, incident_id: int) -> dict | None:
        return self.query("show", {"id": incident_id})

    def blocks(self) -> list[dict]:
        return list(self.query("blocks") or [])

    def integrity(self) -> dict:
        return dict(self.query("integrity") or {})

    def endpoints(self, limit: int = 40) -> dict:
        return dict(self.query("endpoints", {"limit": limit}) or {})

    def stats(self) -> dict:
        return dict(self.query("stats") or {})

    def peers(self) -> dict:
        return dict(self.query("peers") or {})


def database_path(state_dir: str) -> str:
    return os.path.join(state_dir, "incidents.db")


def read_incidents(state_dir: str, limit: int = 30, state: str | None = None) -> list[dict]:
    """Fall back to the incident record itself when the socket is dark."""
    path = database_path(state_dir)
    if not os.path.exists(path):
        return []
    query = "SELECT * FROM incidents"
    args: list = []
    if state in INCIDENT_STATES:
        query += " WHERE state=?"
        args.append(state)
    query += " ORDER BY id DESC LIMIT ?"
    args.append(clamp_limit(limit))
    try:
        connection = _open_readonly(path)
    except sqlite3.Error:
        return []
    try:
        rows = connection.execute(query, args).fetchall()
    except sqlite3.Error:
        return []
    finally:
        connection.close()
    out = []
    for row in rows:
        item = dict(row)
        for key in ("process_json", "details_json"):
            value = item.get(key)
            item[key[:-5]] = json.loads(value) if value else None
            item.pop(key, None)
        out.append(item)
    return out


def read_key(path: str) -> bytes:
    with open(path, "rb") as fh:
        return fh.read().strip()


def _open_readonly(path: str) -> sqlite3.Connection:
    uri = "file:" + urllib.parse.quote(path, safe="/?") + "?mode=ro"
    connection = sqlite3.connect(uri, uri=True, timeout=1.0)
    connection.row_factory = sqlite3.Row
    return connection


def discover(pattern_dirs: list[str]) -> list[ConsoleTarget]:
    """Find agent config files to watch, so a lab directory is enough to get going."""
    targets: list[ConsoleTarget] = []
    seen: set[str] = set()
    for directory in pattern_dirs:
        if not os.path.isdir(directory):
            continue
        for entry in sorted(os.listdir(directory)):
            if not entry.endswith(".json") or entry.endswith("-blocks.json") or entry.endswith("-endpoints.json"):
                continue
            path = os.path.join(directory, entry)
            try:
                target = ConsoleTarget.load(path)
            except (ConfigError, OSError, KeyError, ValueError):
                continue
            if target.name in seen:
                continue
            seen.add(target.name)
            targets.append(target)
    return targets
