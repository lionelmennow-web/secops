"""Operator console and attack validation for Swarm Defense.

Neither package is imported by the agent, and neither adds a socket to it: the
console is a separate process an operator runs, and it only ever asks agents
read-only questions over their existing Unix socket.
"""
