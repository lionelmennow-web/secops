"""The console's view of the swarm: nodes, attacks, addresses, reconciled.

An incident id is only unique inside the node that wrote it (`id` is a per-node
AUTOINCREMENT), so node-scoped identity is `(node, id)` and the swarm-wide
identity is the signature id the nodes now share.
"""

from __future__ import annotations

import ipaddress
import time
from dataclasses import dataclass, field

from ..signals import BOTH

LINK_EXACT = "exact"
LINK_FUZZY = "fuzzy"
LINK_NONE = "none"

LINK_ORDER = {LINK_NONE: 0, LINK_FUZZY: 1, LINK_EXACT: 2}


@dataclass
class Node:
    """One agent, as far as the console can tell."""

    name: str
    address: str = ""
    socket_path: str = ""
    state_dir: str = ""
    alive: bool = False
    error: str = ""
    mode: str = ""
    backend: str = ""
    dry_run: bool = False
    rules: int = 0
    last_firewall_error: str = ""
    uptime: float = 0.0
    pid: int = 0
    last_seen_at: float = 0.0
    peers: list[str] = field(default_factory=list)
    isolated: list[str] = field(default_factory=list)
    gossip: dict = field(default_factory=dict)
    counters: dict = field(default_factory=dict)
    responder: dict = field(default_factory=dict)
    guard_refusals: int = 0
    watchers: dict = field(default_factory=dict)
    audit: dict = field(default_factory=dict)
    endpoints: dict = field(default_factory=dict)
    poller_errors: list = field(default_factory=list)
    recent: list[dict] = field(default_factory=list)

    @property
    def acting(self) -> bool:
        return self.mode == "enforce" and not self.dry_run

    @staticmethod
    def dead(name: str, socket_path: str = "", state_dir: str = "", error: str = "") -> "Node":
        return Node(name=name, socket_path=socket_path, state_dir=state_dir, alive=False, error=error)

    @staticmethod
    def from_status(name: str, status: dict, *, socket_path: str = "", state_dir: str = "") -> "Node":
        firewall = status.get("firewall") or {}
        swarm = status.get("swarm") or {}
        responder = status.get("responder") or {}
        return Node(
            name=status.get("node") or name,
            address=status.get("address", ""),
            socket_path=status.get("control_socket") or socket_path,
            state_dir=state_dir,
            alive=True,
            mode=status.get("mode", ""),
            backend=firewall.get("backend", ""),
            dry_run=bool(firewall.get("dry_run")),
            rules=int(firewall.get("rules", 0) or 0),
            last_firewall_error=firewall.get("last_error") or "",
            uptime=float(status.get("uptime", 0.0) or 0.0),
            pid=int(status.get("pid", 0) or 0),
            last_seen_at=time.time(),
            peers=list(swarm.get("peers") or []),
            isolated=list(swarm.get("isolated") or []),
            gossip=dict(swarm.get("gossip") or {}),
            counters=dict(swarm.get("counters") or {}),
            responder=dict(responder),
            guard_refusals=int(responder.get("guard_refusals", 0) or 0),
            watchers=dict(status.get("watchers") or {}),
            audit=dict(status.get("audit") or {}),
            poller_errors=list(status.get("poller_errors") or []),
            recent=list(status.get("recent") or []),
        )


@dataclass
class Attack:
    """One incident on one node."""

    node: str
    incident_id: int
    ts: float
    updated_at: float
    attack: str
    subject: str
    tag: str
    direction: str
    severity: int
    hits: int
    state: str
    origin: str
    evidence: str
    ttl: float = 0.0
    sig_id: str = ""
    link: str = LINK_NONE
    actions: list[dict] = field(default_factory=list)
    process: dict | None = None
    details: dict = field(default_factory=dict)

    @property
    def key(self) -> str:
        return f"{self.node}:{self.incident_id}"

    @staticmethod
    def from_row(row: dict) -> "Attack":
        return Attack(
            node=row.get("node", ""),
            incident_id=int(row.get("id", 0)),
            ts=float(row.get("ts", 0.0) or 0.0),
            updated_at=float(row.get("updated_at", 0.0) or 0.0),
            attack=row.get("attack", ""),
            subject=row.get("subject", ""),
            tag=row.get("tag", ""),
            direction=row.get("direction", ""),
            severity=int(row.get("severity", 0) or 0),
            hits=int(row.get("hits", 1) or 1),
            state=row.get("state", ""),
            origin=row.get("origin", ""),
            evidence=row.get("evidence", "") or "",
            ttl=float(row.get("ttl", 0.0) or 0.0),
            sig_id=row.get("sig_id", "") or "",
            process=row.get("process"),
            details=row.get("details") or {},
        )


@dataclass
class Seen:
    """A signature the observer overheard. Recorded, never applied."""

    sig_id: str
    reported_by: str
    subject: str
    attack: str
    tag: str
    direction: str
    ttl: float
    ts: float
    hop: int
    ports: list[int]
    reason: str
    sender: str
    received_at: float
    expires_at: float
    verified: bool = True
    note: str = ""

    @staticmethod
    def from_signature(sig, sender: str, received_at: float, note: str = "accepted") -> "Seen":
        return Seen(
            sig_id=sig.id,
            reported_by=sig.node,
            subject=sig.subject,
            attack=sig.attack,
            tag=sig.tag,
            direction=sig.direction,
            ttl=sig.ttl,
            ts=sig.ts,
            hop=sig.hop,
            ports=list(sig.ports),
            reason=sig.reason,
            sender=sender,
            received_at=received_at,
            expires_at=sig.expires_at(),
            verified=True,
            note=note,
        )


@dataclass
class Block:
    """One firewall rule, on one node."""

    node: str
    address: str
    cidr: str
    direction: str
    reason: str
    source: str
    created_at: float
    expires_at: float
    sig_id: str = ""
    ports: list[int] = field(default_factory=list)

    @property
    def remaining(self) -> float:
        return max(0.0, self.expires_at - time.time())

    @staticmethod
    def from_rule(node: str, rule: dict) -> "Block":
        return Block(
            node=node,
            address=rule.get("address", ""),
            cidr=rule.get("cidr", ""),
            direction=rule.get("direction", ""),
            reason=rule.get("reason", "") or "",
            source=rule.get("source", "") or "",
            created_at=float(rule.get("created_at", 0.0) or 0.0),
            expires_at=float(rule.get("expires_at", 0.0) or 0.0),
            sig_id=rule.get("sig_id", "") or "",
            ports=list(rule.get("ports") or []),
        )


@dataclass
class Aggregated:
    """Every node's opinion about one subject, side by side."""

    subject: str
    kind: str = "address"
    attacks: list[str] = field(default_factory=list)
    nodes: list[str] = field(default_factory=list)
    origins: list[str] = field(default_factory=list)
    first_seen: float = 0.0
    last_seen: float = 0.0
    hits: int = 0
    severity: int = 0
    states: list[str] = field(default_factory=list)
    blocked_on: dict[str, str] = field(default_factory=dict)
    sig_ids: list[str] = field(default_factory=list)
    overheard: bool = False

    @property
    def coverage(self) -> str:
        if self.blocked_on:
            return "blocked"
        if self.nodes:
            return "recorded"
        return "overheard"


@dataclass
class Snapshot:
    """One pass of the whole swarm, ready to serialize."""

    generated_at: float = field(default_factory=time.time)
    nodes: list[Node] = field(default_factory=list)
    attacks: list[Attack] = field(default_factory=list)
    blocks: list[Block] = field(default_factory=list)
    seen: list[Seen] = field(default_factory=list)
    aggregated: list[Aggregated] = field(default_factory=list)
    posture: list[dict] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    observer: dict = field(default_factory=dict)

    def index(self) -> dict[str, Node]:
        return {node.name: node for node in self.nodes}

    def as_dict(self) -> dict:
        by_state: dict[str, int] = {}
        for attack in self.attacks:
            by_state[attack.state or "unknown"] = by_state.get(attack.state or "unknown", 0) + 1
        return {
            "generated_at": self.generated_at,
            "nodes": [as_row(node) for node in self.nodes],
            "attacks": [as_row(attack) for attack in self.attacks],
            "blocks": [as_row(block) for block in self.blocks],
            "seen": [as_row(entry) for entry in self.seen],
            "aggregated": [as_row(entry) for entry in self.aggregated],
            "posture": self.posture,
            "errors": self.errors,
            "observer": self.observer,
            "counts": {
                "nodes": len(self.nodes),
                "alive": sum(1 for node in self.nodes if node.alive),
                "attacks": len(self.attacks),
                "by_state": by_state,
                "blocks": len(self.blocks),
                "subjects": len(self.aggregated),
                "overheard": len(self.seen),
                "enforcing": sum(1 for node in self.nodes if node.acting),
            },
        }


def as_row(item) -> dict:
    """Dataclass to plain JSON, with the computed properties the UI needs."""
    row = {key: getattr(item, key) for key in item.__dataclass_fields__}
    if isinstance(item, Block):
        row["remaining"] = item.remaining
    if isinstance(item, Node):
        row["acting"] = item.acting
    if isinstance(item, Aggregated):
        row["coverage"] = item.coverage
    return row


def aggregate(attacks: list[Attack], blocks: list[Block], seen: list[Seen]) -> list[Aggregated]:
    """Collapse per-node incidents into one row per subject, without merging incidents."""
    rows: dict[str, Aggregated] = {}

    def entry(subject: str) -> Aggregated:
        row = rows.get(subject)
        if row is None:
            row = Aggregated(subject=subject, kind="address" if _is_address(subject) else "path")
            rows[subject] = row
        return row

    for attack in attacks:
        row = entry(attack.subject)
        if attack.attack not in row.attacks:
            row.attacks.append(attack.attack)
        if attack.node not in row.nodes:
            row.nodes.append(attack.node)
        if attack.origin and attack.origin not in row.origins:
            row.origins.append(attack.origin)
        if attack.state and attack.state not in row.states:
            row.states.append(attack.state)
        if attack.sig_id and attack.sig_id not in row.sig_ids:
            row.sig_ids.append(attack.sig_id)
        row.first_seen = attack.ts if not row.first_seen else min(row.first_seen, attack.ts)
        row.last_seen = max(row.last_seen, attack.updated_at or attack.ts)
        row.hits += max(attack.hits, 1)
        row.severity = max(row.severity, attack.severity)

    for block in blocks:
        row = entry(block.address)
        if block.sig_id and block.sig_id not in row.sig_ids:
            row.sig_ids.append(block.sig_id)
        merged = row.blocked_on.get(block.node, "")
        row.blocked_on[block.node] = _merge_directions(merged, block.direction)

    sig_ids = {entry.sig_id for entry in seen}
    for attack in attacks:
        attack.link = LINK_EXACT if attack.sig_id and attack.sig_id in sig_ids else _fuzzy_link(attack, seen)

    for overheard in seen:
        row = entry(overheard.subject)
        row.overheard = True
        if overheard.attack not in row.attacks:
            row.attacks.append(overheard.attack)
        if overheard.sig_id not in row.sig_ids:
            row.sig_ids.append(overheard.sig_id)
        row.last_seen = max(row.last_seen, overheard.ts)
        for block in blocks:
            if block.node == overheard.reported_by and _covers(block, overheard.subject):
                merged = row.blocked_on.get(block.node, "")
                row.blocked_on[block.node] = _merge_directions(merged, block.direction)

    return sorted(rows.values(), key=lambda row: (-row.severity, -row.last_seen))


def _fuzzy_link(attack: Attack, seen: list[Seen]) -> str:
    if not attack.subject:
        return LINK_NONE
    for entry in seen:
        if (
            entry.subject == attack.subject
            and entry.attack == attack.attack
            and entry.reported_by in {attack.node, attack.origin.removeprefix("peer:")}
            and abs(entry.ts - attack.ts) < 60.0
        ):
            return LINK_FUZZY
    return LINK_NONE


def _covers(block: Block, subject: str) -> bool:
    if block.address == subject or block.cidr == subject:
        return True
    if not _is_address(subject):
        return False
    try:
        network = ipaddress.ip_network(block.cidr, strict=False)
    except ValueError:
        return False
    try:
        return ipaddress.ip_address(subject) in network
    except ValueError:
        return False


def _merge_directions(current: str, addition: str) -> str:
    parts = {p for p in (current, addition) if p}
    if {"in", "out"} <= parts or BOTH in parts:
        return BOTH
    return parts.pop() if parts else addition


def _is_address(value: str) -> bool:
    try:
        ipaddress.ip_address(value.split("/")[0])
    except ValueError:
        return False
    return True
