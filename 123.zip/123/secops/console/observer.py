"""A receive-only subscriber to the swarm's gossip.

The console otherwise sees only what the agents chose to write to their own
databases, so a threat reported by node A to node B is invisible here unless B
happens to be reachable. The observer listens on the gossip wire directly and
*records* what it hears.

It is receive-only by construction, not by convention:

* it composes `GossipTransport` with no peers, so `broadcast()` has nobody to
  send to even if something called it;
* `on_signature` returns False, so the transport never reaches `_forward`;
* `_forward` is overridden as a no-op, so a future change to the transport
  cannot turn this into a repeater by accident;
* there is no `broadcast` or `send_raw` call site in this module, and the socket
  it owns is created and used by the transport's receive loop only.

Nothing it hears is applied, blocked, taught, or written to a node. It is
evidence for the dashboard and nothing else.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from typing import TYPE_CHECKING

from ..transport import GossipTransport
from .model import Seen

if TYPE_CHECKING:  # pragma: no cover - annotation only
    from ..signature import ThreatSignature

RECENT_LIMIT = 200
REJECTION_LIMIT = 50


def _never_relay(sig: object, sender: tuple[str, int]) -> None:
    """Replaces the transport's re-broadcast path. An observer is not a hop."""
    return None


class GossipObserver:
    def __init__(self, bind: tuple[str, int], key: bytes, *, multicast: tuple[str, int] | None = None) -> None:
        self.bind = bind
        self.started_at = 0.0
        # `peers=[]` is the whole safety argument: there is no address to send to.
        self.transport = GossipTransport(bind=bind, key=key, on_signature=self._on_signature,
                                         peers=[], multicast=multicast)
        # The transport re-broadcasts from its own `_forward`, which stays unreachable
        # as long as the callback below returns False. Neutering it here means the
        # receive-only promise does not depend on that one return value.
        self.transport._forward = _never_relay
        self._recent: deque[Seen] = deque(maxlen=RECENT_LIMIT)
        self._rejects: deque[dict] = deque(maxlen=REJECTION_LIMIT)
        self._lock = threading.Lock()
        self._running = False

    # ---- lifecycle ---------------------------------------------------------
    def start(self) -> None:
        self.transport.start()
        self.started_at = time.time()
        self._running = True

    def stop(self) -> None:
        self._running = False
        self.transport.stop()

    @property
    def running(self) -> bool:
        return self._running

    # ---- the receive-only callback -----------------------------------------
    def _on_signature(self, sig: ThreatSignature | None, sender: tuple[str, int], note: str) -> bool:
        """Record and refuse. Returning False is what keeps `_forward` unreachable."""
        if sig is None:
            # The transport hands us None for malformed or unauthenticated packets; the
            # raw bytes were never parsed, so all we can keep is where they came from.
            self._rejects.appendleft({"sender": f"{sender[0]}:{sender[1]}", "note": note, "ts": time.time()})
            return False
        with self._lock:
            self._recent.appendleft(Seen.from_signature(sig, f"{sender[0]}:{sender[1]}", time.time(), note=note))
        return False

    # ---- what the dashboard reads ------------------------------------------
    def recent(self) -> list[Seen]:
        with self._lock:
            return list(self._recent)

    def rejections(self) -> list[dict]:
        return list(self._rejects)

    def stats(self) -> dict:
        stats = self.transport.stats.as_dict()
        stats["listening"] = f"{self.bind[0]}:{self.bind[1]}"
        stats["running"] = self._running
        stats["recent"] = len(self.recent())
        stats["rejections"] = self.rejections()[:5]
        stats["since"] = self.started_at
        return stats

    def describe(self) -> str:
        stats = self.stats()
        return (f"observer on {stats['listening']}: received {stats['received']}, "
                f"kept {stats['recent']}, rejected shape/auth "
                f"{stats['rejected_shape']}/{stats['rejected_auth']}, "
                f"sent {stats['sent']}, forwarded {stats['forwarded']}")
