"""The console's HTTP face: loopback by default, read-only by construction.

Paths map to fixed handlers; the wire command string is chosen in `sources.py`,
never taken from the URL, so there is no route that can reach a mutating agent
command even by mistake.
"""

from __future__ import annotations

import hmac
import ipaddress
import json
import os
import queue
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from .sources import NodeError

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")

# No inline script or style anywhere, so a stray HTML sink cannot execute.
CSP = "default-src 'none'; style-src 'self'; script-src 'self'; connect-src 'self'; img-src 'self'"

TOKEN_HEADER = "X-Swarm-Token"
SSE_KEEPALIVE = 15.0

ASSETS = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/console.css": ("console.css", "text/css; charset=utf-8"),
    "/console.js": ("console.js", "application/javascript; charset=utf-8"),
    "/favicon.ico": (None, None),
}


def is_loopback(host: str) -> bool:
    if host in ("", "localhost", "::1"):
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


class Console:
    """Serves the cached swarm view over a small, fixed set of read-only routes."""

    def __init__(self, watch, *, token: str = "", static_dir: str = STATIC_DIR) -> None:
        self.watch = watch
        self.token = token
        self.static_dir = static_dir
        self.stop_event = threading.Event()

    # ---- routes ------------------------------------------------------------
    def route(self, path: str, query: dict):
        if not path.startswith("/api/"):
            return None
        snapshot = self.watch.latest()
        if path == "/api/snapshot":
            return snapshot.as_dict()
        if path == "/api/nodes":
            return {"nodes": snapshot.as_dict()["nodes"]}
        if path == "/api/attacks":
            return {"attacks": snapshot.as_dict()["attacks"]}
        if path == "/api/blocks":
            return {"blocks": snapshot.as_dict()["blocks"]}
        if path == "/api/subjects":
            return {"subjects": snapshot.as_dict()["aggregated"]}
        if path == "/api/posture":
            return {"posture": snapshot.as_dict()["posture"]}
        if path == "/api/health":
            return {
                "ok": True,
                "passes": self.watch.passes,
                "poll_error": self.watch.last_error,
                "generated_at": snapshot.generated_at,
            }
        if path == "/api/incident":
            node = (query.get("node") or [""])[0]
            raw_id = (query.get("id") or [""])[0]
            try:
                incident_id = int(raw_id)
            except ValueError:
                return HTTPStatus.BAD_REQUEST, {"error": "id must be an integer"}
            if not node:
                return HTTPStatus.BAD_REQUEST, {"error": "node is required"}
            detail = self.watch.detail(node, incident_id)
            if detail.get("incident") is None:
                return HTTPStatus.NOT_FOUND, detail
            return detail
        return None

    def authorized(self, header_token: str, query: dict) -> bool:
        if not self.token:
            return True
        supplied = header_token or (query.get("token") or [""])[0]
        if not supplied:
            return False
        # compare_digest refuses non-ASCII str, so a browser-unicode token would raise
        # instead of answering 403; bytes comparison accepts any input.
        return hmac.compare_digest(supplied.encode("utf-8"), self.token.encode("utf-8"))

    # ---- streaming ---------------------------------------------------------
    def stream(self, handler) -> None:
        client = self.watch.subscribe()
        try:
            handler.send_response(HTTPStatus.OK)
            handler.send_header("Content-Type", "text/event-stream; charset=utf-8")
            handler.send_header("Cache-Control", "no-cache")
            handler.send_header("X-Accel-Buffering", "no")
            handler.end_headers()
            self._event(handler, "snapshot", self.watch.latest().as_dict())
            while not self.stop_event.is_set() and not handler.server._closing:
                try:
                    payload = client.get(timeout=SSE_KEEPALIVE)
                except queue.Empty:
                    handler.wfile.write(b": keepalive\n\n")
                    handler.wfile.flush()
                    continue
                if payload is None:
                    break
                self._event(handler, "snapshot", payload)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            self.watch.unsubscribe(client)

    @staticmethod
    def _event(handler, name: str, payload) -> None:
        body = json.dumps(payload, default=str)
        blob = f"event: {name}\ndata: {body}\n\n".encode("utf-8", "replace")
        handler.wfile.write(blob)
        handler.wfile.flush()

    def asset(self, name: str) -> bytes | None:
        path = os.path.join(self.static_dir, name)
        resolved = os.path.realpath(path)
        if not resolved.startswith(os.path.realpath(self.static_dir) + os.sep):
            return None
        try:
            with open(resolved, "rb") as handle:
                return handle.read()
        except OSError:
            return None


class Handler(BaseHTTPRequestHandler):
    server_version = "SwarmConsole/1.0"
    protocol_version = "HTTP/1.1"

    @property
    def console(self) -> Console:
        return self.server.console  # type: ignore[attr-defined]

    def do_GET(self) -> None:  # noqa: N802 - stdlib naming
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        path = parsed.path

        if not self.console.authorized(self.headers.get(TOKEN_HEADER, ""), query):
            self._json(HTTPStatus.FORBIDDEN, {"error": "missing or wrong console token"})
            return

        if path in ASSETS:
            self._static(path)
            return
        if path == "/stream":
            self.console.stream(self)
            return

        result = self.console.route(path, query)
        if result is None:
            self._json(HTTPStatus.NOT_FOUND, {"error": "no such route"})
            return
        if isinstance(result, tuple):
            status, body = result
            self._json(status, body)
            return
        self._json(HTTPStatus.OK, result)

    def _static(self, path: str) -> None:
        entry = ASSETS[path]
        if entry[0] is None:
            self.send_error(HTTPStatus.NO_CONTENT)
            return
        body = self.console.asset(entry[0])
        if body is None:
            self._json(HTTPStatus.NOT_FOUND, {"error": "asset missing"})
            return
        self.send_response(HTTPStatus.OK)
        self._security_headers()
        self.send_header("Content-Type", entry[1])
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: HTTPStatus, body) -> None:
        encoded = json.dumps(body, default=str).encode("utf-8", "replace")
        self.send_response(status)
        self._security_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def _security_headers(self) -> None:
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")

    def log_message(self, format: str, *args) -> None:
        if os.environ.get("SWARM_CONSOLE_VERBOSE"):
            super().log_message(format, *args)


class ConsoleServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], console: Console) -> None:
        self.console = console
        self._closing = False
        super().__init__(address, Handler)

    def server_close(self) -> None:
        self._closing = True
        self.console.stop_event.set()
        super().server_close()


def build_server(host: str, port: int, console: Console) -> ConsoleServer:
    if not is_loopback(host) and not console.token:
        raise ValueError(
            f"refusing to serve the swarm view on {host}: a non-loopback console needs --token "
            "(or SWARM_CONSOLE_TOKEN), because the incident evidence in it is attacker-supplied text"
        )
    return ConsoleServer((host, port), console)


def serve_forever(server: ConsoleServer) -> None:
    thread = threading.Thread(target=server.serve_forever, name="console-http", daemon=True)
    thread.start()
