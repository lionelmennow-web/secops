"""Assembling one pass of the swarm view from read-only node queries."""

from __future__ import annotations

import queue
import threading
import time

from .model import Attack, Block, Node, Seen, Snapshot, aggregate
from .sources import NodeError, NodeSource, read_incidents


def build_snapshot(sources: list[NodeSource], seen: list[Seen] | None = None,
                   posture: list[dict] | None = None, incident_limit: int = 50,
                   observer: dict | None = None) -> Snapshot:
    snapshot = Snapshot(generated_at=time.time(), seen=list(seen or []), posture=list(posture or []),
                        observer=dict(observer or {}))
    attacks: list[Attack] = []
    blocks: list[Block] = []

    for source in sources:
        target = source.target
        try:
            status = source.status()
        except NodeError as exc:
            snapshot.nodes.append(Node.dead(target.name, target.socket_path, target.state_dir, exc.detail))
            rows = read_incidents(target.state_dir, limit=incident_limit)
            if rows:
                attacks.extend(Attack.from_row(row) for row in rows)
                snapshot.errors.append(
                    f"{target.name}: socket dark, recovered {len(rows)} incidents from its incident record"
                )
            else:
                snapshot.errors.append(f"{target.name}: unreachable - {exc.detail}")
            continue

        node = Node.from_status(target.name, status, socket_path=target.socket_path, state_dir=target.state_dir)
        snapshot.nodes.append(node)

        try:
            attacks.extend(Attack.from_row(row) for row in source.incidents(limit=incident_limit))
        except NodeError as exc:
            snapshot.errors.append(f"{node.name}: incidents failed - {exc.detail}")

        try:
            blocks.extend(Block.from_rule(node.name, rule) for rule in source.blocks())
        except NodeError as exc:
            snapshot.errors.append(f"{node.name}: blocks failed - {exc.detail}")

        try:
            node.endpoints = source.endpoints()
        except NodeError as exc:
            snapshot.errors.append(f"{node.name}: endpoints failed - {exc.detail}")

    snapshot.attacks = sorted(attacks, key=lambda attack: attack.ts, reverse=True)
    snapshot.blocks = sorted(blocks, key=lambda block: block.expires_at, reverse=True)
    snapshot.aggregated = aggregate(snapshot.attacks, snapshot.blocks, snapshot.seen)
    return snapshot


class SwarmWatch:
    """Poll the swarm on a cadence and hand the newest snapshot to any reader.

    Subscribers get the whole snapshot, not a patch, but only when something
    actually changed: a few nodes fit in one small JSON body, and re-sending it
    beats getting an incremental diff wrong.
    """

    def __init__(self, sources: list[NodeSource], *, observer=None, posture=None,
                 interval: float = 2.0, posture_interval: float = 15.0,
                 incident_limit: int = 50) -> None:
        self.sources = sources
        self.observer = observer
        self.posture = posture
        self.interval = max(0.5, float(interval))
        self.posture_interval = max(1.0, float(posture_interval))
        self.incident_limit = incident_limit
        self.passes = 0
        self.last_error = ""
        self._latest = Snapshot()
        self._fingerprint = ""
        self._posture_rows: list[dict] = []
        self._posture_at = 0.0
        self._lock = threading.Lock()
        self._subscribers: set[queue.Queue] = set()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self.refresh()
        self._thread = threading.Thread(target=self._run, name="swarm-watch", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3.0)
        with self._lock:
            for client in list(self._subscribers):
                client.put(None)
            self._subscribers.clear()

    def latest(self) -> Snapshot:
        with self._lock:
            return self._latest

    def detail(self, node_name: str, incident_id: int) -> dict:
        for source in self.sources:
            if source.name != node_name:
                continue
            try:
                return {"node": node_name, "incident": source.show(incident_id)}
            except NodeError as exc:
                return {"node": node_name, "error": exc.detail, "incident": None}
        return {"node": node_name, "error": "no such node", "incident": None}

    def subscribe(self) -> queue.Queue:
        client: queue.Queue = queue.Queue(maxsize=4)
        with self._lock:
            self._subscribers.add(client)
        return client

    def unsubscribe(self, client: queue.Queue) -> None:
        with self._lock:
            self._subscribers.discard(client)

    def refresh(self) -> Snapshot:
        seen = list(self.observer.recent()) if self.observer is not None else []
        observer = dict(self.observer.stats()) if self.observer is not None else {}
        if self.posture is not None and time.time() - self._posture_at >= self.posture_interval:
            try:
                self._posture_rows = list(self.posture())
                self._posture_at = time.time()
            except Exception as exc:  # posture must never blank the dashboard
                self.last_error = f"posture: {type(exc).__name__}: {exc}"[:200]
        snapshot = build_snapshot(self.sources, seen=seen, posture=self._posture_rows,
                                  incident_limit=self.incident_limit, observer=observer)
        fingerprint = self._fingerprint_for(snapshot)
        changed = fingerprint != self._fingerprint
        with self._lock:
            self._latest = snapshot
            self._fingerprint = fingerprint
            clients = list(self._subscribers)
        self.passes += 1
        if changed:
            self._publish(snapshot.as_dict(), clients)
        return snapshot

    @staticmethod
    def _fingerprint_for(snapshot: Snapshot) -> str:
        newest = snapshot.attacks[0].key if snapshot.attacks else "-"
        # Countdown of a rule's TTL is not a change worth publishing; reap does it.
        blocks = "|".join(f"{block.node}:{block.cidr}:{block.direction}" for block in snapshot.blocks)
        overheard = ",".join(entry.sig_id for entry in snapshot.seen[-10:])
        refused = snapshot.observer.get("rejected_shape", 0) + snapshot.observer.get("rejected_auth", 0)
        rules = sum(node.rules for node in snapshot.nodes)
        alive = ",".join(node.name for node in snapshot.nodes if node.alive)
        posture = len(snapshot.posture)
        return f"{len(snapshot.attacks)}|{newest}|{rules}|{alive}|{overheard}|{refused}|{blocks}|{posture}"

    def _publish(self, payload: dict, clients: list[queue.Queue]) -> None:
        for client in clients:
            try:
                client.put_nowait(payload)
            except queue.Full:
                # A stalled browser must not slow the poller or grow memory.
                try:
                    client.get_nowait()
                    client.put_nowait(payload)
                except (queue.Empty, queue.Full):
                    pass

    def _run(self) -> None:
        while not self._stop.wait(self.interval):
            try:
                self.refresh()
            except Exception as exc:  # one bad node must not stop the watch
                self.last_error = f"{type(exc).__name__}: {exc}"[:200]
