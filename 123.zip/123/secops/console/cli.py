"""`swarmconsole` - read-only operator view of the swarm.

Runs as its own process. The agents it reads are unchanged and still open no
TCP port: this binds a loopback HTTP socket on the machine the operator chose.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

from .server import Console, build_server, is_loopback, serve_forever
from .snapshot import SwarmWatch
from .sources import ConsoleTarget, NodeSource, discover, read_key

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8786


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="swarmconsole",
        description="Read-only dashboard for a swarm. Never mutates a node.",
    )
    parser.add_argument("--node", dest="nodes", action="append", default=[],
                        metavar="AGENT_JSON", help="an agent config file to read (repeatable)")
    parser.add_argument("--discover", action="append", default=[], metavar="DIR",
                        help="read every agent config in DIR (repeatable)")
    parser.add_argument("--host", default=os.environ.get("SWARM_CONSOLE_HOST", DEFAULT_HOST))
    parser.add_argument("--port", type=int, default=int(os.environ.get("SWARM_CONSOLE_PORT", DEFAULT_PORT)))
    parser.add_argument("--token", default=os.environ.get("SWARM_CONSOLE_TOKEN", ""),
                        help="required if --host is not loopback")
    parser.add_argument("--interval", type=float, default=2.0, help="swarm poll interval, seconds")
    parser.add_argument("--limit", type=int, default=50, help="incidents to keep per node")
    parser.add_argument("--timeout", type=float, default=4.0, help="per-node query timeout")
    parser.add_argument("--observe-port", type=int, default=0,
                        help="also listen for gossip on this UDP port (0 disables the observer)")
    parser.add_argument("--observe-ip", default=DEFAULT_HOST)
    parser.add_argument("--key", default="", help="swarm key for signature verification")
    parser.add_argument("--no-posture", action="store_true", help="skip the local posture checks")
    parser.add_argument("--dump", action="store_true", help="print one snapshot as JSON and exit")
    parser.add_argument("--quiet", action="store_true")
    return parser


def collect_targets(args) -> list[ConsoleTarget]:
    targets: list[ConsoleTarget] = []
    for path in args.nodes:
        try:
            targets.append(ConsoleTarget.load(path))
        except Exception as exc:
            raise SystemExit(f"cannot read agent config {path}: {exc}")
    for directory in args.discover:
        targets.extend(discover([directory]))
    unique: dict[str, ConsoleTarget] = {}
    for target in targets:
        unique.setdefault(target.name, target)
    return list(unique.values())


def resolve_key(args, targets: list[ConsoleTarget]) -> bytes:
    path = args.key or (targets[0].key_file if targets else "")
    if not path:
        raise SystemExit("no swarm key: pass --key or at least one --node config")
    try:
        return read_key(path)
    except OSError as exc:
        raise SystemExit(f"cannot read swarm key {path}: {exc}")


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    targets = collect_targets(args)
    if not targets:
        print("no nodes to read: pass --node AGENT_JSON or --discover DIR", file=sys.stderr)
        return 2

    sources = [NodeSource(target, timeout=args.timeout) for target in targets]
    observer = None
    if args.observe_port:
        from .observer import GossipObserver

        key = resolve_key(args, targets)
        observer = GossipObserver(bind=(args.observe_ip, args.observe_port), key=key)
        try:
            observer.start()
        except OSError as exc:
            print(f"observer could not bind {args.observe_ip}:{args.observe_port}: {exc}", file=sys.stderr)
            print("continuing with socket data only", file=sys.stderr)
            observer = None

    # `build_server` already refuses a non-loopback bind without a token, so this is
    # a record of what was served, not the enforcement itself.
    serve = {"host": args.host, "port": args.port, "token": args.token}
    posture = None
    if not args.no_posture:
        from .audit_host import posture_for

        def posture() -> list[dict]:
            return posture_for(targets, sources, serve=serve)

    watch = SwarmWatch(sources, observer=observer, posture=posture,
                       interval=args.interval, incident_limit=args.limit)

    if args.dump:
        snapshot = watch.refresh()
        print(json.dumps(snapshot.as_dict(), indent=2, default=str))
        if observer:
            observer.stop()
        return 0 if any(node.alive for node in snapshot.nodes) else 1

    watch.start()
    console = Console(watch, token=args.token)
    try:
        server = build_server(args.host, args.port, console)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        watch.stop()
        return 2

    host, port = server.server_address[:2]
    serve_forever(server)
    if not args.quiet:
        print(f"swarm console on http://{host}:{port}/  ({len(sources)} node(s), "
              f"observer={'on ' + str(args.observe_port) if observer else 'off'}, "
              f"posture={'on' if posture else 'off'})")
        for source in sources:
            print(f"  {source.name:<12} socket={source.target.socket_path}")
        if not is_loopback(args.host):
            print(f"  serving on {args.host}: token required")
        if observer:
            print("  the observer only hears gossip from nodes that list it as a peer")

    try:
        while True:
            time.sleep(1.0)
    except KeyboardInterrupt:
        pass
    finally:
        watch.stop()
        server.shutdown()
        server.server_close()
        if observer:
            observer.stop()
    if not args.quiet:
        print("console stopped")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
