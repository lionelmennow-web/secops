// Renders the swarm view. Every value here originates in an agent, a log line,
// or a UDP packet, so it is attacker-influenced text: this file writes nodes
// only through textContent and never builds markup, hrefs or src from data.

const state = { snapshot: null, tab: "overview", onlyCurrent: false, stateFilter: "" };

const byId = (id) => document.getElementById(id);
const el = (tag, className, text) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
};
const clear = (node) => {
  while (node && node.firstChild) node.removeChild(node.firstChild);
  return node;
};
const fmt = (ts) => (ts ? new Date(ts * 1000).toLocaleTimeString() : "-");
const day = (ts) => (ts ? new Date(ts * 1000).toLocaleDateString() : "-");
const tag = (text, kind) => el("span", `tag ${kind || ""}`, text);

const ago = (ts) => {
  if (!ts) return "-";
  const s = Math.max(0, Math.round(Date.now() / 1000 - ts));
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  return `${Math.floor(s / 86400)}d`;
};

const duration = (seconds) => {
  const s = Math.max(0, Math.round(seconds || 0));
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h${Math.floor((s % 3600) / 60)}m`;
  return `${Math.floor(s / 86400)}d${Math.floor((s % 86400) / 3600)}h`;
};

const sevKind = (severity) => (severity >= 3 ? "bad" : severity === 2 ? "warn" : "info");

// `cells` are strings/numbers, or an Element to attach as-is.
function fillTable(node, headers, rows, emptyText) {
  clear(node);
  const head = document.createElement("tr");
  headers.forEach((text) => head.appendChild(el("th", null, text)));
  const thead = document.createElement("thead");
  thead.appendChild(head);
  const tbody = document.createElement("tbody");
  if (!rows.length) {
    const line = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = headers.length;
    cell.className = "muted";
    cell.textContent = emptyText;
    line.appendChild(cell);
    tbody.appendChild(line);
  }
  rows.forEach((cells) => {
    const line = document.createElement("tr");
    cells.forEach((cell) => {
      const td = document.createElement("td");
      if (cell instanceof Node) td.appendChild(cell);
      else td.textContent = cell === null || cell === undefined ? "" : String(cell);
      line.appendChild(td);
    });
    tbody.appendChild(line);
  });
  node.append(thead, tbody);
}

function tiles(counts) {
  const node = clear(byId("tiles"));
  const open = (counts.by_state && counts.by_state.open) || 0;
  [
    ["nodes up", `${counts.alive}/${counts.nodes}`],
    ["incidents", counts.attacks],
    ["still open", open],
    ["block rules", counts.blocks],
    ["addresses", counts.subjects],
    ["gossip overheard", counts.overheard],
    ["enforcing", counts.enforcing],
  ].forEach(([label, value]) => {
    const tile = el("div", "tile");
    tile.append(el("div", "n", value), el("div", "l", label));
    node.appendChild(tile);
  });
}

function statRow(label, value) {
  const line = el("div", "row");
  line.append(el("span", null, label), el("span", null, value));
  return line;
}

function nodeCard(node) {
  const card = el("div", "card");
  const title = el("h3");
  title.append(
    el("span", null, node.name),
    tag(node.alive ? "up" : "down", node.alive ? "ok" : "bad"),
    tag(node.mode || "?", node.mode === "enforce" ? "bad" : "warn")
  );
  if (node.backend) title.appendChild(tag(`${node.backend}${node.dry_run ? " dry-run" : ""}`, "info"));
  card.appendChild(title);

  const gossip = node.gossip || {};
  const counters = node.counters || {};
  [
    statRow("address", node.address || "-"),
    statRow("pid", node.alive ? node.pid : "-"),
    statRow("uptime", node.alive ? duration(node.uptime) : "-"),
    statRow("rules in view", node.rules),
    statRow("last polled", ago(node.last_seen_at)),
    statRow("peers", node.peers.length ? node.peers.join(", ") : "none"),
    statRow("isolated", node.isolated.length ? node.isolated.join(", ") : "none"),
    statRow("local / peer threats", `${counters.local_threats ?? "-"} / ${counters.peer_threats ?? "-"}`),
    statRow("guard refusals", node.guard_refusals),
  ].forEach((line) => card.appendChild(line));

  card.appendChild(el("pre", "muted",
    `tx ${gossip.sent || 0}  rx ${gossip.received || 0}  fwd ${gossip.forwarded || 0}  ` +
    `accepted ${gossip.accepted || 0}  dup ${gossip.duplicates || 0}  throttled ${gossip.throttled || 0}  ` +
    `bad-format ${gossip.rejected_shape || 0}  bad-hmac ${gossip.rejected_auth || 0}`));
  if (!node.alive) card.appendChild(el("pre", "muted", node.error || "unreachable"));
  return card;
}

function threatEntry(attack) {
  const entry = el("div", `entry sev${attack.severity}`);
  const head = el("div", "head");
  head.append(
    el("span", null, `${day(attack.ts)} ${fmt(attack.ts)}`),
    el("span", null, `${attack.node}:${attack.incident_id}`),
    el("strong", null, attack.attack),
    el("span", null, attack.subject),
    tag(`sev ${attack.severity}`, sevKind(attack.severity)),
    tag(attack.state, attack.state === "open" ? "bad" : ""),
    tag(`from ${attack.origin}`, "info"),
    tag(`hits ${attack.hits}`),
    tag(`sig ${attack.link}`, attack.link === "exact" ? "ok" : "")
  );
  entry.appendChild(head);
  entry.appendChild(el("div", "evidence", attack.evidence));
  return entry;
}

function renderBanner(snapshot) {
  const banner = clear(byId("banner"));
  const notes = (snapshot.errors || []).slice();
  const planning = snapshot.nodes.filter(
    (node) => node.alive && !node.acting && (node.responder || {}).planned_in_monitor > 0
  );
  if (planning.length) {
    notes.push(
      `${planning.map((node) => node.name).join(", ")} in monitor mode: rules were planned and recorded, ` +
      "never installed in the kernel"
    );
  }
  if (!notes.length) {
    banner.hidden = true;
    return;
  }
  banner.hidden = false;
  banner.className = notes.some((note) => note.includes("unreachable")) ? "banner fail" : "banner";
  notes.forEach((note) => banner.appendChild(el("div", null, note)));
}

// sent/forwarded are printed rather than hidden: a non-zero value there would
// mean the console is speaking on the swarm's wire, which is the one thing
// promised not to happen.
function renderObserver(stats) {
  const node = clear(byId("observer"));
  if (!stats.listening) {
    node.appendChild(el("span", "muted", "gossip observer off: this view is socket and incident-record data only"));
    node.hidden = false;
    return;
  }
  node.hidden = false;
  node.appendChild(
    el(
      "span",
      null,
      `gossip observer on ${stats.listening}: ${stats.received} received, ${stats.recent} recorded, ` +
        `${stats.rejected_shape + stats.rejected_auth} refused (shape ${stats.rejected_shape}, auth ${stats.rejected_auth}), ` +
        `sent ${stats.sent}, forwarded ${stats.forwarded}`
    )
  );
  (stats.rejections || []).slice(0, 3).forEach((refusal) =>
    node.appendChild(el("div", "muted", `${refusal.sender}: ${refusal.note}`))
  );
}

function renderOverview(snapshot) {
  tiles(snapshot.counts);
  renderObserver(snapshot.observer || {});
  const cards = clear(byId("node-cards"));
  if (!snapshot.nodes.length) cards.appendChild(el("div", "empty", "no nodes configured"));
  snapshot.nodes.forEach((node) => cards.appendChild(nodeCard(node)));

  const list = clear(byId("latest"));
  const recent = snapshot.attacks.slice(0, 8);
  if (!recent.length) list.appendChild(el("div", "empty", "quiet: nothing recorded yet"));
  recent.forEach((attack) => list.appendChild(threatEntry(attack)));
}

function renderNodes(snapshot) {
  fillTable(
    byId("nodes-table"),
    ["node", "up", "mode", "backend", "rules", "uptime", "local", "peer", "refusals", "polled", "error"],
    snapshot.nodes.map((node) => [
      node.name,
      node.alive ? "yes" : "no",
      node.mode,
      `${node.backend}${node.dry_run ? " (dry)" : ""}`,
      node.rules,
      node.alive ? duration(node.uptime) : "-",
      (node.counters || {}).local_threats,
      (node.counters || {}).peer_threats,
      node.guard_refusals,
      ago(node.last_seen_at),
      node.error || "",
    ]),
    "no nodes"
  );

  const cards = clear(byId("watchers"));
  snapshot.nodes.filter((node) => node.alive).forEach((node) => {
    const card = el("div", "card");
    card.appendChild(el("h3", null, node.name));
    Object.entries(node.watchers || {}).forEach(([name, detail]) => {
      card.appendChild(el("pre", null, `${name}: ${JSON.stringify(detail)}`));
    });
    if (node.poller_errors && node.poller_errors.length) {
      card.appendChild(el("pre", null, `watcher errors: ${JSON.stringify(node.poller_errors)}`));
    }
    if (node.guard_refusals) {
      card.appendChild(el("pre", null, `refused by guard rails: ${node.guard_refusals}`));
    }
    cards.appendChild(card);
  });
  if (!cards.childNodes.length) cards.appendChild(el("div", "empty", "no live nodes to describe"));
}

function renderAttacks(snapshot) {
  const cutoff = Date.now() / 1000 - 600;
  const select = byId("state-filter");
  const states = new Set(Object.keys((snapshot.counts && snapshot.counts.by_state) || {}));
  const signature = [...states].join(",");
  if (select.dataset.states !== signature) {
    select.dataset.states = signature;
    clear(select);
    select.appendChild(new Option("any state", ""));
    states.forEach((value) => select.appendChild(new Option(value, value)));
    select.value = state.stateFilter;
  }

  const rows = snapshot.attacks.filter(
    (attack) =>
      (!state.onlyCurrent || attack.ts >= cutoff) &&
      (!state.stateFilter || attack.state === state.stateFilter)
  );
  fillTable(
    byId("attacks-table"),
    ["when", "node:id", "attack", "subject", "sev", "state", "origin", "hits", "link", "sig", "actions", "evidence"],
    rows.map((attack) => {
      const button = el("button", null, "detail");
      button.addEventListener("click", () => showDetail(attack.node, attack.incident_id));
      return [
        `${day(attack.ts)} ${fmt(attack.ts)}`,
        `${attack.node}:${attack.incident_id}`,
        attack.attack,
        attack.subject,
        attack.severity,
        attack.state,
        attack.origin,
        attack.hits,
        attack.link,
        attack.sig_id || "-",
        button,
        attack.evidence,
      ];
    }),
    "no incidents match"
  );
}

async function showDetail(node, id) {
  const title = byId("detail-title");
  const view = byId("detail");
  let body;
  try {
    const reply = await fetch(
      `/api/incident?node=${encodeURIComponent(node)}&id=${encodeURIComponent(id)}`,
      { headers: tokenHeader() }
    );
    body = await reply.json();
  } catch (error) {
    body = { error: String(error) };
  }
  title.hidden = false;
  view.hidden = false;
  view.textContent = JSON.stringify(body, null, 2);
}

function renderAddresses(snapshot) {
  fillTable(
    byId("subjects-table"),
    ["subject", "kind", "attacks", "seen on", "coverage", "blocked on", "hits", "sev", "first seen", "last seen", "origins"],
    snapshot.aggregated.map((row) => {
      const blockedCell = row.blocked_on && Object.keys(row.blocked_on).length
        ? Object.entries(row.blocked_on).map(([node, direction]) => `${node}:${direction}`).join(" ")
        : "not blocked";
      return [
        row.subject,
        row.kind,
        row.attacks.join(", "),
        row.nodes.length ? row.nodes.join(", ") : row.overheard ? "observer only" : "-",
        tag(row.coverage, row.coverage === "blocked" ? "ok" : row.coverage === "recorded" ? "warn" : "info"),
        blockedCell,
        row.hits,
        row.severity,
        fmt(row.first_seen),
        `${fmt(row.last_seen)} (${ago(row.last_seen)} ago)`,
        row.origins.join(", "),
      ];
    }),
    "no addresses seen"
  );

  fillTable(
    byId("blocks-table"),
    ["node", "direction", "cidr", "remaining", "source", "reason"],
    snapshot.blocks.map((block) => [
      block.node,
      block.direction,
      block.cidr,
      duration(block.remaining),
      block.source,
      block.reason,
    ]),
    "no active block rules"
  );

  const cards = clear(byId("endpoints"));
  snapshot.nodes.forEach((node) => {
    const endpoints = node.endpoints || {};
    const recent = Object.entries(endpoints.recent || {}).slice(0, 15);
    const approved = endpoints.approved || [];
    if (!recent.length && !approved.length) return;
    const card = el("div", "card");
    card.appendChild(el("h3", null, node.name));
    card.appendChild(statRow("approved endpoints", approved.length));
    card.appendChild(el("pre", "muted",
      recent.map(([endpoint, ts]) => `${endpoint}  last seen ${ago(ts)} ago`).join("\n") || "none seen"));
    cards.appendChild(card);
  });
  if (!cards.childNodes.length) cards.appendChild(el("div", "empty", "no outbound endpoint history yet"));
}

function renderPosture(snapshot) {
  const list = clear(byId("posture-list"));
  const rows = snapshot.posture || [];
  if (!rows.length) {
    list.appendChild(el("div", "empty", "posture checks are off: start the console without --no-posture"));
    return;
  }
  rows.forEach((check) => {
    const entry = el("div", `entry ${check.verdict === "fail" ? "sev3" : check.verdict === "warn" ? "sev2" : "sev1"}`);
    const head = el("div", "head");
    head.append(
      tag(check.verdict, check.verdict === "ok" ? "ok" : check.verdict === "warn" ? "warn" : "bad"),
      el("strong", null, check.area),
      el("span", null, check.node || "console host")
    );
    entry.appendChild(head);
    entry.appendChild(el("div", "evidence", check.message));
    list.appendChild(entry);
  });
}

function render() {
  const snapshot = state.snapshot;
  if (!snapshot) return;
  renderBanner(snapshot);
  renderOverview(snapshot);
  renderNodes(snapshot);
  renderAttacks(snapshot);
  renderAddresses(snapshot);
  renderPosture(snapshot);
  byId("stamp").textContent = `polled ${ago(snapshot.generated_at)} ago`;
}

function setLink(kind, text) {
  const pill = byId("link");
  pill.className = `pill ${kind}`;
  pill.textContent = text;
}

function urlToken() {
  return new URLSearchParams(window.location.search).get("token") || "";
}

function tokenHeader() {
  const token = urlToken();
  return token ? { "X-Swarm-Token": token } : {};
}

async function pollOnce() {
  const reply = await fetch("/api/snapshot", { headers: tokenHeader() });
  if (!reply.ok) throw new Error(`HTTP ${reply.status}`);
  state.snapshot = await reply.json();
  render();
  setLink("live", "polling");
}

function startStream() {
  if (typeof EventSource !== "function") {
    setInterval(pollOnce, 3000);
    return;
  }
  const source = new EventSource(`/stream?token=${encodeURIComponent(urlToken())}`);
  source.addEventListener("snapshot", (event) => {
    state.snapshot = JSON.parse(event.data);
    render();
    setLink("live", "streaming");
  });
  source.onerror = () => setLink("stale", "reconnecting");
}

byId("tabs").addEventListener("click", (event) => {
  const button = event.target.closest("button[data-tab]");
  if (!button) return;
  state.tab = button.dataset.tab;
  document.querySelectorAll("#tabs button").forEach((node) => node.classList.toggle("active", node === button));
  document.querySelectorAll("main section.tab").forEach((node) => node.classList.toggle("active", node.id === state.tab));
});

byId("only-current").addEventListener("change", (event) => {
  state.onlyCurrent = event.target.checked;
  render();
});
byId("state-filter").addEventListener("change", (event) => {
  state.stateFilter = event.target.value;
  render();
});

// Countdowns and "last seen" age move without new data arriving.
setInterval(render, 5000);
pollOnce().catch(() => setLink("dead", "console offline"));
startStream();
