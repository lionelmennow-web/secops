#!/usr/bin/env bash
# Build and run a two-node lab: monitor mode, no firewall backend, nothing here
# can touch the host. `swarmvalidate` and `swarmconsole` both read it.
#
#   deploy/make-lab.sh                # create .runs/demo and start both agents
#   deploy/make-lab.sh --stop         # stop the agents, keep the state
#   deploy/make-lab.sh --fresh        # delete the state first
#   deploy/make-lab.sh --console-port 19990   # let the nodes gossip to a dashboard
set -euo pipefail

ROOT=".runs/demo"
PORT_BASE=19991
CONSOLE_PORT=0
ACTION="start"
while [ $# -gt 0 ]; do
  case "$1" in
    --root) ROOT="$2"; shift 2 ;;
    --port-base) PORT_BASE="$2"; shift 2 ;;
    --console-port) CONSOLE_PORT="$2"; shift 2 ;;
    --stop) ACTION="stop"; shift ;;
    --fresh) ACTION="fresh"; shift ;;
    -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

cd "$(dirname "$0")/.."
PY="${PYTHON:-python3}"

if [ "$ACTION" = "stop" ]; then
  for pidfile in "$ROOT"/*.pid; do
    [ -e "$pidfile" ] || continue
    kill "$(cat "$pidfile")" 2>/dev/null || true
    rm -f "$pidfile"
  done
  echo "lab agents stopped (state kept in $ROOT)"
  exit 0
fi

if [ "$ACTION" = "fresh" ]; then
  for pidfile in "$ROOT"/*.pid; do
    [ -e "$pidfile" ] && kill "$(cat "$pidfile")" 2>/dev/null || true
  done
  # Keep the swarm key. It is trust, not state: wiping it would leave every
  # console already running on the old key silently rejecting all gossip, with
  # nothing but a counter to show why the threat stream stopped.
  if [ -f "$ROOT/swarm.key" ]; then
    mv "$ROOT/swarm.key" "$ROOT/swarm.key.keep"
  fi
  find "$ROOT" -mindepth 1 -not -name 'swarm.key.keep' -delete 2>/dev/null || true
fi

mkdir -p "$ROOT"
PYTHONPATH="$PWD" "$PY" - "$ROOT" "$PORT_BASE" "$CONSOLE_PORT" <<'PY'
import json, os, sys

from secops.config import DEFAULTS

root = os.path.abspath(sys.argv[1])
base = int(sys.argv[2])
console_port = int(sys.argv[3])
key = os.path.join(root, "swarm.key")
kept = key + ".keep"
if os.path.exists(kept):
    os.replace(kept, key)
if not os.path.exists(key):
    import secrets
    with open(key, "w", encoding="utf-8") as handle:
        handle.write(secrets.token_hex(32) + "\n")
    os.chmod(key, 0o600)

for index, name in enumerate(("node-a", "node-b")):
    config = json.loads(json.dumps(DEFAULTS))
    port = base + index
    peer = base + (1 - index)
    peers = [{"node": "the other lab node", "address": "127.0.0.1", "port": peer}]
    if console_port:
        # The console never speaks, so it can only hear what a node chooses to
        # send it: listing it as a peer is what puts threats on the wire it watches.
        peers.append({"node": "console", "address": "127.0.0.1", "port": console_port})
    config.update({
        "node": {"name": name, "advertise_ip": "127.0.0.1"},
        "mode": "monitor",
        "swarm": {**config["swarm"], "key_file": key, "bind_ip": "127.0.0.1",
                  "bind_port": port, "peers": peers},
        "ssh": {**config["ssh"], "logs": [os.path.join(root, f"{name}-auth.log")], "failures": 4},
        "network": {**config["network"],
                    "approved_file": os.path.join(root, f"{name}-endpoints.json")},
        "integrity": {**config["integrity"],
                      "paths": [os.path.join(root, f"{name}-authorized_keys")]},
        "firewall": {"backend": "none", "chain": "SWARM",
                     "state_file": os.path.join(root, f"{name}-blocks.json")},
        "audit": {**config["audit"], "dir": os.path.join(root, name), "syslog": False},
        "guard": {**config["guard"], "allowlist": ["127.0.0.0/8", "::1"]},
    })
    os.makedirs(os.path.join(root, name), exist_ok=True)
    # Same rule install-ubuntu.sh applies to the real state directory: this holds
    # the incident record and quarantined payloads, so it must not be world-readable.
    os.chmod(os.path.join(root, name), 0o700)
    with open(os.path.join(root, f"{name}-auth.log"), "a", encoding="utf-8"):
        pass
    # Seed a baseline, or the persistence scenario can only ever prove that a
    # watched path went missing - not that an appended key was diffed and undone.
    seed = os.path.join(root, f"{name}-authorized_keys")
    if not os.path.exists(seed):
        with open(seed, "w", encoding="utf-8") as handle:
            handle.write("ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBaselinewashere lab baseline key\n")
        os.chmod(seed, 0o600)
    with open(os.path.join(root, f"{name}.json"), "w", encoding="utf-8") as handle:
        json.dump(config, handle, indent=2)
        handle.write("\n")
    print(f"wrote {name}.json (gossip 127.0.0.1:{port}, monitor, backend none)")
PY

for name in node-a node-b; do
  (setsid "$PY" -m secops agent --config "$ROOT/$name.json" >"$ROOT/$name.log" 2>&1 &
   echo $! > "$ROOT/$name.pid")
  sleep 1
done

echo
echo "lab running under $ROOT: $(cat "$ROOT"/node-a.pid) $(cat "$ROOT"/node-b.pid)"
echo
# The nodes were configured to gossip to the console port, so show the observer
# flag next to it: without it the dashboard polls the sockets fine but never
# hears a threat the moment it is sent.
if [ "$CONSOLE_PORT" != "0" ]; then
  OBSERVE=" --observe-port $CONSOLE_PORT"
else
  OBSERVE=""
fi
echo "  dashboard:  $PY -m secops console --node $ROOT/node-a.json --node $ROOT/node-b.json${OBSERVE}"
echo "              then open http://127.0.0.1:8786/"
echo "  attack run: $PY -m secops validate --node $ROOT/node-a.json --node $ROOT/node-b.json --lab-root $ROOT"
echo
echo "  stop:       deploy/make-lab.sh --stop"
