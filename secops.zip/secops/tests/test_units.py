"""Unit tests for the parts that mutate state: firewall, audit, integrity, tailer.

No root, no network, no kernel rules - only the bookkeeping an operator would
otherwise have to trust blindly.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from secops.audit import Audit
from secops.detect.integrity import IntegrityWatcher
from secops.firewall import Firewall, NullFirewall, Rule, normalize
from secops.signals import IN, PERSISTENCE, Threat
from secops.tailing import FileFollower


class RuleTests(unittest.TestCase):
    def test_normalize_canonicalizes_host_and_network(self) -> None:
        self.assertEqual(normalize("10.0.0.5"), "10.0.0.5/32")
        self.assertEqual(normalize("10.0.0.0/24"), "10.0.0.0/24")
        self.assertEqual(normalize("10.0.0.9/24"), "10.0.0.0/24")
        self.assertEqual(normalize("::1"), "::1/128")

    def test_rule_identity_family_and_expiry(self) -> None:
        rule = Rule(address="203.0.113.9", direction=IN, reason="test", expires_at=time.time() + 60, source="local")
        self.assertEqual(rule.cidr, "203.0.113.9/32")
        self.assertEqual(rule.family, 4)
        self.assertEqual(rule.key, ("in", "203.0.113.9/32"))
        self.assertFalse(rule.expired())
        self.assertTrue(rule.expired(time.time() + 120))
        v6 = Rule(address="fe80::1", direction="out", reason="t", expires_at=time.time(), source="local")
        self.assertEqual(v6.family, 6)

    def test_invalid_address_is_refused_without_raising(self) -> None:
        # Guard rails treat a non-parseable address as protected, never as a rule.
        firewall = NullFirewall({"chain": "SWARM"}, allowlist=["127.0.0.0/8"])
        self.assertTrue(firewall.guarded("not-an-ip"))
        self.assertTrue(firewall.guarded("127.0.0.1"))
        self.assertFalse(firewall.guarded("203.0.113.9"))


class FirewallStateTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = tempfile.mkdtemp(prefix="swarm-fw-")
        self.state = os.path.join(self.root, "blocks.json")
        self.firewall = NullFirewall({"chain": "SWARM", "state_file": self.state}, allowlist=["10.9.0.0/16"])

    def rule(self, address="203.0.113.9", ttl=60.0, direction=IN) -> Rule:
        return Rule(
            address=address,
            direction=direction,
            reason="unit test",
            expires_at=time.time() + ttl,
            source="local",
        )

    def test_monitor_mode_tracks_rules_without_touching_the_kernel(self) -> None:
        self.firewall.dry_run = True
        ok, detail = self.firewall.protect(self.rule())
        self.assertTrue(ok)
        self.assertIn("monitor mode", detail)
        self.assertEqual(len(self.firewall.rules), 1)
        self.assertEqual(self.firewall.status()["dry_run"], True)

    def test_allowlist_wins_over_any_threat(self) -> None:
        ok, detail = self.firewall.protect(self.rule("10.9.1.7"))
        self.assertFalse(ok)
        self.assertIn("allowlist", detail)
        self.assertEqual(self.firewall.rules, {})

    def test_longer_lived_rule_is_kept_when_a_shorter_one_arrives(self) -> None:
        self.firewall.protect(self.rule(ttl=3600))
        stored = self.firewall.rules[("in", "203.0.113.9/32")].expires_at
        self.firewall.protect(self.rule(ttl=5))
        self.assertEqual(self.firewall.rules[("in", "203.0.113.9/32")].expires_at, stored)

    def test_state_round_trips_and_drops_expired_rules(self) -> None:
        self.firewall.protect(self.rule("203.0.113.1", ttl=3600))
        self.firewall.protect(self.rule("203.0.113.2", ttl=0.01))
        time.sleep(0.05)
        self.firewall.save_state()
        with open(self.state, encoding="utf-8") as fh:
            payload = json.load(fh)
        self.assertEqual(len(payload["rules"]), 2)

        rebuilt = NullFirewall({"chain": "SWARM", "state_file": self.state}, allowlist=[])
        loaded = rebuilt.load_state()
        self.assertEqual(loaded, 1)
        self.assertIn(("in", "203.0.113.1/32"), rebuilt.rules)

    def test_reap_and_release(self) -> None:
        self.firewall.protect(self.rule("203.0.113.3", ttl=0.01))
        time.sleep(0.05)
        reaped = self.firewall.reap()
        self.assertEqual([r.address for r in reaped], ["203.0.113.3"])
        self.assertEqual(self.firewall.rules, {})
        self.firewall.protect(self.rule("203.0.113.4"))
        ok, _ = self.firewall.release_address("203.0.113.4", IN)
        self.assertTrue(ok)
        ok, detail = self.firewall.release_address("203.0.113.4", IN)
        self.assertFalse(ok)
        self.assertEqual(detail, "no such rule")

    def test_reconcile_repairs_missing_kernel_rules(self) -> None:
        class Stub(Firewall):
            name = "stub"

            def __init__(self, *args) -> None:
                super().__init__(*args)
                self.present = False
                self.installs = 0

            def _present(self, rule) -> bool:
                return self.present

            def _install(self, rule):
                self.installs += 1
                return True, "installed"

        stub = Stub({"state_file": None})
        stub.protect(self.rule())
        result = stub.reconcile()
        self.assertEqual(result["checked"], 1)
        self.assertEqual(result["repaired"], 1)
        stub.present = True
        self.assertEqual(stub.reconcile()["repaired"], 0)


class AuditTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = tempfile.mkdtemp(prefix="swarm-audit-")
        self.audit = Audit(self.root, "node-test", syslog=False)
        self.addCleanup(self.audit.close)

    def threat(self, subject="203.0.113.9", evidence="first") -> Threat:
        return Threat(attack="ssh_bruteforce", subject=subject, evidence=evidence, origin="unit", ttl=60.0)

    def test_repeats_merge_into_one_open_incident(self) -> None:
        first, created = self.audit.open_incident(self.threat())
        self.assertTrue(created)
        second, created = self.audit.open_incident(self.threat(evidence="sixth"))
        self.assertFalse(created)
        self.assertEqual(first, second)
        incident = self.audit.incident(first)
        self.assertEqual(incident["hits"], 2)
        self.assertEqual(incident["evidence"], "sixth")

    def test_different_subjects_are_different_incidents(self) -> None:
        a, _ = self.audit.open_incident(self.threat("203.0.113.9"))
        b, _ = self.audit.open_incident(self.threat("203.0.113.10"))
        self.assertNotEqual(a, b)
        self.assertEqual(len(self.audit.incidents()), 2)

    def test_actions_keep_undo_records(self) -> None:
        incident_id, _ = self.audit.open_incident(self.threat())
        self.audit.record_action(
            incident_id, "block_in", "203.0.113.9", True, "kernel rule added",
            undo={"kind": "unblock", "address": "203.0.113.9", "direction": "in"},
        )
        self.audit.record_action(incident_id, "kill_process", "4242", False, "guard refused: protected")
        actions = self.audit.recent_actions()
        by_kind = {a["kind"]: a for a in actions}
        self.assertEqual(by_kind["block_in"]["undo"]["kind"], "unblock")
        self.assertFalse(by_kind["kill_process"]["ok"])
        self.audit.mark_rolled_back(by_kind["block_in"]["id"])
        after = {a["kind"]: a for a in self.audit.recent_actions()}
        self.assertTrue(after["block_in"]["rolled_back"])

    def test_state_transitions_and_stats_and_stream(self) -> None:
        incident_id, _ = self.audit.open_incident(self.threat())
        self.audit.set_state(incident_id, "contained")
        self.assertEqual(self.audit.incident(incident_id)["state"], "contained")
        stats = self.audit.stats()
        self.assertEqual(stats["incidents_total"], 1)
        self.assertEqual(stats["open"], 0)
        self.assertEqual(stats["last_24h_by_attack"]["ssh_bruteforce"], 1)
        with open(os.path.join(self.root, "threats.jsonl"), encoding="utf-8") as fh:
            lines = [json.loads(line) for line in fh if line.strip()]
        self.assertTrue(any(entry["kind"] == "incident" for entry in lines))

    def test_prune_keeps_the_newest(self) -> None:
        keep = Audit(self.root + "2", "node-test", syslog=False, keep=3)
        self.addCleanup(keep.close)
        for index in range(8):
            id_, _ = keep.open_incident(self.threat(subject=f"203.0.113.{index}"))
            keep.record_action(id_, "block_in", f"203.0.113.{index}", True, "x")
        self.assertEqual(keep.prune(), 5)
        self.assertEqual(len(keep.incidents(limit=50)), 3)
        self.assertEqual(len(keep.recent_actions(limit=50)), 3)


class IntegrityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = tempfile.mkdtemp(prefix="swarm-int-")
        self.keys = os.path.join(self.root, "authorized_keys")
        self.motd = os.path.join(self.root, "notes.txt")
        self.state = os.path.join(self.root, "state")
        for path, text in ((self.keys, "ssh-ed25519 AAAAlegit user@laptop\n"), (self.motd, "hello\n")):
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(text)
        self.threats: list[Threat] = []
        self.watcher = IntegrityWatcher(
            {"paths": [self.keys, self.motd], "restore": True, "interval": 1.0}, self.state, self.threats.append
        )
        self.watcher.tick()  # baseline

    def _write(self, text: str) -> None:
        with open(self.keys, "w", encoding="utf-8") as fh:
            fh.write(text)

    def test_baseline_is_backed_up_and_not_alerted(self) -> None:
        self.assertEqual(self.threats, [])
        record = self.watcher.tracked[self.keys]
        self.assertTrue(record.sha256)
        self.assertTrue(os.path.exists(record.backup))
        with open(record.backup, encoding="utf-8") as fh:
            self.assertEqual(fh.read(), "ssh-ed25519 AAAAlegit user@laptop\n")

    def test_added_attacker_key_becomes_a_persistence_threat(self) -> None:
        self._write(
            "ssh-ed25519 AAAAlegit user@laptop\n"
            "ssh-rsa AAAAB3Nza remote@attacker\n"
        )
        self.watcher.tick()
        self.assertEqual(len(self.threats), 1)
        threat = self.threats[0]
        self.assertEqual(threat.attack, PERSISTENCE)
        self.assertEqual(threat.subject, self.keys)
        self.assertIn("authorized_key", threat.details["markers"])
        self.assertIn("ssh-rsa", "\n".join(threat.details["added_lines"]))
        self.assertIn("restore_paths", threat.actions)

    def test_restore_writes_back_the_baseline_and_clears_the_drift(self) -> None:
        self._write("ssh-ed25519 AAAAlegit user@laptop\nssh-rsa AAAAB3Nza remote@attacker\n")
        self.watcher.tick()
        ok, detail = self.watcher.restore(self.keys)
        self.assertTrue(ok, detail)
        with open(self.keys, encoding="utf-8") as fh:
            self.assertEqual(fh.read(), "ssh-ed25519 AAAAlegit user@laptop\n")
        self.assertEqual(self.watcher.snapshot()["sensitive_drift"], [])

    def test_benign_edit_to_an_ordinary_file_only_alerts(self) -> None:
        with open(self.motd, "w", encoding="utf-8") as fh:
            fh.write("hello\nworld\n")
        self.watcher.tick()
        self.assertEqual(len(self.threats), 1)
        threat = self.threats[0]
        self.assertEqual(threat.tag, "alert")
        self.assertEqual(threat.details["markers"], [])
        # An accepted benign edit becomes the new baseline, so it does not re-alert.
        self.watcher.tick()
        self.assertEqual(len(self.threats), 1)

    def test_any_edit_to_a_sensitive_file_is_blocking(self) -> None:
        self._write("# edited by the operator, no attacker markers\nssh-ed25519 AAAAlegit user@laptop\n")
        self.watcher.tick()
        threat = self.threats[0]
        self.assertEqual(threat.tag, "block")
        self.assertEqual(threat.details["markers"], [])
        self.assertIn("restore_paths", threat.actions)

    def test_deleting_a_watched_file_is_reported_then_restored(self) -> None:
        os.unlink(self.keys)
        self.watcher.tick()
        self.assertEqual(len(self.threats), 1)
        self.assertIn("disappeared", self.threats[0].evidence)
        ok, _ = self.watcher.restore(self.keys)
        self.assertTrue(ok)
        self.assertTrue(os.path.exists(self.keys))

    def test_quarantine_moves_the_file_aside_instead_of_unlinking(self) -> None:
        self._write("ssh-rsa AAAAB3Nza remote@attacker\n")
        self.watcher.tick()
        ok, destination = self.watcher.quarantine(self.keys)
        self.assertTrue(ok)
        self.assertFalse(os.path.exists(self.keys))
        self.assertTrue(os.path.exists(destination))
        self.assertEqual(oct(os.stat(destination).st_mode)[-3:], "600")

    def test_approval_makes_the_current_content_the_new_baseline(self) -> None:
        self._write("ssh-ed25519 AAAAnewkey operator@workstation\n")
        self.watcher.tick()
        self.threats.clear()
        ok, _ = self.watcher.approve(self.keys)
        self.assertTrue(ok)
        self.watcher.tick()
        self.assertEqual(self.threats, [])

    def test_glob_watches_every_user_that_exists(self) -> None:
        homes = os.path.join(self.root, "home")
        for user in ("alice", "bob"):
            directory = os.path.join(homes, user, ".ssh")
            os.makedirs(directory)
            with open(os.path.join(directory, "authorized_keys"), "w", encoding="utf-8") as fh:
                fh.write(f"ssh-ed25519 AAAA{user} {user}@laptop\n")
        watcher = IntegrityWatcher(
            {"paths": [os.path.join(homes, "*", ".ssh", "authorized_keys")]},
            os.path.join(self.root, "state2"),
            lambda threat: None,
        )
        watcher.tick()
        self.assertEqual(len(watcher.tracked), 2)

        os.makedirs(os.path.join(homes, "carol", ".ssh"))
        with open(os.path.join(homes, "carol", ".ssh", "authorized_keys"), "w", encoding="utf-8") as fh:
            fh.write("ssh-rsa AAAAB3Nza remote@attacker\n")
        threats = []
        watcher.emit = threats.append
        watcher.tick()
        self.assertEqual(len(watcher.tracked), 3)
        self.assertEqual(threats, [])  # a brand-new file is baselined, not restored blindly

    def test_manifest_survives_a_restart(self) -> None:
        reopened = IntegrityWatcher({"paths": [self.keys]}, self.state, lambda threat: None)
        self.assertIn(self.keys, reopened.tracked)
        self.assertEqual(reopened.tracked[self.keys].sha256, self.watcher.tracked[self.keys].sha256)


class FollowerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = tempfile.mkdtemp(prefix="swarm-tail-")

    def collected(self, path: str, *, from_start: bool, wait: float = 1.2):
        lines: list[str] = []
        follower = FileFollower(path, lines.append, from_start=from_start)
        follower.start()
        time.sleep(wait)
        follower.stop()
        return lines

    def test_history_in_an_existing_log_is_not_re_lived(self) -> None:
        path = os.path.join(self.root, "auth.log")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("old line\n")
        self.assertEqual(self.collected(path, from_start=False), [])

    def test_a_log_created_after_monitoring_starts_is_read_from_the_top(self) -> None:
        path = os.path.join(self.root, "late.log")
        lines: list[str] = []
        follower = FileFollower(path, lines.append, from_start=False)
        follower.start()
        time.sleep(0.1)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("fail 1\nfail 2\n")
        deadline = time.time() + 2.0
        while len(lines) < 2 and time.time() < deadline:
            time.sleep(0.05)
        follower.stop()
        self.assertEqual(lines, ["fail 1", "fail 2"])

    def test_truncation_and_rotation_are_followed(self) -> None:
        path = os.path.join(self.root, "rot.log")
        lines: list[str] = []
        follower = FileFollower(path, lines.append, from_start=True)
        follower.start()
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("one\n")
        deadline = time.time() + 2.0
        while not lines and time.time() < deadline:
            time.sleep(0.05)
        os.rename(path, path + ".1")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("two\n")
        deadline = time.time() + 2.0
        while len(lines) < 2 and time.time() < deadline:
            time.sleep(0.05)
        follower.stop()
        self.assertEqual(lines, ["one", "two"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
