"""End-to-end swarm behaviour: two agents, one log, real UDP between them.

Everything here is the production code path - FileFollower, AuthRules, the
responder, GossipTransport on loopback, the SQLite audit - with the firewall in
`none` mode so the test host is never modified.
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from secops.agent import SwarmAgent
from secops.config import Config
from secops.signature import ThreatSignature

ATTACKER = "203.0.113.9"


def ssh_fail_line(index: int, source: str = ATTACKER, user: str = "root") -> str:
    clock = time.strftime("%b %d %H:%M:%S")
    return (
        f"{clock} target sshd[{4000 + index}]: Failed password for {user} "
        f"from {source} port {40000 + index} ssh2"
    )


def make_config(root: str, node: str, port: int, peers: list[dict], *, mode: str = "monitor") -> Config:
    data = json.loads(json.dumps(Config.DEFAULTS_SNAPSHOT()))
    data["node"] = {"name": node, "advertise_ip": "127.0.0.1"}
    data["mode"] = mode
    data["swarm"].update(
        {
            "key_file": os.path.join(root, "swarm.key"),
            "bind_ip": "127.0.0.1",
            "bind_port": port,
            "peers": peers,
            "discovery": {"enabled": False, "group": "239.255.77.88", "interval": 1.0},
        }
    )
    data["ssh"].update({"logs": [os.path.join(root, f"{node}-auth.log")], "journal_units": [], "failures": 4, "window": 120.0})
    data["firewall"] = {"backend": "none", "chain": "SWARMTEST", "state_file": os.path.join(root, f"{node}-blocks.json")}
    data["audit"]["dir"] = os.path.join(root, node)
    data["network"]["approved_file"] = os.path.join(root, f"{node}-endpoints.json")
    data["network"]["poll_interval"] = 0.4
    data["process"]["poll_interval"] = 0.3
    data["integrity"]["interval"] = 1.0
    data["integrity"]["paths"] = [os.path.join(root, f"{node}-authorized_keys")]
    config = Config(data)
    config.validate()
    return config


class SwarmIntegrationTest(unittest.TestCase):
    def setUp(self) -> None:
        self.root = tempfile.mkdtemp(prefix="swarm-test-")
        key = os.urandom(32)
        with open(os.path.join(self.root, "swarm.key"), "wb") as fh:
            fh.write(key)
        self.key = key

        peer_a = {"node": "node-a", "address": "127.0.0.1", "port": 19911}
        peer_b = {"node": "node-b", "address": "127.0.0.1", "port": 19912}
        self.agent_a = SwarmAgent(make_config(self.root, "node-a", 19911, [peer_b]))
        self.agent_b = SwarmAgent(make_config(self.root, "node-b", 19912, [peer_a]))
        self.agent_a.start()
        self.agent_b.start()
        self.addCleanup(self.stop)

    def stop(self) -> None:
        for agent in (self.agent_a, self.agent_b):
            agent.stop()

    def append_auth(self, node: str, lines: list[str]) -> str:
        path = os.path.join(self.root, f"{node}-auth.log")
        with open(path, "a", encoding="utf-8") as fh:
            for line in lines:
                fh.write(line + "\n")
            fh.flush()
        return path

    def wait_for(self, predicate, timeout: float = 8.0, message: str = "condition") -> None:
        deadline = time.time() + timeout
        while time.time() < deadline:
            if predicate():
                return
            time.sleep(0.1)
        self.fail(f"timed out waiting for {message}")

    # ---- tests -------------------------------------------------------------
    def test_brute_force_spreads_across_the_swarm(self) -> None:
        self.append_auth("node-a", [ssh_fail_line(index) for index in range(8)])
        self.wait_for(lambda: any(r["address"] == ATTACKER for r in self.agent_a.do_blocks()), message="node-a block")
        self.wait_for(
            lambda: any(r["address"] == ATTACKER for r in self.agent_b.do_blocks()),
            message="node-b learned the block",
        )

        rule = next(r for r in self.agent_b.do_blocks() if r["address"] == ATTACKER)
        self.assertEqual(rule["source"], "node-a")
        self.assertIn("bruteforce", rule["reason"].lower())
        self.assertIn("4 failed logins", rule["reason"])
        self.assertEqual(rule["cidr"], f"{ATTACKER}/32")

        status = self.agent_b.do_status()
        self.assertGreaterEqual(status["swarm"]["counters"]["peer_threats"], 1)
        self.assertEqual(status["swarm"]["gossip"]["rejected_auth"], 0)

        incidents = self.agent_a.do_incidents(limit=10)
        self.assertTrue(any(incident["attack"] == "ssh_bruteforce" for incident in incidents))

    def test_forged_gossip_is_refused_and_not_applied(self) -> None:
        forged = ThreatSignature(
            subject="198.51.100.7",
            attack="ssh_bruteforce",
            node="impostor",
            reason="pretend a peer asked for this",
            ttl=600.0,
        ).with_auth(b"not-the-swarm-key")

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(forged.to_json(), ("127.0.0.1", 19912))
        sock.close()

        def rejected() -> bool:
            stats = self.agent_b.do_status()["swarm"]["gossip"]
            return stats["rejected_auth"] >= 1

        self.wait_for(rejected, message="forged signature rejected")
        self.assertFalse(any(r["address"] == "198.51.100.7" for r in self.agent_b.do_blocks()))

    def test_isolated_node_cannot_teach_the_swarm(self) -> None:
        self.agent_a.isolate("127.0.0.2", reason="test")
        # A real agent binds 127.0.0.1, so use the sender address the transport sees.
        before = self.agent_a.do_status()["swarm"]["counters"]["peer_rejected"]
        self.agent_a.isolated_nodes.add("127.0.0.1")

        self.agent_b.transport.broadcast(
            ThreatSignature(
                subject="192.0.2.50",
                attack="port_scan",
                node="node-b",
                reason="reported by the now-isolated node",
                ttl=300.0,
            ).with_auth(self.key)
        )
        deadline = time.time() + 4
        while time.time() < deadline:
            if self.agent_a.do_status()["swarm"]["counters"]["peer_rejected"] > before:
                break
            time.sleep(0.1)
        self.assertGreater(self.agent_a.do_status()["swarm"]["counters"]["peer_rejected"], before)
        self.assertFalse(any(r["address"] == "192.0.2.50" for r in self.agent_a.do_blocks()))

    def test_real_reverse_shell_grammar_catches_a_live_process(self) -> None:
        # Connects nowhere: closed loopback port. The point is the exec signature,
        # and monitor mode means nothing is killed.
        child = subprocess.Popen(
            ["/bin/bash", "-c", "sleep 1; exec 3<>/dev/tcp/127.0.0.1/9 || true"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            self.wait_for(
                lambda: any(
                    threat["attack"] in ("reverse_shell", "dropper_exec")
                    for threat in self.agent_a.recent
                ),
                timeout=12.0,
                message="process watcher to flag the shell",
            )
        finally:
            child.wait(timeout=15)

    def test_guard_refuses_to_block_a_swarm_peer_or_the_host_itself(self) -> None:
        result = self.agent_a.dispatch({"command": "block", "args": {"address": "127.0.0.1"}})
        self.assertTrue(result["ok"])
        self.assertFalse(any(r["address"] == "127.0.0.1" for r in self.agent_a.do_blocks()))

    def test_control_socket_answers_locally_only(self) -> None:
        path = self.agent_a.control_socket_path
        self.assertTrue(os.path.exists(path))
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(5)
        connection.connect(path)
        connection.sendall(json.dumps({"command": "status", "args": {}}).encode() + b"\n")
        buffer = b""
        while b"\n" not in buffer:
            chunk = connection.recv(65536)
            if not chunk:
                break
            buffer += chunk
        connection.close()
        reply = json.loads(buffer.decode())
        self.assertTrue(reply["ok"])
        self.assertEqual(reply["result"]["node"], "node-a")
        self.assertEqual(reply["result"]["mode"], "monitor")

    def test_operator_block_is_taught_to_peers_and_can_be_rolled_back(self) -> None:
        self.agent_a.dispatch({"command": "block", "args": {"address": "192.0.2.77", "ttl": 120.0, "direction": "both"}})
        self.wait_for(lambda: any(r["address"] == "192.0.2.77" for r in self.agent_b.do_blocks()), message="peer learned manual block")
        rollback = self.agent_a.dispatch({"command": "rollback"})["result"]
        self.assertTrue(rollback["rolled_back"])
        self.assertFalse(any(r["address"] == "192.0.2.77" for r in self.agent_a.do_blocks()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
