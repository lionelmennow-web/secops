#!/usr/bin/env bash
# Install the swarm agent on Ubuntu (22.04 / 24.04).
#
#   sudo ./deploy/install-ubuntu.sh                 # monitor mode, no peers yet
#   sudo ./deploy/install-ubuntu.sh --enforce       # arm enforcement (root only)
#   sudo ./deploy/install-ubuntu.sh --peer 10.0.0.12 --peer 10.0.0.13
#
# Idempotent: it never overwrites an existing /etc/swarm/agent.json or swarm.key,
# so you can re-run it after pulling a new version.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PREFIX=/opt/swarm
CONF=/etc/swarm/agent.json
KEY=/etc/swarm/swarm.key
STATE=/var/lib/swarm
MODE=monitor
PEERS=()

while [[ $# -gt 0 ]]; do
  case "$1" in
    --enforce) MODE=enforce; shift ;;
    --monitor) MODE=monitor; shift ;;
    --peer) PEERS+=("$2"); shift 2 ;;
    --port) PORT="$2"; shift 2 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done
PORT="${PORT:-9911}"

[[ $EUID -eq 0 ]] || { echo "run me with sudo" >&2; exit 1; }
command -v python3 >/dev/null || { echo "python3 is required" >&2; exit 1; }
PY="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)' || {
  echo "needs Python >= 3.11, found $PY" >&2; exit 1; }

echo "== copying code to $PREFIX"
install -d -m 0755 "$PREFIX"
cp -a "$SRC/secops" "$PREFIX/"
cp -a "$SRC/README.md" "$PREFIX/" 2>/dev/null || true
find "$PREFIX" -name __pycache__ -type d -prune -exec rm -rf {} +

echo "== creating $STATE"
install -d -m 0700 "$STATE"

if [[ ! -f $KEY ]]; then
  echo "== generating a swarm key (share this exact file with every peer)"
  install -d -m 0755 /etc/swarm
  umask 077
  head -c 32 /dev/urandom > "$KEY"
  chmod 0600 "$KEY"
fi

if [[ ! -f $CONF ]]; then
  echo "== writing $CONF (mode=$MODE, port=$PORT)"
  install -d -m 0755 /etc/swarm
  PEER_JSON="$(printf '%s\n' "${PEERS[@]:-}" | python3 -c '
import json, sys
port = int(sys.argv[1])
print(json.dumps([{"address": line.strip(), "port": port} for line in sys.stdin if line.strip()]))
' "$PORT")"
  MODE="$MODE" CONF="$CONF" STATE="$STATE" KEY="$KEY" PORT="$PORT" PEER_JSON="$PEER_JSON" python3 - <<'PY'
import json, os, socket
conf = os.environ["CONF"]
json.dump(
    {
        "node": {"name": socket.gethostname().split(".")[0]},
        "mode": os.environ["MODE"],
        "swarm": {
            "key_file": os.environ["KEY"],
            "bind_ip": "0.0.0.0",
            "bind_port": int(os.environ.get("PORT", "9911")),
            "peers": json.loads(os.environ["PEER_JSON"]),
            "discovery": {"enabled": False, "group": "239.255.77.88", "interval": 30.0},
            "max_new_per_second": 20,
        },
        "ssh": {"logs": ["/var/log/auth.log"], "journal_units": ["sshd", "ssh"]},
        "firewall": {
            "backend": "auto",
            "chain": "SWARM",
            "state_file": os.path.join(os.environ["STATE"], "blocks.json"),
        },
        "guard": {"allowlist": ["127.0.0.0/8", "::1"]},
        "audit": {"dir": os.environ["STATE"], "syslog": True},
    },
    open(conf, "w"),
    indent=2,
)
PY
  chmod 0640 "$CONF"
else
  echo "== keeping the existing $CONF"
fi

python3 -c "import json; json.load(open('$CONF'))" || { echo "$CONF is not valid JSON" >&2; exit 1; }

echo "== installing the systemd unit and operator commands"
install -m 0644 "$SRC/deploy/swarm-agent.service" /etc/systemd/system/swarm-agent.service
for name in swarmd swarmctl; do
  if [ "$name" = swarmctl ]; then subcommand=control; else subcommand=agent; fi
  cat > /usr/local/bin/$name <<EOF
#!/bin/sh
PYTHONPATH=$PREFIX exec /usr/bin/python3 -m secops $subcommand "\$@"
EOF
  chmod 0755 /usr/local/bin/$name
done
systemctl daemon-reload
systemctl enable swarm-agent.service

echo
echo "== self-test"
PYTHONPATH=$PREFIX python3 -m secops doctor || true

cat <<EOF

Installed.  Start it with:

    systemctl start swarm-agent
    swarmctl status

Nothing is blocked until you set "mode": "enforce" in $CONF and restart.
To join a second host, copy $KEY to it (scp as root, then chmod 0600) and add
{"address": "<this host>", "port": $PORT} to its "peers" list.
EOF
