"""Read the Linux process table straight from /proc.

This is how the agent answers "who is making that connection, and should they
be?": socket inodes are matched to the file descriptors that hold them, so an
outbound session is attributed to a real pid, cmdline, interpreter, and cwd
rather than a guess.
"""

from __future__ import annotations

import hashlib
import ipaddress
import os
import pwd
import re
import socket
import struct
import time
from typing import Iterable

from .events import ProcessRecord, TcpConnection

TCP_STATES = {
    "01": "ESTABLISHED",
    "02": "SYN_SENT",
    "03": "SYN_RECV",
    "04": "FIN_WAIT1",
    "05": "FIN_WAIT2",
    "06": "TIME_WAIT",
    "07": "CLOSE",
    "08": "CLOSE_WAIT",
    "09": "LAST_ACK",
    "0A": "LISTEN",
    "0B": "CLOSING",
}

HEXIP4 = re.compile(r"^[0-9A-F]{8}$")
JIFFIES = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
BOOT_TIME = None
MAX_HASH_BYTES = 8 * 1024 * 1024


def _btime() -> float:
    global BOOT_TIME
    if BOOT_TIME is None:
        BOOT_TIME = time.time()
        try:
            with open("/proc/stat", encoding="utf-8") as fh:
                for line in fh:
                    if line.startswith("btime "):
                        BOOT_TIME = float(line.split()[1])
                        break
        except OSError:
            pass
    return BOOT_TIME


def list_pids() -> list[int]:
    pids = []
    for name in os.listdir("/proc"):
        if name.isdigit():
            pids.append(int(name))
    return pids


def _read(path: str) -> str:
    try:
        with open(path, "rb") as fh:
            return fh.read().decode("utf-8", "replace")
    except OSError:
        return ""


def _readlink(path: str) -> str:
    try:
        return os.readlink(path)
    except OSError:
        return ""


def _user(uid: int) -> str:
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)


def read_process(pid: int) -> ProcessRecord | None:
    stat = _read(f"/proc/{pid}/stat")
    if not stat:
        return None
    # comm is wrapped in parentheses and may contain spaces: split around them.
    try:
        head, rest = stat.split("(", 1)
        comm, tail = rest.split(") ", 1)
        fields = tail.split()
    except ValueError:
        return None
    if len(fields) < 20:
        return None
    ppid = int(fields[1])
    state = fields[0]
    starttime_ticks = int(fields[19])
    uid = _stat_uid(pid)
    return ProcessRecord(
        pid=pid,
        ppid=ppid,
        uid=uid,
        comm=comm,
        cmdline=tuple(part for part in _read(f"/proc/{pid}/cmdline").split("\0")[:24] if part),
        exe=_readlink(f"/proc/{pid}/exe"),
        cwd=_readlink(f"/proc/{pid}/cwd"),
        started_at=_btime() + starttime_ticks / JIFFIES,
        state=state,
    )


def _stat_uid(pid: int) -> int:
    try:
        for line in _read(f"/proc/{pid}/status").splitlines():
            if line.startswith("Uid:"):
                return int(line.split()[1])
    except (IndexError, ValueError):
        pass
    return -1


def user_name(uid: int) -> str:
    return _user(uid)


def socket_inodes(pid: int) -> set[int]:
    inodes = set()
    fd_dir = f"/proc/{pid}/fd"
    try:
        entries = os.listdir(fd_dir)
    except OSError:
        return inodes
    for entry in entries:
        target = _readlink(os.path.join(fd_dir, entry))
        if target.startswith("socket:["):
            digits = target[8:-1]
            if digits.isdigit():
                inodes.add(int(digits))
    return inodes


def open_files(pid: int, limit: int = 24) -> tuple[str, ...]:
    """Regular files a process holds open - payloads and C2 configs show up here."""
    found = []
    fd_dir = f"/proc/{pid}/fd"
    try:
        entries = os.listdir(fd_dir)
    except OSError:
        return ()
    for entry in entries[:256]:
        target = _readlink(os.path.join(fd_dir, entry))
        if target.startswith("/") and not target.startswith(("/proc/", "/sys/", "/dev/")):
            found.append(target)
            if len(found) >= limit:
                break
    return tuple(found)


def decode_address(hex_value: str, family: int) -> tuple[str, int]:
    ip_hex, _, port_hex = hex_value.partition(":")
    port = int(port_hex, 16) if port_hex else 0
    if family == 6:
        raw = bytes.fromhex(ip_hex)
        # /proc lists IPv6 as four 32-bit little-endian words.
        words = [raw[i : i + 4][::-1] for i in range(0, 16, 4)]
        return f"{socket.inet_ntop(socket.AF_INET6, b''.join(words))}", port
    raw = bytes.fromhex(ip_hex)
    return socket.inet_ntop(socket.AF_INET, raw[::-1]), port


def read_tcp_connections(family: int = 4) -> list[TcpConnection]:
    path = "/proc/net/tcp" if family == 4 else "/proc/net/tcp6"
    connections: list[TcpConnection] = []
    try:
        with open(path, encoding="utf-8") as fh:
            lines = fh.readlines()[1:]
    except OSError:
        return connections
    for line in lines:
        parts = line.split()
        if len(parts) < 10:
            continue
        local_ip, local_port = decode_address(parts[1], family)
        remote_ip, remote_port = decode_address(parts[2], family)
        state = TCP_STATES.get(parts[3], parts[3])
        connections.append(
            TcpConnection(
                local=local_ip,
                local_port=local_port,
                remote=remote_ip,
                remote_port=remote_port,
                state=state,
                uid=int(parts[7]),
                inode=int(parts[9]),
                family=family,
            )
        )
    return connections


def socket_owner_index() -> dict[int, tuple[int, str]]:
    """inode -> (pid, comm) for every socket the kernel will let us see."""
    index: dict[int, tuple[int, str]] = {}
    for pid in list_pids():
        record = None
        comm = ""
        try:
            comm = _read(f"/proc/{pid}/comm").strip()
        except OSError:
            continue
        for inode in socket_inodes(pid):
            index[inode] = (pid, comm)
    return index


def attach_processes(connections: Iterable[TcpConnection]) -> list[TcpConnection]:
    owners = socket_owner_index()
    enriched = []
    for connection in connections:
        owner = owners.get(connection.inode)
        if owner:
            pid, comm = owner
            enriched.append(
                TcpConnection(
                    **{**connection.__dict__, "pid": pid, "comm": comm}
                )
            )
        else:
            enriched.append(connection)
    return enriched


def lineage(pid: int, limit: int = 8) -> tuple[tuple[int, str], ...]:
    """(pid, comm) chain from the process up to init, oldest last."""
    chain = []
    current = pid
    for _ in range(limit):
        record = read_process(current)
        if record is None:
            break
        chain.append((record.pid, record.comm))
        if record.ppid <= 0 or record.ppid == current:
            break
        current = record.ppid
    return tuple(chain)


def file_identity(path: str, max_bytes: int = MAX_HASH_BYTES) -> dict:
    """Hash and stat what we can of a file the process is running."""
    identity = {"path": path, "exists": False, "size": 0, "mtime": 0.0, "sha256": "", "mode": 0}
    try:
        stat = os.stat(path)
    except OSError:
        return identity
    identity.update(exists=True, size=stat.st_size, mtime=stat.st_mtime, mode=stat.st_mode & 0o7777)
    digest = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            remaining = max_bytes
            while remaining > 0:
                chunk = fh.read(min(65536, remaining))
                if not chunk:
                    break
                digest.update(chunk)
                remaining -= len(chunk)
    except OSError:
        identity["sha256"] = ""
        return identity
    identity["sha256"] = digest.hexdigest()
    return identity


def is_private(address: str) -> bool:
    try:
        ip = ipaddress.ip_address(address)
    except ValueError:
        return False
    return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast


def same_boot(started_at: float, now: float | None = None) -> bool:
    return started_at > _btime() - 1 and started_at <= (now or time.time()) + 1
