"""Peer-to-peer threat gossip over UDP.

No controller: each agent knows its peers from local config (or LAN discovery),
sends signed threats to them, and re-broadcasts what it accepted, minus the peer
it heard it from. Every hop re-validates, so a node cannot smuggle a forged or
malformed rule into the swarm, and the throttle keeps one noisy peer from
burying the others.
"""

from __future__ import annotations

import socket
import struct
import threading
import time
from collections import deque
from dataclasses import dataclass

from .signals import ALERT
from .signature import MAX_HOP, SignatureError, ThreatSignature, parse, verify_auth

DEFAULT_MAX_NEW_PER_SECOND = 25
SEEN_RETENTION = 900.0
MAX_PACKET = 2048


@dataclass
class GossipStats:
    sent: int = 0
    received: int = 0
    rejected_shape: int = 0
    rejected_auth: int = 0
    rejected_isolated: int = 0
    duplicates: int = 0
    throttled: int = 0
    forwarded: int = 0
    accepted: int = 0

    def as_dict(self) -> dict:
        return {
            "sent": self.sent,
            "received": self.received,
            "rejected_shape": self.rejected_shape,
            "rejected_auth": self.rejected_auth,
            "rejected_isolated": self.rejected_isolated,
            "duplicates": self.duplicates,
            "throttled": self.throttled,
            "forwarded": self.forwarded,
            "accepted": self.accepted,
        }


class TokenBucket:
    def __init__(self, rate: float, capacity: float | None = None) -> None:
        self.rate = rate
        self.capacity = capacity if capacity is not None else max(rate, 1.0)
        self._tokens = self.capacity
        self._updated = time.monotonic()
        self._lock = threading.Lock()

    def take(self, amount: float = 1.0) -> bool:
        with self._lock:
            now = time.monotonic()
            self._tokens = min(self.capacity, self._tokens + (now - self._updated) * self.rate)
            self._updated = now
            if self._tokens >= amount:
                self._tokens -= amount
                return True
            return False


@dataclass(frozen=True)
class Peer:
    address: tuple[str, int]
    node: str = ""

    def __str__(self) -> str:
        return f"{self.address[0]}:{self.address[1]}"


class GossipTransport:
    def __init__(
        self,
        bind: tuple[str, int],
        key: bytes,
        on_signature,
        peers: list[Peer] | None = None,
        max_new_per_second: float = DEFAULT_MAX_NEW_PER_SECOND,
        multicast: tuple[str, int] | None = None,
    ) -> None:
        self.bind = bind
        self.key = key
        self.on_signature = on_signature
        self.peers: list[Peer] = list(peers or [])
        self.multicast = multicast
        self.stats = GossipStats()
        self._bucket = TokenBucket(max_new_per_second)
        self._seen: dict[str, float] = {}
        self._seen_order: deque = deque()
        self._lock = threading.Lock()
        self._sock: socket.socket | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(0.5)
        sock.bind(self.bind)
        if self.multicast:
            group, port = self.multicast
            try:
                mreq = struct.pack("4sl", socket.inet_aton(group), socket.INADDR_ANY)
                sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            except OSError:
                pass
        self._sock = sock
        self._thread = threading.Thread(target=self._receive_loop, name="gossip", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._sock:
            try:
                self._sock.close()
            except OSError:
                pass
        if self._thread:
            self._thread.join(timeout=2.0)

    def add_peer(self, peer: Peer) -> bool:
        with self._lock:
            if any(p.address == peer.address for p in self.peers):
                return False
            self.peers.append(peer)
            return True

    def peer_count(self) -> int:
        with self._lock:
            return len(self.peers)

    def broadcast(self, sig: ThreatSignature, exclude_addr: tuple[str, int] | None = None) -> int:
        if self._sock is None:
            return 0
        packet = sig.with_auth(self.key).to_json()
        if len(packet) > MAX_PACKET:
            return 0
        with self._lock:
            targets = [p for p in self.peers if p.address != exclude_addr]
        delivered = 0
        for peer in targets:
            try:
                self._sock.sendto(packet, peer.address)
                delivered += 1
            except OSError:
                continue
        if self.multicast and exclude_addr is None:
            try:
                self._sock.sendto(packet, self.multicast)
                delivered += 1
            except OSError:
                pass
        self.stats.sent += delivered
        self._remember(sig.id)
        return delivered

    def send_raw(self, payload: bytes, address: tuple[str, int]) -> bool:
        """Send an unauthenticated control packet (peer hello). Only used by discovery."""
        if self._sock is None:
            return False
        try:
            self._sock.sendto(payload, address)
            return True
        except OSError:
            return False

    def _receive_loop(self) -> None:
        while not self._stop.is_set():
            try:
                packet, sender = self._sock.recvfrom(MAX_PACKET)
            except socket.timeout:
                continue
            except OSError:
                return
            self._handle(packet, sender)

    def _handle(self, packet: bytes, sender: tuple[str, int]) -> None:
        self.stats.received += 1
        try:
            sig = parse(packet)
        except SignatureError as exc:
            self.stats.rejected_shape += 1
            self.on_signature(None, sender, f"malformed signature dropped: {exc}")
            return

        if not verify_auth(sig, self.key):
            self.stats.rejected_auth += 1
            self.on_signature(None, sender, f"unauthenticated signature from {sender[0]} ignored")
            return

        if not self._fresh(sig):
            self.stats.duplicates += 1
            return

        if sig.tag != ALERT and not self._bucket.take():
            # Compromise alerts outrank the routine throttle: containment should
            # not wait behind a burst of brute-force reports.
            self.stats.throttled += 1
            self.on_signature(sig, sender, "rate limit reached; signature dropped")
            return

        if self.on_signature(sig, sender, "accepted"):
            self.stats.accepted += 1
            self._forward(sig, sender)

    def _forward(self, sig: ThreatSignature, sender: tuple[str, int]) -> None:
        if sig.hop >= MAX_HOP:
            return
        hopling = ThreatSignature(
            subject=sig.subject,
            attack=sig.attack,
            node=sig.node,
            reason=sig.reason,
            tag=sig.tag,
            direction=sig.direction,
            ttl=sig.ttl,
            ts=sig.ts,
            hop=sig.hop + 1,
            ports=sig.ports,
            version=sig.version,
            auth=sig.auth,
        )
        self.broadcast(hopling, exclude_addr=sender)
        self.stats.forwarded += 1

    def _fresh(self, sig: ThreatSignature) -> bool:
        """One instance per threat, no matter how many peers re-broadcast it."""
        now = time.time()
        with self._lock:
            if sig.id in self._seen:
                return False
            self._seen[sig.id] = now
            self._seen_order.append(sig.id)
            while self._seen_order and now - self._seen[self._seen_order[0]] > SEEN_RETENTION:
                self._seen.pop(self._seen_order.popleft(), None)
            return True

    def _remember(self, sig_id: str) -> None:
        now = time.time()
        with self._lock:
            self._seen.setdefault(sig_id, now)
            self._seen_order.append(sig_id)
