"""Observation types produced by the log, process, and network watchers."""

from __future__ import annotations

from dataclasses import dataclass, field

FAIL = "fail"
SUCCESS = "success"
EXHAUSTED = "exhausted"  # sshd gave up after MaxAuthTries
INFO = "info"


@dataclass(frozen=True)
class AuthAttempt:
    ts: float
    service: str  # sshd | sudo | su | login
    status: str
    user: str = ""
    source: str = ""  # remote address, empty for local authentication
    port: int = 0
    detail: str = ""
    target_user: str = ""

    @property
    def remote(self) -> bool:
        return bool(self.source)


@dataclass(frozen=True)
class TcpConnection:
    local: str
    local_port: int
    remote: str
    remote_port: int
    state: str
    uid: int
    inode: int
    family: int = 4
    pid: int = 0
    comm: str = ""

    @property
    def endpoint(self) -> str:
        return f"{self.remote}:{self.remote_port}"


@dataclass
class ProcessRecord:
    pid: int
    ppid: int
    uid: int
    comm: str
    cmdline: tuple[str, ...] = ()
    exe: str = ""
    cwd: str = ""
    started_at: float = 0.0
    state: str = ""
    connections: tuple[TcpConnection, ...] = ()

    @property
    def line(self) -> str:
        return " ".join(self.cmdline) if self.cmdline else self.comm


@dataclass
class FileChange:
    path: str
    kind: str  # modified | created | deleted
    ts: float
    size: int = 0
    sha256: str = ""
    previous_sha256: str = ""
    added_lines: tuple[str, ...] = ()
    removed_lines: tuple[str, ...] = ()
    backup: str = ""
    detail: str = ""
