"""Operator configuration for a swarm agent.

One JSON file per host (`/etc/swarm/agent.json`). Values expand `~` and
`${HOME}`, and every capability can be switched off independently so the agent
can run on a laptop, a jump box, or a server with the same binary.
"""

from __future__ import annotations

import copy
import json
import os
import socket
from dataclasses import dataclass
from typing import Any

DEFAULTS: dict[str, Any] = {
    "node": {
        "name": "",
        "advertise_ip": "",
    },
    # monitor = detect, log, alert, and gossip. enforce = also mutate the host.
    "mode": "monitor",
    "swarm": {
        "key_file": "/etc/swarm/swarm.key",
        "bind_ip": "0.0.0.0",
        "bind_port": 9911,
        "peers": [],
        "peer_file": "",
        "discovery": {"enabled": False, "group": "239.255.77.88", "interval": 30.0},
        "max_new_per_second": 20,
    },
    "ssh": {
        "enabled": True,
        "logs": ["/var/log/auth.log"],
        "journal_units": ["sshd", "ssh"],
        "failures": 6,
        "window": 120.0,
        "max_attempts_exceeded": True,
        "block_ttl": 3600.0,
        "permanent_after": 18,
        "permanent_ttl": 86400.0,
    },
    "process": {
        "enabled": True,
        "poll_interval": 0.4,
        "history": 120.0,
        "quarantine_dirs": ["/tmp", "/var/tmp", "/dev/shm", "${HOME}/.cache"],
        "copy_payload": True,
        "max_copy_bytes": 2097152,
    },
    "network": {
        "enabled": True,
        "poll_interval": 1.0,
        "approved_file": "/var/lib/swarm/approved_endpoints.json",
        "grace": 20.0,
        "egress_block_ttl": 7200.0,
        "scan_ports": False,
    },
    "integrity": {
        "enabled": True,
        "interval": 5.0,
        "restore": True,
        "paths": [
            "${HOME}/.ssh/authorized_keys",
            "${HOME}/.ssh/config",
            "${HOME}/.bashrc",
            "${HOME}/.profile",
            "${HOME}/.config/autostart",
            "${HOME}/.config/systemd/user",
            "${HOME}/.local/share/systemd",
            "/etc/ssh/sshd_config",
            "/etc/rc.local",
            "/etc/ld.so.preload",
            "/etc/sudoers",
            "/etc/sudoers.d",
            "/etc/crontab",
            "/etc/cron.d",
            "/etc/systemd/system",
            "/lib/systemd/system",
        ],
    },
    "firewall": {
        "backend": "auto",  # auto | iptables | nftables | none
        "chain": "SWARM",
        "state_file": "/var/lib/swarm/blocks.json",
        "comment": "swarm-defense",
    },
    "guard": {
        # Never block these: operator consoles, VPN endpoints, management LANs.
        "allowlist": ["127.0.0.0/8", "::1"],
        "never_block_advertise_ip": True,
        "never_kill_comm": ["systemd", "init", "sshd", "systemd-journald", "dbus-daemon", "NetworkManager", "chronyd", "rsyslogd", "swarmd", "python3"],
        "never_kill_uids": [0],
        "protect_ssh_session": True,
    },
    "audit": {
        "dir": "/var/lib/swarm",
        "syslog": True,
        "keep_incidents": 2000,
    },
}


@dataclass
class ConfigError(Exception):
    path: str
    detail: str

    def __str__(self) -> str:
        return f"invalid configuration at {self.path}: {self.detail}"


def _deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def _expand(value):
    if isinstance(value, str):
        return os.path.expandvars(os.path.expanduser(value))
    if isinstance(value, list):
        return [_expand(v) for v in value]
    if isinstance(value, dict):
        return {k: _expand(v) for k, v in value.items()}
    return value


class Config:
    def __init__(self, data: dict, origin: str = "<defaults>") -> None:
        self.origin = origin
        self.data = _expand(data)

    @staticmethod
    def DEFAULTS_SNAPSHOT() -> dict:
        return copy.deepcopy(DEFAULTS)

    @classmethod
    def load(cls, path: str | None = None) -> "Config":
        data = copy.deepcopy(DEFAULTS)
        origin = path or "<defaults>"
        if path:
            with open(path, encoding="utf-8") as fh:
                data = _deep_merge(data, json.load(fh))
        config = cls(data, origin)
        config.validate()
        return config

    @classmethod
    def default(cls) -> "Config":
        config = cls(copy.deepcopy(DEFAULTS))
        config.validate()
        return config

    def validate(self) -> None:
        if self.data["mode"] not in ("monitor", "enforce"):
            raise ConfigError(self.origin, "mode must be 'monitor' or 'enforce'")
        firewall = self.data["firewall"]["backend"]
        if firewall not in ("auto", "iptables", "nftables", "none"):
            raise ConfigError(self.origin, "firewall.backend must be auto|iptables|nftables|none")
        if self.ssh["enabled"] and self.ssh["failures"] < 2:
            raise ConfigError(self.origin, "ssh.failures must be at least 2")
        if not 1 <= self.swarm["bind_port"] <= 65535:
            raise ConfigError(self.origin, "swarm.bind_port out of range")
        for peer in self.swarm["peers"]:
            if "address" not in peer or "port" not in peer:
                raise ConfigError(self.origin, f"peer {peer!r} needs address and port")

    def get(self, dotted: str, default: Any = None) -> Any:
        node: Any = self.data
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    def __getitem__(self, key: str) -> Any:
        return self.data[key]

    @property
    def ssh(self) -> dict:
        return self.data["ssh"]

    @property
    def swarm(self) -> dict:
        return self.data["swarm"]

    @property
    def process(self) -> dict:
        return self.data["process"]

    @property
    def network(self) -> dict:
        return self.data["network"]

    @property
    def integrity(self) -> dict:
        return self.data["integrity"]

    @property
    def firewall(self) -> dict:
        return self.data["firewall"]

    @property
    def guard(self) -> dict:
        return self.data["guard"]

    @property
    def audit(self) -> dict:
        return self.data["audit"]

    @property
    def enforce(self) -> bool:
        return self.data["mode"] == "enforce"

    def node_name(self) -> str:
        name = self.data["node"]["name"]
        return name or socket.gethostname().split(".")[0]

    def advertise_ip(self) -> str:
        configured = self.data["node"]["advertise_ip"]
        if configured:
            return configured
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # No packets leave here: connect() on a UDP socket only sets the route.
            sock.connect(("10.255.255.255", 1))
            return sock.getsockname()[0]
        except OSError:
            return "127.0.0.1"
        finally:
            sock.close()

    def dump(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.data, fh, indent=2)
            fh.write("\n")
