"""Threat signals: the vocabulary shared by detectors, responders, and peers.

A detector never touches the host. It produces a `Threat` describing what it saw
and which actions it would like; the responder decides, the guard rails veto, and
the swarm only ever transmits the part of a threat another node can act on
(an address to refuse traffic from, and why).
"""

from __future__ import annotations

import ipaddress
import time
from dataclasses import dataclass, field, replace

BLOCK = "block"
ALERT = "alert"
TAGS = (BLOCK, ALERT)

IN = "in"
OUT = "out"
BOTH = "both"
DIRECTIONS = (IN, OUT, BOTH)

# Detector identifiers, also the wire vocabulary for peer validation.
SSH_BRUTEFORCE = "ssh_bruteforce"
SSH_MAX_ATTEMPTS = "ssh_max_attempts"
CREDENTIAL_BREACH = "credential_breach"
REVERSE_SHELL = "reverse_shell"
C2_OUTBOUND = "c2_outbound"
DROPPER_EXEC = "dropper_exec"
TUNNEL_TOOL = "tunnel_tool"
PORT_SCAN = "port_scan"
PERSISTENCE = "persistence"
EXPLOIT_ATTEMPT = "exploit_attempt"
NEW_SOURCE_LOGIN = "new_source_login"
PRIV_ESC_ATTEMPT = "priv_esc_attempt"
NODE_ISOLATE = "node_isolate"
POLICY = "policy"

ATTACKS = (
    SSH_BRUTEFORCE,
    SSH_MAX_ATTEMPTS,
    CREDENTIAL_BREACH,
    REVERSE_SHELL,
    C2_OUTBOUND,
    DROPPER_EXEC,
    TUNNEL_TOOL,
    PORT_SCAN,
    PERSISTENCE,
    EXPLOIT_ATTEMPT,
    NEW_SOURCE_LOGIN,
    PRIV_ESC_ATTEMPT,
    NODE_ISOLATE,
    POLICY,
)

# Actions, in the order a responder should attempt them.
BLOCK_IN = "block_in"
BLOCK_OUT = "block_out"
KILL_PROCESS = "kill_process"
QUARANTINE_FILE = "quarantine_file"
RESTORE_PATHS = "restore_paths"
ALERT_ONLY = "alert_only"

SEVERITY = {
    SSH_BRUTEFORCE: 2,
    SSH_MAX_ATTEMPTS: 3,
    CREDENTIAL_BREACH: 3,
    REVERSE_SHELL: 3,
    C2_OUTBOUND: 3,
    DROPPER_EXEC: 2,
    TUNNEL_TOOL: 2,
    PORT_SCAN: 1,
    NEW_SOURCE_LOGIN: 1,
    NODE_ISOLATE: 3,
    POLICY: 1,
    PERSISTENCE: 3,
    EXPLOIT_ATTEMPT: 1,
    NEW_SOURCE_LOGIN: 1,
    PRIV_ESC_ATTEMPT: 2,
}

# How long peers should keep refusing traffic for this class, in seconds.
DEFAULT_TTL = {
    SSH_BRUTEFORCE: 3600.0,
    SSH_MAX_ATTEMPTS: 7200.0,
    CREDENTIAL_BREACH: 7200.0,
    REVERSE_SHELL: 14400.0,
    C2_OUTBOUND: 14400.0,
    DROPPER_EXEC: 7200.0,
    TUNNEL_TOOL: 7200.0,
    PORT_SCAN: 900.0,
    PERSISTENCE: 0.0,
    EXPLOIT_ATTEMPT: 600.0,
    PRIV_ESC_ATTEMPT: 600.0,
    NEW_SOURCE_LOGIN: 3600.0,
    NODE_ISOLATE: 3600.0,
    POLICY: 3600.0,
}


@dataclass
class ProcessInfo:
    """Everything the agent can attribute about the process behind a threat."""

    pid: int
    ppid: int = 0
    comm: str = ""
    cmdline: tuple[str, ...] = ()
    exe: str = ""
    cwd: str = ""
    uid: int = -1
    user: str = ""
    started_at: float = 0.0
    lineage: tuple[str, ...] = ()
    sha256: str = ""
    files: tuple[str, ...] = ()

    def brief(self) -> str:
        line = " ".join(self.cmdline)[:160] if self.cmdline else self.comm
        return f"pid={self.pid} uid={self.uid} {self.comm}: {line}"


@dataclass
class Threat:
    attack: str
    subject: str  # address to refuse traffic from, or local path for integrity hits
    evidence: str
    origin: str = ""
    tag: str = BLOCK
    direction: str = IN
    ttl: float = 0.0
    severity: int = 2
    actions: tuple[str, ...] = (BLOCK_IN,)
    process: ProcessInfo | None = None
    endpoints: tuple[str, ...] = ()
    ports: tuple[int, ...] = ()
    paths: tuple[str, ...] = ()
    observed_at: float = field(default_factory=time.time)
    details: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.ttl:
            self.ttl = DEFAULT_TTL.get(self.attack, 3600.0)
        self.severity = SEVERITY.get(self.attack, self.severity)

    @property
    def key(self) -> tuple[str, str, str]:
        """Identity for de-duplication across detectors and poll cycles."""
        return (self.attack, self.subject, self.direction)

    @property
    def peers_should_learn(self) -> bool:
        return self.tag == BLOCK and is_address(self.subject)

    def with_action(self, *actions: str) -> "Threat":
        return replace(self, actions=tuple(dict.fromkeys(self.actions + actions)))

    def as_dict(self) -> dict:
        return {
            "attack": self.attack,
            "subject": self.subject,
            "tag": self.tag,
            "direction": self.direction,
            "severity": self.severity,
            "ttl": self.ttl,
            "evidence": self.evidence,
            "origin": self.origin,
            "actions": list(self.actions),
            "endpoints": list(self.endpoints),
            "ports": list(self.ports),
            "paths": list(self.paths),
            "observed_at": self.observed_at,
            "process": (
                {
                    "pid": self.process.pid,
                    "ppid": self.process.ppid,
                    "comm": self.process.comm,
                    "cmdline": list(self.process.cmdline),
                    "exe": self.process.exe,
                    "cwd": self.process.cwd,
                    "uid": self.process.uid,
                    "user": self.process.user,
                    "lineage": list(self.process.lineage),
                    "sha256": self.process.sha256,
                    "files": list(self.process.files),
                }
                if self.process
                else None
            ),
            "details": self.details,
        }


def is_address(value: str) -> bool:
    try:
        ipaddress.ip_address(value.split("/")[0])
    except ValueError:
        return False
    return True
