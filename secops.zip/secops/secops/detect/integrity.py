"""Persistence watcher: the settings a reverse shell edits to stay installed.

Every path in `integrity.paths` is baselined, hashed, and backed up. When one
changes, the agent reports exactly which lines appeared or vanished, and in
enforce mode restores the previous content and quarantines the modified file.
Nothing here ever deletes a file the operator did not put under watch.
"""

from __future__ import annotations

import difflib
import glob
import hashlib
import json
import os
import re
import shutil
import stat
import time
from dataclasses import dataclass, field

from ..signals import ALERT, BLOCK, PERSISTENCE, Threat

MAX_TRACKED_BYTES = 512 * 1024
WALK_DEPTH = 3
_GLOB_CHARS = frozenset("*?[")
PERSISTENCE_MARKERS: tuple[tuple[str, re.Pattern], ...] = (
    ("remote_payload", re.compile(r"(curl|wget|http://|https://|/dev/tcp/|ftp://)", re.I)),
    ("pipe_to_shell", re.compile(r"\|\s*(?:ba)?sh\b", re.I)),
    ("temp_path_exec", re.compile(r"(?:/tmp/|/var/tmp/|/dev/shm/)\S+", re.I)),
    ("encoded_payload", re.compile(r"base64\s+(-d|--decode)|echo\s+[A-Za-z0-9+/]{60,}=", re.I)),
    ("reverse_listener", re.compile(r"\b(nc|ncat|socat)\b[^\n]{0,60}(-l|--listen|exec:)", re.I)),
    ("privilege_grant", re.compile(r"NOPASSWD|\ ALL=\(ALL", re.I)),
    ("authorized_key", re.compile(r"^(ssh-(?:rsa|ed25519|dss)|ecdsa-\S+)\s+\S+", re.I)),
    ("preload", re.compile(r"\.so\b", re.I)),
)


@dataclass
class TrackedFile:
    path: str
    sha256: str = ""
    size: int = 0
    mtime: float = 0.0
    backup: str = ""
    first_seen: float = field(default_factory=time.time)
    approved_at: float = 0.0


class IntegrityWatcher:
    name = "integrity"

    def __init__(self, config: dict, state_dir: str, emit) -> None:
        self.config = config
        self.state_dir = state_dir
        self.emit = emit
        self.watch_paths = tuple(config.get("paths", []))
        self.restore_enabled = bool(config.get("restore", True))
        self.backup_dir = os.path.join(state_dir, "backups")
        self.quarantine_dir = os.path.join(state_dir, "quarantine")
        self.manifest_file = os.path.join(state_dir, "integrity_manifest.json")
        self.tracked: dict[str, TrackedFile] = {}
        self.changes = 0
        self._load_manifest()

    # ---- manifest ----------------------------------------------------------
    def _load_manifest(self) -> None:
        try:
            with open(self.manifest_file, encoding="utf-8") as fh:
                payload = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return
        for path, item in payload.get("files", {}).items():
            self.tracked[path] = TrackedFile(
                path=path,
                sha256=item.get("sha256", ""),
                size=item.get("size", 0),
                mtime=item.get("mtime", 0.0),
                backup=item.get("backup", ""),
                first_seen=item.get("first_seen", time.time()),
                approved_at=item.get("approved_at", 0.0),
            )

    def save_manifest(self) -> None:
        os.makedirs(self.state_dir, exist_ok=True)
        payload = {
            "updated_at": time.time(),
            "files": {path: record.__dict__ for path, record in self.tracked.items()},
        }
        tmp = f"{self.manifest_file}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, default=str)
        os.replace(tmp, self.manifest_file)

    # ---- observation -------------------------------------------------------
    def targets(self) -> list[str]:
        found = []
        for entry in self.watch_paths:
            # `/home/*/.ssh/authorized_keys` is how you watch every real user,
            # so a glob is expanded on every pass; new homes appear by themselves.
            paths = sorted(glob.glob(entry)) if _GLOB_CHARS.intersection(entry) else [entry]
            for path in paths:
                if os.path.isdir(path):
                    found.extend(self._walk(path))
                else:
                    # A listed path that does not exist yet stays in the manifest, so a
                    # file the attacker *creates* there is caught as a change, not as unknown.
                    found.append(path)
        return sorted(set(found))

    def _walk(self, directory: str, depth: int = 0) -> list[str]:
        out = []
        if depth > WALK_DEPTH or not os.path.isdir(directory):
            return out
        try:
            for name in os.scandir(directory):
                if name.is_dir(follow_symlinks=False):
                    out.extend(self._walk(name.path, depth + 1))
                elif name.is_file(follow_symlinks=False):
                    out.append(name.path)
        except OSError:
            return out
        return out

    def tick(self) -> None:
        for path in self.targets():
            record = self.tracked.get(path) or TrackedFile(path=path)
            observed = self._observe(path)
            if record.sha256 == "" and observed is None:
                continue
            if observed is None and record.sha256:
                self._report_removed(path, record)
                continue
            if observed is None:
                # Never existed and still does not: baseline it as absent.
                record.sha256 = ""
                self.tracked[path] = record
                continue
            digest, size, mtime = observed
            if record.sha256 == digest:
                self.tracked[path] = record
                continue
            if not record.sha256:
                self._baseline(path, record, digest, size, mtime)
                continue
            self._report_change(path, record, digest, size, mtime)

    def _observe(self, path: str):
        try:
            st = os.stat(path)
        except OSError:
            return None
        if not stat.S_ISREG(st.st_mode) or st.st_size > MAX_TRACKED_BYTES:
            return None
        digest = self._hash(path)
        return digest, st.st_size, st.st_mtime

    @staticmethod
    def _hash(path: str) -> str:
        digest = hashlib.sha256()
        try:
            with open(path, "rb") as fh:
                for chunk in iter(lambda: fh.read(65536), b""):
                    digest.update(chunk)
        except OSError:
            return ""
        return digest.hexdigest()

    def _baseline(self, path: str, record: TrackedFile, digest: str, size: int, mtime: float) -> None:
        record.sha256, record.size, record.mtime = digest, size, mtime
        record.backup = self._backup(path, tag="baseline")
        record.first_seen = time.time()
        self.tracked[path] = record
        # Persist immediately: without this a restart finds an empty manifest and
        # silently accepts whatever the file looks like now, including a change
        # an attacker made while the agent was down.
        self.save_manifest()

    def _backup(self, path: str, tag: str = "baseline") -> str:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        safe = path.strip("/").replace("/", "%")
        destination = os.path.join(self.backup_dir, f"{safe}.{tag}.{stamp}")
        os.makedirs(self.backup_dir, exist_ok=True)
        try:
            shutil.copy2(path, destination)
        except OSError:
            return ""
        os.chmod(destination, 0o600)
        return destination

    # ---- reporting ---------------------------------------------------------
    def _report_change(self, path: str, record: TrackedFile, digest: str, size: int, mtime: float) -> None:
        self.changes += 1
        previous = record.backup
        added, removed = self._diff_lines(previous, path)
        markers = self._markers(added)
        new_backup = self._backup(path, tag="modified")
        evidence = f"{os.path.basename(path)} changed: +{len(added)} / -{len(removed)} lines"
        if markers:
            evidence += f"; persistence markers: {', '.join(markers)}"
        threat = Threat(
            attack=PERSISTENCE,
            subject=path,
            evidence=evidence[:400],
            origin=self.name,
            tag=BLOCK if markers or _sensitive(path) else ALERT,
            direction="in",
            severity=3 if markers else 2,
            ttl=0.0,
            actions=("restore_paths", "quarantine_file") if self.restore_enabled else ("quarantine_file",),
            paths=(path,),
            details={
                "previous_sha256": record.sha256,
                "current_sha256": digest,
                "added_lines": list(added)[:40],
                "removed_lines": list(removed)[:40],
                "markers": list(markers),
                "backup": previous,
                "modified_copy": new_backup,
            },
        )
        # The modified copy is evidence; the baseline remains the restore source.
        self.emit(threat)
        record.size, record.mtime = size, mtime
        if not markers and not _sensitive(path):
            record.sha256 = digest
            record.approved_at = time.time()
        self.tracked[path] = record
        self.save_manifest()

    def _report_removed(self, path: str, record: TrackedFile) -> None:
        self.changes += 1
        self.emit(
            Threat(
                attack=PERSISTENCE,
                subject=path,
                evidence=f"{os.path.basename(path)} disappeared from a watched location",
                origin=self.name,
                tag=BLOCK if _sensitive(path) else ALERT,
                direction="in",
                severity=2,
                ttl=0.0,
                actions=("restore_paths",) if self.restore_enabled else (),
                paths=(path,),
                details={"previous_sha256": record.sha256, "backup": record.backup},
            )
        )
        record.sha256 = ""
        self.tracked[path] = record
        self.save_manifest()

    @staticmethod
    def _diff_lines(previous: str | None, current: str) -> tuple[tuple, tuple]:
        old_text = _read_text(previous) if previous else ""
        new_text = _read_text(current)
        if old_text is None or new_text is None:
            return (), ()
        diff = list(
            difflib.unified_diff(
                old_text.splitlines(), new_text.splitlines(), lineterm="", n=0
            )
        )
        added = tuple(line[1:] for line in diff if line.startswith("+") and not line.startswith("+++"))
        removed = tuple(line[1:] for line in diff if line.startswith("-") and not line.startswith("---"))
        return added, removed

    @staticmethod
    def _markers(lines: tuple) -> tuple[str, ...]:
        found = set()
        for line in lines:
            for name, pattern in PERSISTENCE_MARKERS:
                if pattern.search(line):
                    found.add(name)
        return tuple(sorted(found))

    # ---- remediation -------------------------------------------------------
    def restore(self, path: str) -> tuple[bool, str]:
        """Write back the last approved content and re-baseline."""
        record = self.tracked.get(path)
        if record is None or not record.backup or not os.path.exists(record.backup):
            return False, "no baseline backup for this path"
        try:
            shutil.copy2(record.backup, path)
        except OSError as exc:
            return False, f"restore failed: {exc}"
        digest = self._hash(path)
        record.sha256 = digest
        record.size = os.path.getsize(path)
        record.mtime = os.stat(path).st_mtime
        self.tracked[path] = record
        self.save_manifest()
        return True, f"restored from {os.path.basename(record.backup)}"

    def quarantine(self, path: str) -> tuple[bool, str]:
        """Move a changed file out of the live path, keeping it for the operator."""
        if not os.path.exists(path):
            return False, "file is not present"
        if path not in self.tracked and not any(path.startswith(p.rstrip("/")) for p in self.watch_paths):
            return False, "path is not under watch"
        stamp = time.strftime("%Y%m%d-%H%M%S")
        destination = os.path.join(self.quarantine_dir, f"{path.strip('/').replace('/', '%')}.{stamp}")
        os.makedirs(self.quarantine_dir, exist_ok=True)
        try:
            shutil.move(path, destination)
        except OSError as exc:
            return False, f"quarantine failed: {exc}"
        os.chmod(destination, 0o600)
        record = self.tracked.get(path)
        if record:
            record.sha256 = ""
            self.tracked[path] = record
        self.save_manifest()
        return True, destination

    def approve(self, path: str) -> tuple[bool, str]:
        """Operator accepts the current content; it becomes the new baseline."""
        observed = self._observe(path)
        if observed is None:
            return False, "file is not readable or absent"
        digest, size, mtime = observed
        record = self.tracked.get(path) or TrackedFile(path=path)
        record.sha256, record.size, record.mtime = digest, size, mtime
        record.approved_at = time.time()
        record.backup = self._backup(path, tag="approved")
        self.tracked[path] = record
        self.save_manifest()
        return True, record.backup

    def snapshot(self) -> dict:
        return {
            "watched": len(self.tracked),
            "changes": self.changes,
            "restore_enabled": self.restore_enabled,
            "sensitive_drift": [
                path
                for path, record in self.tracked.items()
                if record.sha256 and os.path.exists(path) and self._hash(path) != record.sha256
            ][:10],
        }


def _read_text(path: str | None) -> str | None:
    if not path:
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read(MAX_TRACKED_BYTES)
    except OSError:
        return None


def _sensitive(path: str) -> bool:
    lowered = path.lower()
    markers = ("authorized_keys", "sshd_config", "sudoers", "ld.so.preload", "rc.local", "/cron", "systemd", "autostart", ".bashrc", ".profile")
    return any(marker in lowered for marker in markers)
