"""Connection watcher: outbound call-homes and inbound sweeps.

Two independent questions get answered here:
* is something on this host talking to an endpoint it has never used before, and
  is the process behind it worth trusting? (a scam link that just phoned home)
* is one address probing many ports at once? (reconnaissance before a break-in)

The watcher never kills or blocks; it emits Threats with the attribution it
managed to make, and the responder decides.
"""

from __future__ import annotations

import time
from collections import defaultdict

from .. import procfs
from ..signals import (
    ALERT,
    BLOCK,
    BLOCK_IN,
    BLOCK_OUT,
    C2_OUTBOUND,
    IN,
    KILL_PROCESS,
    OUT,
    PORT_SCAN,
    ProcessInfo,
    Threat,
)

COMMON_PORTS = frozenset({22, 53, 80, 123, 443, 465, 587, 853, 993, 995, 4433, 8443})
RISKY_COMM = ("sh", "bash", "dash", "zsh", "python", "python2", "python3", "perl", "ruby", "php",
              "node", "nc", "ncat", "netcat", "socat", "curl", "wget", "telnet", "awk", "lua",
              "expect", "deno", "bun", "busybox", "php-fpm")
SCAN_PORTS = 8
SCAN_SOURCES = 1


class NetWatcher:
    name = "net"

    def __init__(self, config: dict, netview, endpoints, firewall, emit, assessments=None) -> None:
        self.config = config
        self.netview = netview
        self.endpoints = endpoints
        self.firewall = firewall
        self.emit = emit
        self.assessments = assessments or {}
        self.grace = float(config.get("grace", 20.0))
        self.pending: dict[str, float] = {}
        self.reported: set[str] = set()
        self.scan_threshold = int(config.get("scan_ports", SCAN_PORTS))
        self.seen_cycles = 0
        self.threats = 0

    def tick(self) -> None:
        self.seen_cycles += 1
        self._watch_outbound()
        self._watch_scans()

    def _watch_outbound(self) -> None:
        now = time.time()
        live_endpoints = set()

        for connection in self.netview.outbound():
            if connection.remote in ("0.0.0.0", "::") or procfs.is_private(connection.remote):
                continue
            endpoint = connection.endpoint
            live_endpoints.add(endpoint)

            blocked = self._already_known_bad(connection.remote)
            if blocked:
                self._emit(
                    Threat(
                        attack=C2_OUTBOUND,
                        subject=connection.remote,
                        evidence=(
                            f"{connection.comm or 'pid ' + str(connection.pid)} still reaching "
                            f"{endpoint}, an address the swarm already refuses ({blocked['reason']})"
                        ),
                        origin=self.name,
                        tag=BLOCK,
                        direction=OUT,
                        severity=3,
                        ttl=float(self.config.get("egress_block_ttl", 14400.0)),
                        actions=(KILL_PROCESS, BLOCK_OUT),
                        process=self._process_info(connection),
                        endpoints=(endpoint,),
                        ports=(connection.remote_port,),
                        details={"existing_rule": blocked},
                    )
                )
                continue

            if self.endpoints.known(endpoint):
                self.pending.pop(endpoint, None)
                continue

            first_seen = self.pending.setdefault(endpoint, now)
            if now - first_seen < self.grace:
                continue
            if endpoint in self.reported:
                continue
            self._assess_new_endpoint(connection, endpoint, now)

        # Endpoints that went away before the grace period ended were transient.
        for endpoint in set(self.pending) - live_endpoints:
            self.pending.pop(endpoint, None)

    def _assess_new_endpoint(self, connection, endpoint: str, now: float) -> None:
        self.reported.add(endpoint)
        comm = (connection.comm or "").lower()
        risky = any(comm.startswith(prefix) for prefix in RISKY_COMM)
        odd_port = connection.remote_port not in COMMON_PORTS
        assessment = self.assessments.get(connection.pid)

        if assessment and assessment.confidence >= 0.6:
            # The process watcher already identified the shell; the connection is
            # the confirmation. Attach both halves to one incident.
            confidence = min(1.0, assessment.confidence + 0.2)
            evidence = (
                f"{assessment.attack} process pid {connection.pid} ({connection.comm}) connected to "
                f"{endpoint}; indicators: {', '.join(assessment.indicators)}"
            )
        elif risky and odd_port:
            confidence = 0.65
            evidence = (
                f"{connection.comm} (pid {connection.pid}, uid {connection.uid}) opened an unexpected "
                f"session to first-seen endpoint {endpoint}"
            )
        elif odd_port:
            confidence = 0.4
            evidence = f"{connection.comm or 'unknown'} reached new endpoint {endpoint} on port {connection.remote_port}"
        else:
            self.endpoints.note(endpoint)
            return

        actions = (BLOCK_OUT, KILL_PROCESS) if confidence >= 0.7 else ("alert_only",)
        self._emit(
            Threat(
                attack=C2_OUTBOUND,
                subject=connection.remote,
                evidence=evidence[:400],
                origin=self.name,
                tag=BLOCK if confidence >= 0.55 else ALERT,
                direction=OUT if confidence >= 0.55 else IN,
                severity=3 if confidence >= 0.75 else 2,
                ttl=float(self.config.get("egress_block_ttl", 14400.0)),
                actions=tuple(actions),
                process=self._process_info(connection),
                endpoints=(endpoint,),
                ports=(connection.remote_port,),
                details={
                    "confidence": round(confidence, 3),
                    "state": connection.state,
                    "local_port": connection.local_port,
                    "new_endpoint": True,
                },
            )
        )

    def _watch_scans(self) -> None:
        hits: dict[str, set] = defaultdict(set)
        for connection in self.netview.connections:
            if connection.state not in ("SYN_RECV",):
                continue
            if connection.remote in ("0.0.0.0", "::"):
                continue
            hits[connection.remote].add(connection.local_port)
        for source, ports in hits.items():
            if len(ports) < self.scan_threshold:
                continue
            self._emit(
                Threat(
                    attack=PORT_SCAN,
                    subject=source,
                    evidence=(
                        f"{len(ports)} half-open inbound connections to ports "
                        f"{', '.join(str(p) for p in sorted(ports)[:10])} - port sweep"
                    ),
                    origin=self.name,
                    tag=BLOCK,
                    direction=IN,
                    severity=1,
                    ttl=900.0,
                    actions=(BLOCK_IN,),
                    ports=tuple(sorted(ports)[:16]),
                    details={"targeted_ports": sorted(ports)[:64]},
                )
            )

    def _already_known_bad(self, address: str) -> dict | None:
        for rule in self.firewall.snapshot():
            if rule["address"] == address or rule["cidr"] == address:
                return rule
        return None

    def _process_info(self, connection) -> ProcessInfo | None:
        if not connection.pid:
            return None
        record = procfs.read_process(connection.pid)
        if record is None:
            return None
        identity = procfs.file_identity(record.exe) if record.exe else {}
        return ProcessInfo(
            pid=record.pid,
            ppid=record.ppid,
            comm=record.comm,
            cmdline=record.cmdline,
            exe=record.exe,
            cwd=record.cwd,
            uid=record.uid,
            user=procfs.user_name(record.uid),
            started_at=record.started_at,
            lineage=tuple(f"{comm}[{pid}]" for pid, comm in procfs.lineage(record.pid)),
            sha256=identity.get("sha256", ""),
            files=procfs.open_files(record.pid),
        )

    def _emit(self, threat: Threat) -> None:
        self.threats += 1
        self.emit(threat)

    def snapshot(self) -> dict:
        return {
            "cycles": self.seen_cycles,
            "threats": self.threats,
            "pending_endpoints": {k: round(time.time() - v, 1) for k, v in self.pending.items()},
            "reported": len(self.reported),
        }
