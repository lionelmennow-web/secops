"""Read real authentication telemetry: sshd/sudo/su lines from auth.log or journald.

Ubuntu writes these messages whether sshd logs to rsyslog (`/var/log/auth.log`)
or only to the journal, so both sources are supported and the agent degrades to
whichever is readable. Every parser names the exact log text it matches, so an
operator can confirm a detection against the audit trail.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import time

from ..events import EXHAUSTED, FAIL, INFO, SUCCESS, AuthAttempt
from ..tailing import FileFollower

SYSLOG_PREFIX = re.compile(
    r"^(?P<month>[A-Z][a-z]{2})\s+(?P<day>\s?\d{1,2})\s+(?P<clock>\d{2}:\d{2}:\d{2})\s+(?P<host>\S+)\s+"
)

PATTERNS: tuple[tuple[str, re.Pattern, dict], ...] = (
    (
        "ssh_failed_password",
        re.compile(
            r"sshd\[\d+\]:\s+Failed\s+(?P<method>password|publickey|keyboard-interactive/pam)\s+for\s+"
            r"(?:invalid user\s+)?(?P<user>\S+)\s+from\s+(?P<ip>[0-9a-fA-F:.]+)\s+port\s+(?P<port>\d+)"
        ),
        {"status": FAIL, "service": "sshd"},
    ),
    (
        "ssh_max_attempts",
        re.compile(
            r"sshd\[\d+\]:\s+error:\s+maximum authentication attempts exceeded for\s+"
            r"(?:invalid user\s+)?(?P<user>\S+)\s+from\s+(?P<ip>[0-9a-fA-F:.]+)\s+port\s+(?P<port>\d+)"
        ),
        {"status": EXHAUSTED, "service": "sshd"},
    ),
    (
        "ssh_invalid_user",
        re.compile(
            r"sshd\[\d+\]:\s+Invalid user\s+(?P<user>\S+)\s+from\s+(?P<ip>[0-9a-fA-F:.]+)\s+port\s+(?P<port>\d+)"
        ),
        {"status": INFO, "service": "sshd"},
    ),
    (
        "ssh_pam_failure",
        re.compile(
            r"pam_unix\((?P<service>[\w-]+):auth\):\s+authentication failure;.*?"
            r"rhost=(?P<ip>[0-9a-fA-F:.]*)\s+user=(?P<user>\S+)"
        ),
        {"status": FAIL},
    ),
    (
        "ssh_accepted",
        re.compile(
            r"sshd\[\d+\]:\s+Accepted\s+(?P<method>password|publickey|keyboard-interactive/pam)\s+for\s+"
            r"(?P<user>\S+)\s+from\s+(?P<ip>[0-9a-fA-F:.]+)\s+port\s+(?P<port>\d+)"
        ),
        {"status": SUCCESS, "service": "sshd"},
    ),
    (
        "sudo_bad_password",
        re.compile(r"sudo:\s+(?P<user>\S+)\s+:\s+(?P<count>\d+)\s+incorrect password attempts\s+;\s+TTY=(?P<tty>\S+)"),
        {"status": FAIL, "service": "sudo"},
    ),
    (
        "sudo_not_in_sudoers",
        re.compile(r"sudo:\s+(?P<user>\S+)\s+:\s+user NOT in sudoers\s+;\s+TTY=(?P<tty>\S+).*?COMMAND=(?P<cmd>.*)"),
        {"status": FAIL, "service": "sudo"},
    ),
    (
        "sudo_ok",
        re.compile(
            r"sudo:\s+(?P<user>\S+)\s+:\s+TTY=(?P<tty>\S+)\s+;\s+PWD=(?P<pwd>.*?)\s+;\s+USER=(?P<target>\S+)\s+;\s+COMMAND=(?P<cmd>.*)"
        ),
        {"status": SUCCESS, "service": "sudo"},
    ),
    (
        "su_failed",
        re.compile(r"su(?:\(|:)\S*\s*(?:auth\S*):\s+FAILED su for (?P<target>\S+) by (?P<user>\S+)"),
        {"status": FAIL, "service": "su"},
    ),
)

LOCAL_IPS = frozenset({"", "localhost", "127.0.0.1", "::1"})
MONTHS = {
    m: i + 1
    for i, m in enumerate(
        ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    )
}


def parse_line(line: str, now: float | None = None) -> AuthAttempt | None:
    """Turn one syslog/journal line into an AuthAttempt, or None if it is not auth traffic."""
    now = now if now is not None else time.time()
    body = line
    stamp = now

    prefix = SYSLOG_PREFIX.match(body)
    if prefix:
        stamp = _syslog_ts(prefix, now)
        body = body[prefix.end():]

    for name, pattern, fixed in PATTERNS:
        match = pattern.search(body)
        if not match:
            continue
        groups = match.groupdict()
        ip = (groups.get("ip") or "").strip()
        service = fixed.get("service") or groups.get("service") or "auth"
        if name == "ssh_pam_failure" and service == "sshd":
            # pam_unix duplicates the Failed password line for the same attempt.
            return None
        return AuthAttempt(
            ts=stamp,
            service=service,
            status=fixed["status"],
            user=groups.get("user") or "",
            source="" if ip in LOCAL_IPS else ip,
            port=int(groups["port"]) if groups.get("port") else 0,
            detail=name,
            target_user=groups.get("target") or "",
        )
    return None


def _syslog_ts(prefix: re.Match, now: float) -> float:
    """Syslog timestamps carry no year; resolve it against the observer's clock.

    rsyslog writes local time, so mktime is the right decoder even though the
    agent compares everything else in UTC.
    """
    reference = time.localtime(now)
    month = MONTHS.get(prefix["month"], reference.tm_mon)
    day = int(prefix["day"])
    hour, minute, second = (int(part) for part in prefix["clock"].split(":"))
    for year in (reference.tm_year, reference.tm_year - 1):
        stamp = time.mktime((year, month, day, hour, minute, second, 0, 0, -1))
        if stamp <= now + 3600:
            return stamp
    return now


class AuthWatcher:
    """Collects auth events from files and journald, then hands them to rules."""

    def __init__(self, config: dict, on_event, log=print) -> None:
        self.config = config
        self.on_event = on_event
        self.log = log
        self.sources: list[str] = []
        self.read_lines = 0
        self.matched = 0
        self._followers: list[FileFollower] = []
        self._journal: subprocess.Popen | None = None
        self._threads: list[threading.Thread] = []
        self._stop = threading.Event()

    def start(self) -> list[str]:
        """Follow every configured log, then fall back to the journal.

        A path that is missing or unreadable right now is still followed: logs
        appear when rsyslog starts, and permissions change when the operator adds
        the agent user to the adm group.
        """
        for path in self.config.get("logs", []):
            if not os.path.exists(path):
                self.log(f"auth watcher: {path} does not exist yet; following it anyway")
            elif not os.access(path, os.R_OK):
                self.log(f"auth watcher: {path} is not readable (add this user to the adm group)")
            follower = FileFollower(path, self._handle_line, from_start=False)
            follower.start()
            self._followers.append(follower)
            self.sources.append(f"file:{path}")
        if not self.config.get("logs") and self.config.get("journal_units"):
            self._start_journal(self.config["journal_units"])
        if not self.sources:
            self.log("auth watcher: no log paths and no journal units configured; auth detection idle")
        return self.sources

    def stop(self) -> None:
        self._stop.set()
        for follower in self._followers:
            follower.stop()
        if self._journal:
            self._journal.terminate()
            try:
                self._journal.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self._journal.kill()

    def _start_journal(self, units: list[str]) -> None:
        if not shutil.which("journalctl"):
            return
        argv = ["journalctl", "-f", "-o", "json", *_unit_args(units)]
        try:
            self._journal = subprocess.Popen(
                argv, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, bufsize=1
            )
        except OSError as exc:
            self.log(f"auth watcher: journalctl failed: {exc}")
            return
        self.sources.append(f"journal:{','.join(units)}")
        thread = threading.Thread(target=self._drain_journal, name="journalctl", daemon=True)
        thread.start()
        self._threads.append(thread)

    def _drain_journal(self) -> None:
        assert self._journal and self._journal.stdout
        for raw in self._journal.stdout:
            if self._stop.is_set():
                return
            try:
                record = json.loads(raw)
            except json.JSONDecodeError:
                self._handle_line(raw.rstrip("\n"))
                continue
            message = record.get("MESSAGE", "")
            stamp = record.get("__REALTIME_TIMESTAMP")
            now = int(stamp) / 1_000_000 if stamp else None
            self._handle_line(message, now=now)

    def _handle_line(self, line: str, now: float | None = None) -> None:
        self.read_lines += 1
        event = parse_line(line, now=now)
        if event is None:
            return
        self.matched += 1
        self.on_event(event)


def _unit_args(units: list[str]) -> list[str]:
    args = []
    for unit in units:
        args += ["-u", unit]
    return args
