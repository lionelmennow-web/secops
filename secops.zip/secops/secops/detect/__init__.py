"""Detectors observe the host and emit Threats. None of them touch the system."""
