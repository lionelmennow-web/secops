"""Brute-force and credential-abuse rules over authentication events.

Every rule is a window count against the audit trail, so a blocked address can
always be explained by quoting the log lines that caused it.
"""

from __future__ import annotations

import json
import os
import time
from collections import defaultdict, deque

from ..events import EXHAUSTED, FAIL, SUCCESS, AuthAttempt
from ..signals import (
    ALERT,
    BLOCK,
    BLOCK_IN,
    CREDENTIAL_BREACH,
    NEW_SOURCE_LOGIN,
    PRIV_ESC_ATTEMPT,
    SSH_BRUTEFORCE,
    SSH_MAX_ATTEMPTS,
    Threat,
)

REPEAT_SUPPRESS = 30.0


class AuthRules:
    name = "auth"

    def __init__(self, config: dict, state_dir: str, emit) -> None:
        self.config = config
        self.state_dir = state_dir
        self.emit = emit
        self.window = float(config.get("window", 120.0))
        self.threshold = int(config.get("failures", 6))
        self.permanent_after = int(config.get("permanent_after", 18))
        self.block_ttl = float(config.get("block_ttl", 3600.0))
        self.permanent_ttl = float(config.get("permanent_ttl", 86400.0))
        self._failures: dict[str, deque] = defaultdict(deque)
        self._last_emit: dict[tuple, float] = {}
        self._known_sources: set[str] = set()
        self._known_file = os.path.join(state_dir, "approved_login_sources.json")
        self.decisions = 0
        self._load_known()

    def _load_known(self) -> None:
        try:
            with open(self._known_file, encoding="utf-8") as fh:
                self._known_sources = set(json.load(fh).get("sources", []))
        except (OSError, json.JSONDecodeError):
            self._known_sources = set()

    def _save_known(self) -> None:
        os.makedirs(self.state_dir, exist_ok=True)
        tmp = f"{self._known_file}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"updated_at": time.time(), "sources": sorted(self._known_sources)}, fh, indent=2)
        os.replace(tmp, self._known_file)

    def handle(self, event: AuthAttempt) -> None:
        if event.service == "sudo" and not event.remote:
            self._local_privilege(event)
            return
        if event.service == "su" and not event.remote:
            self._local_privilege(event)
            return
        if not event.remote:
            return
        if event.status == SUCCESS:
            self._successful_login(event)
            return
        if event.status == EXHAUSTED:
            self._emit(
                Threat(
                    attack=SSH_MAX_ATTEMPTS,
                    subject=event.source,
                    evidence=f"sshd gave up after MaxAuthTries for {event.user!r} from {event.source}",
                    origin=self.name,
                    tag=BLOCK,
                    direction="in",
                    ttl=self.block_ttl * 2,
                    actions=(BLOCK_IN,),
                    ports=(int(event.port or 0),) if event.port else (),
                    details={"user": event.user, "service": event.service},
                )
            )
            return
        if event.status != FAIL:
            return

        now = event.ts if event.ts <= time.time() + self.window else time.time()
        failures = self._failures[event.source]
        failures.append(now)
        while failures and now - failures[0] > self.window:
            failures.popleft()

        count = len(failures)
        if count >= self.threshold:
            escalated = count >= self.permanent_after
            self._emit(
                Threat(
                    attack=SSH_BRUTEFORCE,
                    subject=event.source,
                    evidence=(
                        f"{count} failed logins from {event.source} in {self.window:.0f}s "
                        f"(last user {event.user!r})"
                    ),
                    origin=self.name,
                    tag=BLOCK,
                    direction="in",
                    ttl=self.permanent_ttl if escalated else self.block_ttl,
                    actions=(BLOCK_IN,),
                    details={"user": event.user, "service": event.service, "window": self.window},
                )
            )

    def _successful_login(self, event: AuthAttempt) -> None:
        failures = self._failures.get(event.source)
        had_failures = bool(failures)
        if had_failures:
            self._emit(
                Threat(
                    attack=CREDENTIAL_BREACH,
                    subject=event.source,
                    evidence=(
                        f"{event.user!r} authenticated from {event.source} immediately after "
                        f"{len(failures)} failed attempts - credential likely guessed"
                    ),
                    origin=self.name,
                    tag=BLOCK,
                    direction="both",
                    ttl=self.permanent_ttl,
                    actions=(BLOCK_IN, "block_out", "alert_only"),
                    details={"user": event.user, "method": event.detail},
                )
            )
            self._failures[event.source] = deque()
            return

        if event.source not in self._known_sources:
            self._known_sources.add(event.source)
            self._save_known()
            self._emit(
                Threat(
                    attack=NEW_SOURCE_LOGIN,
                    subject=event.source,
                    evidence=f"first recorded successful login for {event.user!r} from {event.source}",
                    origin=self.name,
                    tag=ALERT,
                    direction="in",
                    actions=("alert_only",),
                    details={"user": event.user},
                )
            )

    def _local_privilege(self, event: AuthAttempt) -> None:
        """Local sudo/su abuse is not network-blockable; it is an operator alert."""
        if event.status != FAIL:
            return
        self._emit(
            Threat(
                attack=PRIV_ESC_ATTEMPT,
                subject=f"local:{event.user or 'unknown'}",
                evidence=f"{event.service} authentication failure for {event.user!r} ({event.detail})",
                origin=self.name,
                tag=ALERT,
                direction="in",
                actions=("alert_only",),
                details={"tty": event.detail},
            )
        )

    def _emit(self, threat: Threat) -> None:
        """Report one threat per subject/class per short window; the responder
        refreshes the block TTL on each repeat, so persistent attackers stay out."""
        now = time.time()
        key = threat.key
        if now - self._last_emit.get(key, 0.0) < REPEAT_SUPPRESS:
            return
        self._last_emit[key] = now
        self.decisions += 1
        self.emit(threat)

    def snapshot(self) -> dict:
        return {
            "decisions": self.decisions,
            "watched_sources": len(self._failures),
            "active_windows": {
                source: len(values)
                for source, values in self._failures.items()
                if values and time.time() - values[-1] < self.window * 2
            },
            "known_sources": len(self._known_sources),
        }
