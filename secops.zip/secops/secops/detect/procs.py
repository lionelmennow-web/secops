"""Exec-time detection: catch the reverse shell a scam link just opened.

The agent samples the process table and evaluates a transparent grammar of
exploit indicators. Each hit carries a weight, and correlated context adds more:
an open outbound socket to a never-before-seen endpoint, a dropper path, or a
shell spawned underneath a browser or mail client. The responder only kills or
blocks above a confidence floor, which is why an ordinary `python -c` on a
developer laptop does not get the operator locked out of their own tools.
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass

from .. import procfs
from ..signals import (
    BOTH,
    BLOCK,
    BLOCK_IN,
    BLOCK_OUT,
    DROPPER_EXEC,
    IN,
    KILL_PROCESS,
    ALERT,
    QUARANTINE_FILE,
    REVERSE_SHELL,
    TUNNEL_TOOL,
    ProcessInfo,
    Threat,
)

INTERPRETERS = ("sh", "bash", "dash", "zsh", "ksh", "csh", "fish", "python", "python2", "python3",
                "perl", "ruby", "php", "node", "awk", "gawk", "lua", "expect", "telnet", "nc",
                "ncat", "netcat", "socat", "curl", "wget", "tar", "make")

LAUNCHERS = ("browser", "firefox", "chrome", "chromium", "msedge", "thunderbird", "librewolf",
             "brave", "opera", "edge", "outlook", "snap", "flatpak", "electron", "soffice",
             "libreoffice", "xdg-open", "xdg-open", "gio", "nautilus", "code", "code-url-handler")

SIGNATURES: tuple[tuple[str, re.Pattern, str, float], ...] = (
    (
        "bash_tcp_redirect",
        re.compile(r"/dev/(?:tcp|udp)/[0-9a-zA-Z.\-]"),
        REVERSE_SHELL,
        0.75,
    ),
    (
        "netcat_exec",
        re.compile(r"\b(?:nc|ncat|netcat)\b[^\n]{0,90}?(?:\s-[a-z]*e\b|\s-(?:c|k)\s|\s--exec\b|\s-e\s)"),
        REVERSE_SHELL,
        0.7,
    ),
    (
        "socat_system",
        re.compile(r"\bsocat\b[^\n]{0,120}?(?:exec:|system:|shell:|pty:)", re.I),
        REVERSE_SHELL,
        0.7,
    ),
    (
        "interpreter_socket_dup2",
        re.compile(
            r"(?:socket\.socket|fsockopen|TCPSocket|IO::Socket|Socket::TCP|SOCK_STREAM|"
            r"subprocess\.|pty\.spawn|os\.dup2|IO\.Redirect|Proc\.new)",
            re.I,
        ),
        REVERSE_SHELL,
        0.55,
    ),
    (
        "named_pipe_shell",
        re.compile(r"\bmkfifo\b[^\n]{0,80}?(?:/tmp/|/dev/shm/|\.fifo)|\bmkfifo\b.*\|\s*(?:ba|z|k|da)?sh\b", re.I),
        REVERSE_SHELL,
        0.7,
    ),
    (
        "pipe_to_shell",
        re.compile(
            r"(?:curl|wget)[^\n]{0,140}?\|\s*(?:ba|z|k|da|c|fish)?sh\b|"
            r"(?:ba|z|k|da)?sh\s+<\s*\(\s*(?:curl|wget)",
            re.I,
        ),
        REVERSE_SHELL,
        0.6,
    ),
    (
        "base64_to_shell",
        re.compile(r"base64\s+(-d|--decode)[^\n]{0,80}?\|\s*(?:ba)?sh\b|echo\s+[A-Za-z0-9+/]{40,}={0,2}\s*\|\s*base64\s+-d", re.I),
        REVERSE_SHELL,
        0.6,
    ),
    (
        # A socket marker alone can be legitimate tooling; a socket marker wired
        # straight into a process spawn is the reverse-shell shape.
        "socket_to_process_spawn",
        re.compile(
            r"(?:socket\.socket|fsockopen|TCPSocket|IO::Socket|SOCK_STREAM)[^\n]{0,200}?"
            r"(?:subprocess\.|os\.dup2|pty\.spawn|\bexec\b|\bsystem\b|Proc\.new|/bin/sh|/bin/bash)",
            re.I,
        ),
        REVERSE_SHELL,
        0.3,
    ),
    (
        "tunnel_tool",
        re.compile(
            r"\b(?:chisel|frpc|frps|ngrok|cloudflared|bore|rathole|ligolo|ligoltun|ew|reGeorg|suo5)\b"
            r"|\bssh\b[^\n]{0,80}?\s-R\s|\bssh\b[^\n]{0,80}?\s-w\sN\b",
            re.I,
        ),
        TUNNEL_TOOL,
        0.45,
    ),
)

DROPPER_DIRS_DEFAULT = ("/tmp", "/var/tmp", "/dev/shm", "/run/user")
MIN_CONFIDENCE = 0.5
SUPPRESS_WINDOW = 20.0


@dataclass(frozen=True)
class ExecAssessment:
    attack: str
    confidence: float
    indicators: tuple[str, ...]
    reasons: tuple[str, ...]
    remote_endpoints: tuple[str, ...]
    remote_addresses: tuple[str, ...]


class ProcessWatcher:
    name = "procs"

    def __init__(self, config: dict, netview, emit, approve_endpoint=None) -> None:
        self.config = config
        self.netview = netview
        self.emit = emit
        self.approve_endpoint = approve_endpoint
        self.quarantine_dirs = tuple(config.get("quarantine_dirs", DROPPER_DIRS_DEFAULT))
        self.history_window = float(config.get("history", 120.0))
        self.known: dict[int, float] = {}
        self.assessed: dict[int, ExecAssessment] = {}
        self.last_threat: dict[tuple, float] = {}
        self.scans = 0
        self.threats = 0

    def start(self) -> None:
        # Processes born before the agent started are not evidence of a fresh
        # click; adopt them silently so a rebooted agent does not kill its host.
        for pid in procfs.list_pids():
            self.known[pid] = 0.0

    def tick(self) -> None:
        self.scans += 1
        now = time.time()
        live = set(procfs.list_pids())
        for pid in live - set(self.known):
            self._evaluate_new(pid, now)
        for pid in list(self.known):
            if pid not in live:
                self.known.pop(pid, None)
                self.assessed.pop(pid, None)
        for pid in set(self.known) - live:
            self.known.pop(pid, None)

    def _evaluate_new(self, pid: int, now: float) -> None:
        record = procfs.read_process(pid)
        if record is None:
            return
        self.known[pid] = now
        if record.pid == os.getpid():
            return
        assessment = self.assess(record)
        if assessment is None or assessment.confidence < MIN_CONFIDENCE:
            return
        self.assessed[pid] = assessment
        self._emit_for(record, assessment)

    def assess(self, record) -> ExecAssessment | None:
        line = record.line
        if not line:
            return None
        indicators: list[str] = []
        reasons: list[str] = []
        confidence = 0.0
        best_class = REVERSE_SHELL
        best_weight = 0.0

        for name, pattern, class_name, weight in SIGNATURES:
            if pattern.search(line):
                indicators.append(name)
                confidence += weight
                if weight > best_weight:
                    best_weight, best_class = weight, class_name
        if "socket_to_process_spawn" in indicators and best_weight < 0.55:
            confidence += 0.15
        attack = best_class
        if not indicators:
            indicators, confidence, attack, reasons = self._dropper(record, line, indicators, confidence)
            if not indicators:
                return None

        connections = self.netview.connections_of(record.pid)
        fresh_endpoints, addresses = self._fresh_endpoints(connections, record)
        if fresh_endpoints:
            confidence += 0.3
            reasons.append(f"outbound to never-seen endpoint(s): {', '.join(fresh_endpoints[:4])}")
        elif connections:
            confidence += 0.05

        if self._browser_lineage(record):
            confidence += 0.25
            reasons.append("spawned beneath a browser, mail client, or document viewer")
        if self._quarantine_path(record):
            confidence += 0.15
            reasons.append(f"runs from a user-writable path: {self._quarantine_path(record)}")
        if record.uid != 0 and any(word in line.lower() for word in ("sudo", "su ", "setuid", "pkexec")):
            confidence += 0.1
            reasons.append("attempts privilege change")

        return ExecAssessment(
            attack=attack,
            confidence=round(min(confidence, 1.0), 3),
            indicators=tuple(indicators),
            reasons=tuple(reasons),
            remote_endpoints=tuple(fresh_endpoints),
            remote_addresses=addresses,
        )

    def _dropper(self, record, line: str, indicators, confidence):
        """An interpreter executing a script from a world-writable directory."""
        path = self._quarantine_path(record)
        if not path:
            return indicators, confidence, REVERSE_SHELL, []
        interpreter = os.path.basename(record.exe or record.comm)
        if interpreter not in INTERPRETERS and not any(
            arg.startswith("/") and arg.endswith((".sh", ".py", ".pl", ".rb", ".php", ".js")) for arg in record.cmdline
        ):
            return indicators, confidence, REVERSE_SHELL, []
        return (
            ["dropper_path_exec"],
            max(confidence, 0.5),
            DROPPER_EXEC,
            [f"interpreter {interpreter} executing {path}"],
        )

    def _quarantine_path(self, record) -> str:
        candidates = (record.exe, record.cwd) + tuple(
            arg for arg in record.cmdline[1:] if arg.startswith("/")
        )
        for candidate in candidates:
            if not candidate:
                continue
            for directory in self.quarantine_dirs:
                if candidate.startswith(directory.rstrip("/") + "/") or candidate == directory:
                    return candidate
        return ""

    def _browser_lineage(self, record) -> bool:
        for _pid, comm in procfs.lineage(record.ppid):
            lowered = comm.lower()
            if any(launcher in lowered for launcher in LAUNCHERS):
                return True
        return False

    def _fresh_endpoints(self, connections, record) -> tuple[list, tuple]:
        endpoints: list[str] = []
        addresses: set = set()
        for connection in connections:
            if connection.state not in ("ESTABLISHED", "SYN_SENT", "CLOSE_WAIT"):
                continue
            if connection.remote in ("0.0.0.0", "::") or procfs.is_private(connection.remote):
                continue
            endpoint = connection.endpoint
            if self.approve_endpoint and self.approve_endpoint(endpoint):
                continue
            endpoints.append(endpoint)
            addresses.add(connection.remote)
        return endpoints, tuple(addresses)

    def _emit_for(self, record, assessment: ExecAssessment) -> None:
        now = time.time()
        key = (record.pid, assessment.attack)
        if now - self.last_threat.get(key, 0.0) < SUPPRESS_WINDOW:
            return
        self.last_threat[key] = now
        self.threats += 1

        subject = assessment.remote_addresses[0] if assessment.remote_addresses else ""
        process = self._process_info(record)
        evidence = " | ".join(
            [f"{assessment.attack} confidence {assessment.confidence:.2f}"]
            + list(assessment.indicators)
            + list(assessment.reasons)
        )[:400]

        actions = []
        if assessment.confidence >= 0.7:
            actions.append(KILL_PROCESS)
        if subject:
            actions += [BLOCK_OUT, BLOCK_IN]
        if record.exe and self._quarantine_path(record):
            actions.append(QUARANTINE_FILE)
        if not actions:
            actions = ["alert_only"]

        threat = Threat(
            attack=assessment.attack,
            subject=subject or f"local:{record.pid}",
            evidence=evidence,
            origin=self.name,
            tag=BLOCK if subject or assessment.confidence >= 0.7 else ALERT,
            direction=BOTH if subject else IN,
            severity=3 if assessment.confidence >= 0.8 else 2,
            actions=tuple(actions),
            process=process,
            endpoints=assessment.remote_endpoints,
            ports=tuple(
                connection.remote_port
                for connection in self.netview.connections_of(record.pid)
                if connection.remote_port
            )[:8],
            paths=tuple(p for p in (record.exe, record.cwd) if p),
            details={
                "confidence": assessment.confidence,
                "indicators": list(assessment.indicators),
                "reasons": list(assessment.reasons),
                "lineage": [[pid, comm] for pid, comm in procfs.lineage(record.pid)],
                "open_files": list(process.files)[:12],
            },
        )
        self.emit(threat)

    def _process_info(self, record) -> ProcessInfo:
        identity = procfs.file_identity(record.exe) if record.exe else {}
        return ProcessInfo(
            pid=record.pid,
            ppid=record.ppid,
            comm=record.comm,
            cmdline=record.cmdline,
            exe=record.exe,
            cwd=record.cwd,
            uid=record.uid,
            user=procfs.user_name(record.uid),
            started_at=record.started_at,
            lineage=tuple(f"{comm}[{pid}]" for pid, comm in procfs.lineage(record.pid)),
            sha256=identity.get("sha256", ""),
            files=procfs.open_files(record.pid),
        )

    def snapshot(self) -> dict:
        return {
            "scans": self.scans,
            "tracked_processes": len(self.known),
            "threats": self.threats,
            "live_assessments": {
                str(pid): {"attack": a.attack, "confidence": a.confidence, "indicators": list(a.indicators)}
                for pid, a in self.assessed.items()
            },
        }
