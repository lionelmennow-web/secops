"""The responder: the only code in the agent that changes the host.

Every action passes three gates. `Guard` refuses anything that would cut off the
operator or kill something it must not touch. `mode` decides whether the action
is executed at all - in monitor mode the agent records exactly what it *would*
have done, which is how a new deployment gets trusted before it is armed. And
each executed action stores an undo record so `swarmctl rollback` can reverse a
false positive.
"""

from __future__ import annotations

import ipaddress
import json
import os
import re
import shutil
import signal
import socket
import time

from . import procfs
from .firewall import Firewall, Rule
from .signals import (
    ALERT_ONLY,
    BOTH,
    IN,
    OUT,
    BLOCK_IN,
    BLOCK_OUT,
    KILL_PROCESS,
    QUARANTINE_FILE,
    RESTORE_PATHS,
    Threat,
)

PROTECTED_COMM = (
    "systemd", "init", "kthreadd", "sshd", "systemd-journald", "systemd-logind", "dbus-daemon",
    "NetworkManager", "systemd-networkd", "chronyd", "ntpd", "rsyslogd", "swarmd", "swarm-agent",
    "dockerd", "containerd", "kubelet", "rsync", "agetty", "login", "bash", "zsh", "fish",
)
KERNEL_PGID = 2
MAX_EVIDENCE_FILES = 40
ROLLBACKABLE = {BLOCK_IN, BLOCK_OUT, KILL_PROCESS, QUARANTINE_FILE, RESTORE_PATHS}


class Guard:
    """Refusals that keep the swarm from shooting itself in the foot."""

    def __init__(self, config: dict, own_pid: int, advertise_ip: str, peers: list[str]) -> None:
        self.allowlist = list(config.get("allowlist", []))
        self.never_kill_comm = set(config.get("never_kill_comm", PROTECTED_COMM))
        self.protect_ssh = bool(config.get("protect_ssh_session", True))
        self.own_pid = own_pid
        self.advertise_ip = advertise_ip
        self.peers = set(peers)
        self.resolvers = _resolver_addresses()
        self.protected_addresses = self._protected()
        self.ancestry = {pid for pid, _comm in procfs.lineage(own_pid)}
        self.refusals = 0

    def _protected(self) -> set[str]:
        protected = {self.advertise_ip, "127.0.0.1", "::1"}
        protected |= self.peers | self.resolvers
        return {entry for entry in protected if entry}

    def may_block(self, address: str) -> tuple[bool, str]:
        try:
            ip = ipaddress.ip_address(address.split("/")[0])
        except ValueError:
            self.refusals += 1
            return False, f"{address!r} is not an address"
        for entry in self.allowlist:
            try:
                if ip in ipaddress.ip_network(entry, strict=False):
                    self.refusals += 1
                    return False, f"{address} is inside the operator allowlist ({entry})"
            except ValueError:
                continue
        if str(ip) in self.protected_addresses:
            self.refusals += 1
            return False, f"{address} protects this host's own connectivity"
        return True, "allowed"

    def may_kill(self, pid: int, comm: str, uid: int, confidence: float) -> tuple[bool, str]:
        if pid in (0, 1) or pid == self.own_pid:
            self.refusals += 1
            return False, f"refusing to kill pid {pid}"
        record = procfs.read_process(pid)
        if record is None:
            return False, "process is already gone"
        if record.ppid == KERNEL_PGID:
            self.refusals += 1
            return False, f"pid {pid} is a kernel thread"
        if comm in self.never_kill_comm or record.comm in self.never_kill_comm:
            self.refusals += 1
            return False, f"{comm} is on the protected process list"
        lineage = {ancestor for ancestor, _name in procfs.lineage(pid)}
        if lineage & self.ancestry:
            self.refusals += 1
            return False, "process is part of the agent's own ancestry"
        if self.protect_ssh and _ssh_session(pid) and confidence < 0.85:
            self.refusals += 1
            return False, "process belongs to an interactive SSH session; confidence below 0.85"
        return True, "allowed"


def _resolver_addresses() -> set[str]:
    found = set()
    try:
        with open("/etc/resolv.conf", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                parts = line.split()
                if parts and parts[0] in ("nameserver", "Nameserver") and len(parts) > 1:
                    found.add(parts[1])
    except OSError:
        pass
    return found


def _ssh_session(pid: int) -> bool:
    for ancestor_pid, comm in procfs.lineage(pid):
        if comm in ("sshd", "login", "systemd-logind"):
            return True
    return False


class Responder:
    def __init__(
        self,
        config,
        firewall: Firewall,
        guard: Guard,
        audit,
        integrity=None,
        endpoint_history=None,
        netview=None,
    ) -> None:
        self.config = config
        self.firewall = firewall
        self.guard = guard
        self.audit = audit
        self.integrity = integrity
        self.endpoints = endpoint_history
        self.netview = netview
        self.mode = config.data["mode"]
        self.state_dir = config.audit["dir"]
        self.evidence_dir = os.path.join(self.state_dir, "evidence")
        self.executed = 0
        self.planned = 0
        self.denied = 0

    @property
    def enforcing(self) -> bool:
        return self.mode == "enforce"

    def handle(self, threat: Threat, sig_id: str = "", origin_node: str = "") -> int:
        incident_id, _new = self.audit.open_incident(threat, sig_id=sig_id)
        if not threat.actions or all(action == ALERT_ONLY for action in threat.actions):
            self.audit.note(incident_id, "alert only: no host change proposed")
            self.audit.set_state(incident_id, "noted")
            return incident_id

        for action in threat.actions:
            self._act(incident_id, action, threat, origin_node)
        if not self.enforcing:
            self.audit.set_state(incident_id, "monitor")
        return incident_id

    # ---- actions -----------------------------------------------------------
    def _act(self, incident_id: int, action: str, threat: Threat, origin_node: str) -> None:
        handler = {
            BLOCK_IN: self._block,
            BLOCK_OUT: self._block,
            KILL_PROCESS: self._kill,
            QUARANTINE_FILE: self._quarantine,
            RESTORE_PATHS: self._restore,
        }.get(action)
        if handler is None:
            return
        handler(incident_id, action, threat, origin_node)

    def _block(self, incident_id: int, action: str, threat: Threat, origin_node: str) -> None:
        address = threat.subject
        direction = IN if action == BLOCK_IN else OUT
        ok, reason = self.guard.may_block(address)
        if not ok:
            self.denied += 1
            self.audit.record_action(incident_id, action, address, False, f"guard refused: {reason}")
            return
        rule = Rule(
            address=address,
            direction=direction,
            reason=f"{threat.attack}: {threat.evidence}"[:200],
            expires_at=time.time() + max(threat.ttl, 5.0),
            source=origin_node or "local",
            ports=threat.ports[:16] if threat.direction != BOTH else (),
        )
        installed, detail = self.firewall.protect(rule)
        if not self.enforcing:
            self.planned += 1
        else:
            self.executed += 1 if installed else 0
        self.audit.record_action(
            incident_id,
            action,
            address,
            installed,
            detail,
            undo={"kind": "unblock", "address": address, "direction": direction},
        )
        if action == BLOCK_OUT and self.endpoints is not None:
            for endpoint in threat.endpoints:
                self.endpoints.revoke(endpoint)

    def _kill(self, incident_id: int, action: str, threat: Threat, origin_node: str) -> None:
        process = threat.process
        if process is None:
            self.audit.record_action(incident_id, action, "none", False, "no process attribution available")
            return
        confidence = float(threat.details.get("confidence", 0.0))
        ok, reason = self.guard.may_kill(process.pid, process.comm, process.uid, confidence)
        if not ok:
            self.denied += 1
            self.audit.record_action(incident_id, action, str(process.pid), False, f"guard refused: {reason}")
            return

        evidence = self.capture_evidence(incident_id, process)
        if not self.enforcing:
            self.planned += 1
            self.audit.record_action(
                incident_id,
                action,
                str(process.pid),
                True,
                f"monitor mode: would SIGKILL pid {process.pid} ({process.comm}) - {evidence}",
                undo={"kind": "noop"},
            )
            return

        killed, detail = _terminate(process.pid, evidence)
        self.executed += 1 if killed else 0
        self.audit.record_action(
            incident_id,
            action,
            str(process.pid),
            killed,
            f"{detail}; evidence at {evidence}",
            undo={"kind": "cannot_revive", "cmdline": list(process.cmdline), "pid": process.pid},
        )

    def _quarantine(self, incident_id: int, action: str, threat: Threat, origin_node: str) -> None:
        for path in self._payload_paths(threat):
            if self.integrity is None:
                self.audit.record_action(incident_id, action, path, False, "integrity watcher disabled")
                return
            if not self.enforcing:
                self.planned += 1
                self.audit.record_action(incident_id, action, path, True, f"monitor mode: would quarantine {path}")
                continue
            ok, detail = self.integrity.quarantine(path)
            if not ok:
                ok, detail = self._self_quarantine(path)
            self.executed += 1 if ok else 0
            self.audit.record_action(
                incident_id, action, path, ok, detail, undo={"kind": "restore_file", "to": path, "from": detail}
            )

    def _self_quarantine(self, path: str) -> tuple[bool, str]:
        """Payload outside the watched set: move it anyway, it ran from /tmp."""
        if not os.path.exists(path) or not os.path.isfile(path):
            return False, "no such regular file"
        stamp = time.strftime("%Y%m%d-%H%M%S")
        destination = os.path.join(self.integrity.quarantine_dir, f"adhoc.{path.strip('/').replace('/', '%')}.{stamp}")
        try:
            os.makedirs(self.integrity.quarantine_dir, exist_ok=True)
            shutil.move(path, destination)
            os.chmod(destination, 0o600)
        except OSError as exc:
            return False, f"move failed: {exc}"
        return True, destination

    def _restore(self, incident_id: int, action: str, threat: Threat, origin_node: str) -> None:
        if self.integrity is None:
            self.audit.record_action(incident_id, action, ",".join(threat.paths), False, "integrity watcher disabled")
            return
        for path in threat.paths:
            if not self.enforcing:
                self.planned += 1
                self.audit.record_action(incident_id, action, path, True, f"monitor mode: would restore {path}")
                continue
            ok, detail = self.integrity.restore(path)
            self.executed += 1 if ok else 0
            self.audit.record_action(
                incident_id,
                action,
                path,
                ok,
                detail,
                undo={"kind": "reapply", "backup": self.integrity.tracked[path].backup if path in self.integrity.tracked else ""},
            )

    def _payload_paths(self, threat: Threat) -> tuple[str, ...]:
        """Paths the agent may remove: watched ones, plus what the flagged process ran from."""
        candidates = set(threat.paths)
        if threat.process:
            candidates.add(threat.process.exe)
            candidates.update(threat.process.files[:5])
        allowed_prefixes = tuple(self.config.process.get("quarantine_dirs", []))
        out = []
        for path in candidates:
            if not path:
                continue
            if self.integrity and any(path.startswith(entry.rstrip("*")) for entry in self.integrity.watch_paths):
                out.append(path)
            elif any(path.startswith(prefix) for prefix in allowed_prefixes):
                out.append(path)
        return tuple(sorted(set(out)))

    # ---- evidence ----------------------------------------------------------
    def capture_evidence(self, incident_id: int, process) -> str:
        directory = os.path.join(self.evidence_dir, f"incident-{incident_id}")
        os.makedirs(directory, exist_ok=True)
        stamp = time.strftime("%Y%m%dT%H%M%S")
        bundle = {
            "captured_at": time.time(),
            "process": {
                "pid": process.pid,
                "ppid": process.ppid,
                "uid": process.uid,
                "user": process.user,
                "comm": process.comm,
                "cmdline": list(process.cmdline),
                "exe": process.exe,
                "cwd": process.cwd,
                "started_at": process.started_at,
                "sha256": process.sha256,
                "lineage": list(process.lineage),
            },
            "open_files": list(process.files),
            "sockets": self._socket_table(process.pid),
            "remote_intel": [],
        }
        for socket_info in bundle["sockets"]:
            address = socket_info["remote"].split(":")[0]
            if address and address not in ("0.0.0.0", "::"):
                bundle["remote_intel"].append(_reverse(address))
        try:
            with open(os.path.join(directory, f"process-{process.pid}-{stamp}.json"), "w", encoding="utf-8") as fh:
                json.dump(bundle, fh, indent=2, default=str)
        except OSError:
            return directory
        for source, label in ((f"/proc/{process.pid}/status", "status"), (f"/proc/{process.pid}/maps", "maps")):
            try:
                with open(source, encoding="utf-8", errors="replace") as fh:
                    text = fh.read(262144)
                with open(os.path.join(directory, f"{process.pid}.{label}"), "w", encoding="utf-8") as out:
                    out.write(text)
            except OSError:
                continue
        self._copy_payload(process, directory)
        return directory

    def _socket_table(self, pid: int) -> list[dict]:
        if self.netview is None:
            return []
        return [
            {
                "local": f"{c.local}:{c.local_port}",
                "remote": f"{c.remote}:{c.remote_port}",
                "state": c.state,
            }
            for c in self.netview.connections_of(pid)
        ]

    def _copy_payload(self, process, directory: str) -> None:
        for path in list(process.files)[:MAX_EVIDENCE_FILES] + [process.exe, process.cwd]:
            if not path or not os.path.isfile(path):
                continue
            if os.path.getsize(path) > 4 * 1024 * 1024:
                continue
            name = re.sub(r"[^A-Za-z0-9._-]", "_", path)[-80:]
            try:
                shutil.copy2(path, os.path.join(directory, f"payload.{name}"))
            except OSError:
                continue


def _reverse(address: str) -> dict:
    info = {"address": address, "ptr": "", "error": ""}
    try:
        socket.setdefaulttimeout(2.0)
        info["ptr"] = socket.gethostbyaddr(address)[0]
    except (OSError, UnicodeError) as exc:
        info["error"] = str(exc)[:80]
    return info


def _terminate(pid: int, evidence: str) -> tuple[bool, str]:
    """Kill the process, and any shell it spawned underneath it."""
    children = _direct_children(pid)
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        return True, "process had already exited"
    except PermissionError as exc:
        return False, f"kill refused: {exc}"
    except OSError as exc:
        return False, f"kill failed: {exc}"
    for child in children:
        try:
            os.kill(child, signal.SIGKILL)
        except OSError:
            continue
    return True, f"SIGKILL sent to {pid}" + (f" and children {children}" if children else "")


def _direct_children(pid: int) -> list[int]:
    children = []
    for candidate in procfs.list_pids():
        record = procfs.read_process(candidate)
        if record and record.ppid == pid and record.comm in ("sh", "bash", "dash", "zsh", "nc", "python3"):
            children.append(candidate)
    return children
