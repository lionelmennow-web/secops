"""Shared view of the kernel's socket table, plus endpoint history.

One poller refreshes the connection snapshot; the process watcher, network
watcher, and responder all read from it. That keeps /proc traffic to one pass
per cycle no matter how many rules need socket attribution.
"""

from __future__ import annotations

import json
import os
import time
from collections import defaultdict

from . import procfs

OUTBOUND_STATES = ("ESTABLISHED", "SYN_SENT", "CLOSE_WAIT", "LAST_ACK")
INBOUND_STATES = ("SYN_RECV", "ESTABLISHED")


class NetView:
    def __init__(self, families: tuple[int, ...] = (4, 6)) -> None:
        self.families = families
        self.connections: list = []
        self.by_inode: dict[int, object] = {}
        self.by_pid: dict[int, list] = defaultdict(list)
        self.listen_ports: set[int] = set()
        self.updated_at = 0.0
        self.refreshes = 0

    def refresh(self) -> list:
        connections: list = []
        for family in self.families:
            connections.extend(procfs.read_tcp_connections(family))
        owners = procfs.socket_owner_index()
        enriched = []
        for connection in connections:
            pid, comm = owners.get(connection.inode, (0, ""))
            enriched.append(
                type(connection)(
                    local=connection.local,
                    local_port=connection.local_port,
                    remote=connection.remote,
                    remote_port=connection.remote_port,
                    state=connection.state,
                    uid=connection.uid,
                    inode=connection.inode,
                    family=connection.family,
                    pid=pid,
                    comm=comm,
                )
            )
        self.connections = enriched
        self.by_inode = {c.inode: c for c in enriched}
        self.by_pid = defaultdict(list)
        self.listen_ports = set()
        for connection in enriched:
            if connection.pid:
                self.by_pid[connection.pid].append(connection)
            if connection.state == "LISTEN":
                self.listen_ports.add(connection.local_port)
        self.updated_at = time.time()
        self.refreshes += 1
        return enriched

    def outbound(self) -> list:
        return [
            connection
            for connection in self.connections
            if connection.state in OUTBOUND_STATES and connection.remote not in ("0.0.0.0", "::")
        ]

    def connections_of(self, pid: int) -> list:
        return list(self.by_pid.get(pid, ()))

    def stalled_inbound(self, window: float) -> list:
        """Connections half-opened by a scanner; the local table keeps them as SYN_RECV."""
        return [c for c in self.connections if c.state == "SYN_RECV"]

    def snapshot(self) -> dict:
        return {
            "updated_at": self.updated_at,
            "connections": len(self.connections),
            "outbound": len(self.outbound()),
            "listening": sorted(self.listen_ports)[:64],
            "refreshes": self.refreshes,
        }


class EndpointHistory:
    """TOFU allow-list of outbound endpoints.

    Anything this host has talked to before, or that the operator approved, is
    considered known. A first-ever connection to a new endpoint is not blocked
    on sight - it is correlated with the process that made it - but a *new*
    endpoint whose process also matches exploit grammar is the strongest
    possible signal that a scam link just opened a shell.
    """

    SWEEP = 4000

    def __init__(self, path: str) -> None:
        self.path = path
        self.endpoints: dict[str, float] = {}
        self.approved: set[str] = set()
        self.loaded_at = 0.0
        self._load()

    def _load(self) -> None:
        try:
            with open(self.path, encoding="utf-8") as fh:
                payload = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return
        self.endpoints = {key: float(value) for key, value in payload.get("endpoints", {}).items()}
        self.approved = set(payload.get("approved", []))
        self.loaded_at = time.time()

    def save(self) -> None:
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        tmp = f"{self.path}.tmp"
        payload = {
            "updated_at": time.time(),
            "endpoints": self.endpoints,
            "approved": sorted(self.approved),
        }
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2)
        os.replace(tmp, self.path)

    def note(self, endpoint: str) -> None:
        self.endpoints[endpoint] = time.time()
        if len(self.endpoints) > self.SWEEP:
            cutoff = sorted(self.endpoints.items(), key=lambda item: item[1])[self.SWEEP // 2][1]
            self.endpoints = {k: v for k, v in self.endpoints.items() if v >= cutoff}

    def known(self, endpoint: str) -> bool:
        return endpoint in self.approved or endpoint in self.endpoints

    def approve(self, endpoint: str) -> None:
        self.approved.add(endpoint)
        self.save()

    def revoke(self, endpoint: str) -> bool:
        existed = endpoint in self.approved
        self.approved.discard(endpoint)
        self.endpoints.pop(endpoint, None)
        self.save()
        return existed
