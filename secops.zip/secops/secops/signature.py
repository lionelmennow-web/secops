"""Compact, authenticated threat signatures exchanged between swarm agents.

The wire format carries only what a peer can act on: which address to refuse
traffic from, in which direction, for how long, and why. Local response detail
(pids, file paths) never travels, because no other node can act on it.
"""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import time
from dataclasses import dataclass, field, replace

from .signals import ALERT, ATTACKS, BLOCK, BOTH, DIRECTIONS

PROTOCOL_VERSION = 2

MAX_EVIDENCE = 200
MAX_TTL = 604800.0
MIN_TTL = 5.0
MAX_HOP = 6
CLOCK_SKEW = 30.0


class SignatureError(ValueError):
    """Raised when a received signature is malformed, forged, or stale."""


@dataclass(frozen=True)
class ThreatSignature:
    subject: str
    attack: str
    node: str
    reason: str = ""
    tag: str = BLOCK
    direction: str = BOTH
    ttl: float = 3600.0
    ts: float = field(default_factory=time.time)
    hop: int = 1
    ports: tuple[int, ...] = ()
    version: int = PROTOCOL_VERSION
    auth: str = ""

    def __post_init__(self) -> None:
        # The wire carries rounded values, so signed and parsed forms must agree.
        object.__setattr__(self, "ts", round(float(self.ts), 1))
        object.__setattr__(self, "ttl", round(float(self.ttl), 1))

    @property
    def id(self) -> str:
        return hashlib.sha256(self.canonical()).hexdigest()[:16]

    @property
    def subject_ip(self):
        return ipaddress.ip_address(self.subject.split("/")[0])

    def canonical(self) -> bytes:
        payload = {
            "v": self.version,
            "tag": self.tag,
            "attack": self.attack,
            "subject": self.subject,
            "node": self.node,
            "dir": self.direction,
            "ttl": round(self.ttl, 1),
            "ts": round(self.ts, 1),
            "hop": self.hop,
            "ports": list(self.ports),
            "reason": self.reason,
        }
        return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()

    def with_auth(self, key: bytes) -> "ThreatSignature":
        return replace(self, auth=hmac.new(key, self.canonical(), hashlib.sha256).hexdigest())

    def to_json(self) -> bytes:
        payload = json.loads(self.canonical())
        payload["auth"] = self.auth
        return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()

    def expires_at(self) -> float:
        return self.ts + self.ttl

    def is_expired(self, now: float | None = None) -> bool:
        return (now or time.time()) >= self.expires_at()


def parse(raw: bytes, now: float | None = None) -> ThreatSignature:
    """Decode and structurally validate a signature; authenticity is checked separately."""
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SignatureError(f"not decodable: {exc}") from exc
    if not isinstance(payload, dict):
        raise SignatureError("payload is not an object")

    try:
        sig = ThreatSignature(
            version=int(payload.get("v", 0)),
            tag=str(payload["tag"]),
            attack=str(payload["attack"]),
            subject=str(payload["subject"]),
            node=str(payload["node"]),
            direction=str(payload.get("dir", BOTH)),
            ttl=float(payload["ttl"]),
            ts=float(payload["ts"]),
            hop=int(payload["hop"]),
            ports=tuple(int(p) for p in payload.get("ports", [])),
            reason=str(payload.get("reason", "")),
            auth=str(payload.get("auth", "")),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise SignatureError(f"missing or mistyped field: {exc}") from exc

    validate_shape(sig, now=now)
    return sig


def validate_shape(sig: ThreatSignature, now: float | None = None) -> None:
    now = now if now is not None else time.time()

    if sig.version != PROTOCOL_VERSION:
        raise SignatureError(f"unsupported protocol version {sig.version}")
    if sig.tag not in (BLOCK, ALERT):
        raise SignatureError(f"unknown tag {sig.tag!r}")
    if sig.attack not in ATTACKS:
        raise SignatureError(f"unknown attack class {sig.attack!r}")
    if sig.direction not in DIRECTIONS:
        raise SignatureError(f"unknown direction {sig.direction!r}")
    if not _is_address(sig.subject):
        raise SignatureError(f"invalid subject address {sig.subject!r}")
    if not sig.node or len(sig.node) > 64:
        raise SignatureError("node id must be 1..64 characters")
    if len(sig.reason) > MAX_EVIDENCE:
        raise SignatureError("reason exceeds length limit")
    if len(sig.ports) > 16 or any(not 0 < port <= 65535 for port in sig.ports):
        raise SignatureError("port list is malformed or too long")
    if not MIN_TTL <= sig.ttl <= MAX_TTL:
        raise SignatureError(f"ttl {sig.ttl} outside allowed range")
    if not 1 <= sig.hop <= MAX_HOP:
        raise SignatureError(f"hop count {sig.hop} outside allowed range")
    if sig.ts > now + CLOCK_SKEW:
        raise SignatureError("timestamp is in the future")
    if sig.is_expired(now):
        raise SignatureError("signature already expired")


def _is_address(value: str) -> bool:
    try:
        ipaddress.ip_address(value.split("/")[0])
    except ValueError:
        return False
    return True


def verify_auth(sig: ThreatSignature, key: bytes) -> bool:
    expected = hmac.new(key, sig.canonical(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, sig.auth)
