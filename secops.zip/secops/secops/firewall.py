"""Host firewall control: the enforcement point the whole swarm shares.

Two dedicated chains (or one nftables table) are jumped to from INPUT and
OUTPUT, so the agent only ever edits its own rules and never rewrites the
operator's rule set. Blocking an address drops it in both directions: inbound
attackers cannot retry, and a compromised host cannot call its C2 back.
"""

from __future__ import annotations

import ipaddress
import json
import os
import re
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field

from .signals import IN, OUT

FAMILIES = {4: "iptables", 6: "ip6tables"}


@dataclass
class Rule:
    address: str  # host or CIDR
    direction: str  # IN | OUT
    reason: str
    expires_at: float
    source: str  # local node name, or "peer:<name>" when learned by gossip
    sig_id: str = ""
    ports: tuple[int, ...] = ()
    created_at: float = field(default_factory=time.time)

    @property
    def cidr(self) -> str:
        return normalize(self.address)

    @property
    def family(self) -> int:
        return ipaddress.ip_network(self.cidr, strict=False).version

    @property
    def key(self) -> tuple[str, str]:
        return (self.direction, self.cidr)

    def expired(self, now: float | None = None) -> bool:
        return (now or time.time()) >= self.expires_at

    def as_dict(self) -> dict:
        return {
            "address": self.address,
            "direction": self.direction,
            "cidr": self.cidr,
            "reason": self.reason,
            "expires_at": self.expires_at,
            "source": self.source,
            "sig_id": self.sig_id,
            "ports": list(self.ports),
            "created_at": self.created_at,
        }


def normalize(address: str) -> str:
    """'10.0.0.5', '10.0.0.0/24' -> a canonical network string."""
    if "/" in address:
        return str(ipaddress.ip_network(address, strict=False))
    ip = ipaddress.ip_address(address)
    return f"{ip}/{ip.max_prefixlen}"


def _run(argv: list[str], stdin: str | None = None) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(argv, capture_output=True, text=True, input=stdin, timeout=20)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return subprocess.CompletedProcess(argv, returncode=127, stdout="", stderr=str(exc))


def detect_backend(preference: str) -> str:
    if preference != "auto":
        return preference
    if shutil.which("iptables"):
        return "iptables"
    if shutil.which("nft"):
        return "nftables"
    return "none"


class Firewall:
    name = "base"

    def __init__(self, config: dict, allowlist=None) -> None:
        self.config = config
        self.allowlist = allowlist or []
        self.chain = config.get("chain", "SWARM")
        self.comment = config.get("comment", "swarm-defense")
        self.state_file = config.get("state_file")
        self.lock = threading.Lock()
        self.rules: dict[tuple[str, str], Rule] = {}
        self.last_error = ""
        # Monitor mode keeps the rule set in view without touching the kernel, so
        # an operator can see what enforcement would do before arming it.
        self.dry_run = False

    @classmethod
    def build(cls, config: dict, allowlist=None) -> "Firewall":
        backend = detect_backend(config.get("backend", "auto"))
        if backend == "iptables":
            return IptablesFirewall(config, allowlist)
        if backend == "nftables":
            return NftablesFirewall(config, allowlist)
        return NullFirewall(config, allowlist)

    # ---- remembered state --------------------------------------------------
    def load_state(self) -> int:
        if not self.state_file or not os.path.exists(self.state_file):
            return 0
        try:
            with open(self.state_file, encoding="utf-8") as fh:
                payload = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return 0
        now = time.time()
        for item in payload.get("rules", []):
            try:
                rule = Rule(
                    address=item["address"],
                    direction=item["direction"],
                    reason=item.get("reason", "restored from state"),
                    expires_at=float(item["expires_at"]),
                    source=item.get("source", "state"),
                    sig_id=item.get("sig_id", ""),
                    ports=tuple(item.get("ports", ())),
                    created_at=float(item.get("created_at", now)),
                )
            except (KeyError, TypeError, ValueError):
                continue
            if rule.expired(now):
                continue
            self.rules[rule.key] = rule
        return len(self.rules)

    def save_state(self) -> None:
        if not self.state_file:
            return
        os.makedirs(os.path.dirname(self.state_file) or ".", exist_ok=True)
        tmp = f"{self.state_file}.tmp"
        payload = {
            "updated_at": time.time(),
            "backend": self.name,
            "rules": sorted((r.as_dict() for r in self.rules.values()), key=lambda r: r["expires_at"]),
        }
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2)
        os.replace(tmp, self.state_file)

    # ---- operations ----------------------------------------------------------
    def protect(self, rule: Rule) -> tuple[bool, str]:
        if self.guarded(rule.address):
            return False, f"{rule.address} is on the operator allowlist"
        existing = self.rules.get(rule.key)
        with self.lock:
            if existing and not existing.expired() and existing.expires_at > rule.expires_at:
                rule.expires_at = existing.expires_at
            self.rules[rule.key] = rule
        if self.dry_run:
            self.save_state()
            return True, "monitor mode: rule tracked, kernel untouched"
        installed, detail = self._install(rule)
        self.save_state()
        return installed, detail

    def release(self, key: tuple[str, str]) -> tuple[bool, str]:
        with self.lock:
            rule = self.rules.pop(key, None)
        if rule is None:
            return False, "no such rule"
        if self.dry_run:
            self.save_state()
            return True, "monitor mode: tracked rule removed"
        removed, detail = self._remove(rule)
        self.save_state()
        return removed, detail

    def release_address(self, address: str, direction: str = IN) -> tuple[bool, str]:
        return self.release((direction, normalize(address)))

    def guarded(self, address: str) -> bool:
        try:
            ip = ipaddress.ip_address(address.split("/")[0])
        except ValueError:
            return True
        for entry in self.allowlist:
            try:
                if ip in ipaddress.ip_network(entry, strict=False):
                    return True
            except ValueError:
                continue
        return False

    def reap(self) -> list[Rule]:
        now = time.time()
        expired = [rule for rule in list(self.rules.values()) if rule.expired(now)]
        for rule in expired:
            self.release(rule.key)
        return expired

    def snapshot(self) -> list[dict]:
        with self.lock:
            return [r.as_dict() for r in self.rules.values()]

    def reconcile(self) -> dict:
        """Re-assert every remembered rule; used after a restart or a manual flush."""
        result = {"checked": 0, "repaired": 0, "missing": []}
        for rule in list(self.rules.values()):
            result["checked"] += 1
            if self.dry_run or self._present(rule):
                continue
            installed, detail = self._install(rule)
            if installed:
                result["repaired"] += 1
            else:
                result["missing"].append({"rule": rule.as_dict(), "detail": detail})
        return result

    def teardown(self) -> dict:
        errors = []
        removed = 0
        for key in list(self.rules):
            ok, detail = self.release(key)
            removed += 1 if ok else 0
            if not ok:
                errors.append(detail)
        self._destroy_chains()
        return {"removed": removed, "errors": errors}

    def install_hooks(self) -> tuple[bool, str]:
        return True, "no kernel hooks required"

    def status(self) -> dict:
        return {
            "backend": self.name,
            "dry_run": self.dry_run,
            "rules": len(self.rules),
            "last_error": self.last_error,
        }

    def _install(self, rule: Rule) -> tuple[bool, str]:
        return True, f"recorded only ({self.name})"

    def _remove(self, rule: Rule) -> tuple[bool, str]:
        return True, f"removed from record only ({self.name})"

    def _present(self, rule: Rule) -> bool:
        return True

    def _destroy_chains(self) -> None:
        return None


class NullFirewall(Firewall):
    """Detection-only mode: nothing reaches the kernel."""

    name = "none"


class IptablesFirewall(Firewall):
    name = "iptables"

    BINARY = {4: "iptables", 6: "ip6tables"}

    def chains(self) -> list[tuple[str, str, str]]:
        """(binary, chain, parent) for every place we may need to write."""
        out = []
        for family, binary in self.BINARY.items():
            if not shutil.which(binary):
                continue
            out.append((binary, self.chain, "INPUT"))
            out.append((binary, f"{self.chain}-OUT", "OUTPUT"))
        return out

    def install_hooks(self) -> tuple[bool, str]:
        problems = []
        for binary, chain, parent in self.chains():
            if _run([binary, "-n", "-L", chain]).returncode != 0:
                created = _run([binary, "-N", chain])
                if created.returncode != 0:
                    problems.append(f"{binary} -N {chain}: {created.stderr.strip()}")
                    continue
            if _run([binary, "-C", parent, "-j", chain]).returncode != 0:
                jumped = _run([binary, "-I", parent, "1", "-j", chain])
                if jumped.returncode != 0:
                    problems.append(f"{binary} -I {parent}: {jumped.stderr.strip()}")
        if problems:
            self.last_error = "; ".join(problems)
            return False, self.last_error[:400]
        return True, f"{len(self.chains())} chains ready"

    def _chain(self, rule: Rule) -> str:
        return self.chain if rule.direction == IN else f"{self.chain}-OUT"

    def _base(self, rule: Rule) -> list[str]:
        argv = [self.BINARY[rule.family], self._chain(rule)]
        return argv

    def _match(self, rule: Rule) -> list[str]:
        argv = ["-s", rule.cidr]
        if rule.ports:
            argv += ["-p", "tcp", "-m", "multiport", "--sports", ",".join(str(p) for p in rule.ports)]
        return argv

    def _verb(self, rule: Rule, action: str) -> list[str]:
        binary, chain = self._base(rule)
        return [binary, action, chain, *self._match(rule), "-m", "comment", "--comment", self.comment, "-j", "DROP"]

    def _present(self, rule: Rule) -> bool:
        binary, chain = self._base(rule)
        listed = _run([binary, "-S", chain])
        if listed.returncode != 0:
            return False
        needle = " ".join(self._match(rule))
        return needle in listed.stdout

    def _install(self, rule: Rule) -> tuple[bool, str]:
        if self._present(rule):
            return True, "already enforced"
        result = _run(self._verb(rule, "-A"))
        if result.returncode != 0:
            self.last_error = result.stderr.strip()
            return False, f"iptables -A failed: {self.last_error[:200]}"
        return True, "kernel rule added"

    def _remove(self, rule: Rule) -> tuple[bool, str]:
        result = _run(self._verb(rule, "-D"))
        if result.returncode != 0:
            self.last_error = result.stderr.strip()
            return False, f"iptables -D failed: {self.last_error[:200]}"
        return True, "kernel rule removed"

    def _destroy_chains(self) -> None:
        for binary, chain, parent in self.chains():
            _run([binary, "-D", parent, "-j", chain])
            _run([binary, "-F", chain])
            _run([binary, "-X", chain])


class NftablesFirewall(Firewall):
    """Explicit rules with comments inside a dedicated `inet swarm` table.

    Deleting by handle makes removal exact, and flushes only ever touch our own
    table, so the distribution's rules are never in scope.
    """

    name = "nftables"
    TABLE = "swarm"

    def install_hooks(self) -> tuple[bool, str]:
        if _run(["nft", "list", "table", f"inet {self.TABLE}"]).returncode == 0:
            return True, "table already present"
        plan = "\n".join(
            [
                f"table inet {self.TABLE} {{",
                f"  chain in {{ type filter hook input priority filter + 10; policy accept; }}",
                f"  chain out {{ type filter hook output priority filter + 10; policy accept; }}",
                "}",
            ]
        )
        result = _run(["nft", "-f", "-"], stdin=plan)
        if result.returncode != 0:
            self.last_error = result.stderr.strip()
            return False, f"nft table create failed: {self.last_error[:200]}"
        return True, "table created"

    def _chain(self, rule: Rule) -> str:
        return "in" if rule.direction == IN else "out"

    def _statement(self, rule: Rule) -> str:
        family = "ip6" if rule.family == 6 else "ip"
        parts = [f"{family} saddr {rule.cidr}"]
        if rule.ports:
            parts.append(f"tcp sport {{{','.join(str(p) for p in rule.ports)}}}")
        return " ".join(parts)

    def _present(self, rule: Rule) -> bool:
        listed = _run(["nft", "-a", "list", "chain", f"inet {self.TABLE}", self._chain(rule)])
        if listed.returncode != 0:
            return False
        return self._statement(rule) in listed.stdout

    def _add(self, rule: Rule) -> tuple[bool, str]:
        statement = self._statement(rule)
        line = (
            f"add rule inet {self.TABLE} {self._chain(rule)} {statement} "
            f'comment "{self.comment}: {self._clean(rule.reason)}" counter drop'
        )
        result = _run(["nft", "-f", "-"], stdin=line)
        if result.returncode != 0:
            self.last_error = result.stderr.strip()
            return False, f"nft add failed: {self.last_error[:200]}"
        return True, "kernel rule added"

    def _install(self, rule: Rule) -> tuple[bool, str]:
        if self._present(rule):
            return True, "already enforced"
        return self._add(rule)

    @staticmethod
    def _clean(text: str) -> str:
        return re.sub(r'["\n]', " ", text)[:120]

    def _remove(self, rule: Rule) -> tuple[bool, str]:
        listed = _run(["nft", "-a", "list", "chain", f"inet {self.TABLE}", self._chain(rule)])
        statement = self._statement(rule)
        handle = None
        for line in listed.stdout.splitlines():
            if statement in line:
                match = re.search(r"handle (\d+)", line)
                if match:
                    handle = match.group(1)
                    break
        if handle is None:
            return True, "nothing to remove"
        result = _run(
            ["nft", "delete", "rule", "inet", self.TABLE, self._chain(rule), handle],
        )
        if result.returncode != 0:
            self.last_error = result.stderr.strip()
            return False, f"nft delete failed: {self.last_error[:200]}"
        return True, "kernel rule removed"

    def _destroy_chains(self) -> None:
        _run(["nft", "delete", "table", "inet", self.TABLE])
