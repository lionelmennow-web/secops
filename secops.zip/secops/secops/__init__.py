"""Swarm Defense: a self-organizing, decentralized immune system for networked devices."""

__version__ = "0.1.0"
