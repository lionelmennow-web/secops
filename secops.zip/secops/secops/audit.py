"""Incident record: what was seen, what was done, and how to undo it.

Every decision is written to SQLite (queryable) and a JSONL stream (tailable,
exportable), and mirrored to syslog so an external collector sees the same
timeline. Actions carry their undo record, which is what makes `swarmctl
rollback` possible after a false positive.
"""

from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import threading
import time

from .signals import Threat

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL,
  updated_at REAL NOT NULL,
  node TEXT NOT NULL,
  attack TEXT NOT NULL,
  subject TEXT NOT NULL,
  tag TEXT NOT NULL,
  direction TEXT NOT NULL,
  severity INTEGER NOT NULL,
  ttl REAL NOT NULL,
  evidence TEXT NOT NULL,
  origin TEXT NOT NULL,
  sig_id TEXT DEFAULT '',
  hits INTEGER DEFAULT 1,
  state TEXT DEFAULT 'open',
  process_json TEXT,
  details_json TEXT
);
CREATE INDEX IF NOT EXISTS incidents_key ON incidents (attack, subject, direction);
CREATE TABLE IF NOT EXISTS actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id INTEGER NOT NULL,
  ts REAL NOT NULL,
  kind TEXT NOT NULL,
  target TEXT NOT NULL,
  ok INTEGER NOT NULL,
  detail TEXT NOT NULL,
  undo_json TEXT,
  rolled_back INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS actions_incident ON actions (incident_id);
CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id INTEGER NOT NULL,
  ts REAL NOT NULL,
  text TEXT NOT NULL
);
"""

MERGE_WINDOW = 60.0


class Audit:
    def __init__(self, directory: str, node: str, syslog: bool = True, keep: int = 2000) -> None:
        os.makedirs(directory, exist_ok=True)
        self.node = node
        self.db_path = os.path.join(directory, "incidents.db")
        self.stream_path = os.path.join(directory, "threats.jsonl")
        self.syslog = syslog
        self.keep = keep
        self._lock = threading.Lock()
        self._db = sqlite3.connect(self.db_path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.executescript(SCHEMA)
            self._db.commit()

    def close(self) -> None:
        with self._lock:
            self._db.commit()
            self._db.close()

    # ---- writing -----------------------------------------------------------
    def open_incident(self, threat: Threat, sig_id: str = "") -> tuple[int, bool]:
        """Merge repeats of the same live threat into one incident."""
        now = time.time()
        row = self._db.execute(
            "SELECT id, hits, ts FROM incidents WHERE attack=? AND subject=? AND direction=? "
            "AND state='open' AND ? - updated_at < ? ORDER BY id DESC LIMIT 1",
            (threat.attack, threat.subject, threat.direction, now, MERGE_WINDOW),
        ).fetchone()
        if row:
            with self._lock:
                self._db.execute(
                    "UPDATE incidents SET hits=hits+1, updated_at=?, evidence=?, details_json=?, ttl=? WHERE id=?",
                    (now, threat.evidence, json.dumps(threat.details, default=str), threat.ttl, row["id"]),
                )
                self._db.commit()
            self._write_stream("merge", dict(threat.as_dict(), id=row["id"], sig_id=sig_id))
            return row["id"], False

        with self._lock:
            cursor = self._db.execute(
                "INSERT INTO incidents (ts, updated_at, node, attack, subject, tag, direction, severity, ttl,"
                " evidence, origin, sig_id, process_json, details_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    now,
                    now,
                    self.node,
                    threat.attack,
                    threat.subject,
                    threat.tag,
                    threat.direction,
                    threat.severity,
                    threat.ttl,
                    threat.evidence,
                    threat.origin,
                    sig_id,
                    json.dumps(threat.as_dict()["process"], default=str),
                    json.dumps(threat.details, default=str),
                ),
            )
            self._db.commit()
        incident_id = cursor.lastrowid
        self._write_stream("incident", dict(threat.as_dict(), id=incident_id, sig_id=sig_id))
        self._log(threat, incident_id)
        return incident_id, True

    def record_action(
        self,
        incident_id: int,
        kind: str,
        target: str,
        ok: bool,
        detail: str,
        undo: dict | None = None,
    ) -> None:
        with self._lock:
            self._db.execute(
                "INSERT INTO actions (incident_id, ts, kind, target, ok, detail, undo_json) VALUES (?,?,?,?,?,?,?)",
                (incident_id, time.time(), kind, target, 1 if ok else 0, detail, json.dumps(undo, default=str) if undo else None),
            )
            self._db.execute("UPDATE incidents SET updated_at=? WHERE id=?", (time.time(), incident_id))
            self._db.commit()
        self._write_stream(
            "action",
            {"id": incident_id, "kind": kind, "target": target, "ok": ok, "detail": detail, "undo": undo},
        )

    def note(self, incident_id: int, text: str) -> None:
        with self._lock:
            self._db.execute("INSERT INTO notes (incident_id, ts, text) VALUES (?,?,?)", (incident_id, time.time(), text))
            self._db.commit()
        self._write_stream("note", {"id": incident_id, "text": text})

    def set_state(self, incident_id: int, state: str) -> None:
        with self._lock:
            self._db.execute(
                "UPDATE incidents SET state=?, updated_at=? WHERE id=?", (state, time.time(), incident_id)
            )
            self._db.commit()

    def mark_rolled_back(self, action_id: int) -> None:
        with self._lock:
            self._db.execute("UPDATE actions SET rolled_back=1 WHERE id=?", (action_id,))
            self._db.commit()

    # ---- reading -----------------------------------------------------------
    def incidents(self, limit: int = 30, state: str | None = None) -> list[dict]:
        query = "SELECT * FROM incidents"
        args: list = []
        if state:
            query += " WHERE state=?"
            args.append(state)
        query += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        rows = self._db.execute(query, args).fetchall()
        return [self._incident_dict(row) for row in rows]

    def incident(self, incident_id: int) -> dict | None:
        row = self._db.execute("SELECT * FROM incidents WHERE id=?", (incident_id,)).fetchone()
        if row is None:
            return None
        detail = self._incident_dict(row)
        detail["actions"] = [
            dict(zip(("id", "ts", "kind", "target", "ok", "detail", "undo", "rolled_back"), values))
            for values in self._db.execute(
                "SELECT id, ts, kind, target, ok, detail, undo_json, rolled_back FROM actions WHERE incident_id=? ORDER BY id",
                (incident_id,),
            )
        ]
        for action in detail["actions"]:
            action["undo"] = json.loads(action["undo"]) if action["undo"] else None
        detail["notes"] = [
            dict(zip(("ts", "text"), values))
            for values in self._db.execute(
                "SELECT ts, text FROM notes WHERE incident_id=? ORDER BY id", (incident_id,)
            )
        ]
        return detail

    def recent_actions(self, limit: int = 40) -> list[dict]:
        values = self._db.execute(
            "SELECT a.id, a.incident_id, a.ts, a.kind, a.target, a.ok, a.detail, a.undo_json, a.rolled_back,"
            " i.attack, i.subject FROM actions a JOIN incidents i ON i.id=a.incident_id"
            " ORDER BY a.id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        out = []
        for row in values:
            item = dict(zip(("id", "incident_id", "ts", "kind", "target", "ok", "detail", "undo", "rolled_back", "attack", "subject"), row))
            item["undo"] = json.loads(item["undo"]) if item["undo"] else None
            out.append(item)
        return out

    def stats(self) -> dict:
        counts = dict(self._db.execute("SELECT state, COUNT(*) FROM incidents GROUP BY state").fetchall())
        by_attack = dict(
            self._db.execute(
                "SELECT attack, COUNT(*) FROM incidents WHERE ts > ? GROUP BY attack",
                (time.time() - 86400,),
            ).fetchall()
        )
        return {
            "incidents_total": self._db.execute("SELECT COUNT(*) FROM incidents").fetchone()[0],
            "open": counts.get("open", 0),
            "resolved": counts.get("resolved", 0),
            "actions": self._db.execute("SELECT COUNT(*) FROM actions").fetchone()[0],
            "last_24h_by_attack": by_attack,
        }

    def prune(self) -> int:
        """Keep the newest `keep` incidents; drop their actions and notes with them."""
        row = self._db.execute(
            "SELECT id FROM incidents ORDER BY id DESC LIMIT 1 OFFSET ?", (max(self.keep - 1, 0),)
        ).fetchone()
        if row is None:
            return 0
        cutoff = row["id"]
        with self._lock:
            removed = self._db.execute("DELETE FROM incidents WHERE id < ?", (cutoff,)).rowcount
            for table in ("actions", "notes"):
                self._db.execute(f"DELETE FROM {table} WHERE incident_id < ?", (cutoff,))
            self._db.commit()
        return removed

    def _incident_dict(self, row: sqlite3.Row) -> dict:
        item = dict(row)
        for key in ("process_json", "details_json"):
            value = item.get(key)
            item[key[:-5]] = json.loads(value) if value else None
            item.pop(key, None)
        return item

    def _write_stream(self, kind: str, payload: dict) -> None:
        record = {"ts": time.time(), "node": self.node, "kind": kind, **payload}
        try:
            with open(self.stream_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, default=str) + "\n")
        except OSError:
            pass

    def _log(self, threat: Threat, incident_id: int) -> None:
        message = (
            f"swarm[{self.node}] incident {incident_id}: {threat.attack} subject={threat.subject} "
            f"severity={threat.severity} :: {threat.evidence}"
        )[:1000]
        if not self.syslog:
            return
        try:
            subprocess.run(
                ["logger", "-t", "swarm-agent", "-p", "auth.warning" if threat.severity >= 3 else "local4.warning", message],
                capture_output=True,
                timeout=3,
            )
        except (OSError, subprocess.TimeoutExpired):
            pass
