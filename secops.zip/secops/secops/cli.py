"""`swarmctl` - operator control of a local agent over its Unix socket.

Nothing here listens on the network: the command line client connects to the
agent's private socket, sends one JSON request, and prints the reply.
"""

from __future__ import annotations

import argparse
import json
import os
import socket
import sys

DEFAULT_SOCKETS = (
    "/var/lib/swarm/agent.sock",
    os.path.join(os.path.expanduser("~"), ".local/state/swarm/agent.sock"),
    "./var/lib/swarm/agent.sock",
)


def request(payload: dict, socket_path: str, timeout: float = 12.0) -> dict:
    try:
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(timeout)
        connection.connect(socket_path)
    except OSError as exc:
        return {"ok": False, "error": f"cannot reach agent at {socket_path}: {exc}"}
    try:
        connection.sendall((json.dumps(payload) + "\n").encode())
        buffer = b""
        while b"\n" not in buffer:
            chunk = connection.recv(65536)
            if not chunk:
                break
            buffer += chunk
            if len(buffer) > 8 * 1024 * 1024:
                return {"ok": False, "error": "reply too large"}
    finally:
        connection.close()
    if not buffer:
        return {"ok": False, "error": "agent returned nothing"}
    return json.loads(buffer.split(b"\n", 1)[0].decode())


def find_socket(explicit: str | None) -> str:
    if explicit:
        return explicit
    env = os.environ.get("SWARM_CONTROL")
    if env:
        return env
    for candidate in DEFAULT_SOCKETS:
        if os.path.exists(candidate):
            return candidate
    return DEFAULT_SOCKETS[0]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="swarmctl", description="Control a local swarm agent")
    parser.add_argument("--socket", "-s", default=None, help="agent control socket path")
    parser.add_argument("--json", action="store_true", help="print raw JSON instead of a table")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("status", help="everything the agent currently knows")
    sub.add_parser("peers", help="swarm membership and gossip counters")
    sub.add_parser("blocks", help="active firewall rules")
    sub.add_parser("flush", help="remove every rule this agent installed")

    incidents = sub.add_parser("incidents", help="recent incidents")
    incidents.add_argument("--limit", type=int, default=25)
    incidents.add_argument("--state", default=None)

    show = sub.add_parser("show", help="one incident with its actions and notes")
    show.add_argument("id", type=int)

    block = sub.add_parser("block", help="refuse an address and teach the peers")
    block.add_argument("address")
    block.add_argument("--ttl", type=float, default=3600.0)
    block.add_argument("--direction", choices=("in", "out", "both"), default="both")
    block.add_argument("--reason", default="manual")

    unblock = sub.add_parser("unblock", help="remove a rule")
    unblock.add_argument("address")
    unblock.add_argument("--direction", choices=("in", "out"), default=None)

    isolate = sub.add_parser("isolate", help="cut a device out of the swarm")
    isolate.add_argument("address")
    isolate.add_argument("--ttl", type=float, default=3600.0)
    isolate.add_argument("--reason", default="operator command")

    release = sub.add_parser("release", help="undo an isolation")
    release.add_argument("address")

    endpoints = sub.add_parser("endpoints", help="outbound endpoint history")
    endpoints.add_argument("--limit", type=int, default=40)

    approve_endpoint = sub.add_parser("approve-endpoint", help="trust an outbound endpoint")
    approve_endpoint.add_argument("endpoint")

    revoke_endpoint = sub.add_parser("revoke-endpoint", help="stop trusting an endpoint")
    revoke_endpoint.add_argument("endpoint")

    approve_path = sub.add_parser("approve-path", help="accept a changed file as the new baseline")
    approve_path.add_argument("path")

    restore = sub.add_parser("restore", help="write a watched file back to its baseline")
    restore.add_argument("path")

    sub.add_parser("integrity", help="persistence watch state")

    rollback = sub.add_parser("rollback", help="undo the reversible actions of an incident")
    rollback.add_argument("--incident", type=int, default=None)

    sub.add_parser("stats", help="incident counts")
    sub.add_parser("doctor", help="self-test the detection grammar and guard rails")
    return parser


def emit(result: dict, as_json: bool, renderer) -> int:
    if not result.get("ok"):
        print(f"error: {result.get('error', 'failed')}", file=sys.stderr)
        return 1
    if as_json:
        print(json.dumps(result["result"], indent=2, default=str))
    else:
        renderer(result["result"])
    return 0


def render_status(value: dict) -> None:
    print(f"node {value['node']} at {value['address']}  mode={value['mode']}  pid={value['pid']}")
    print(f"uptime {value['uptime']:.0f}s   firewall {value['firewall']['backend']} ({value['firewall']['rules']} rules)")
    if value["firewall"]["last_error"]:
        print(f"  last firewall error: {value['firewall']['last_error']}")
    swarm = value["swarm"]
    print(f"peers: {', '.join(swarm['peers']) or 'none configured'}   isolated: {', '.join(swarm['isolated']) or 'none'}")
    gossip = swarm["gossip"]
    print(
        "gossip: rx {received} tx {sent} fwd {forwarded} accepted {accepted} "
        "dup {duplicates} throttle {throttled} bad-format {rejected_shape} bad-hmac {rejected_auth}".format(
            **gossip
        )
    )
    print(f"counters: {swarm['counters']}")
    for name, watcher in value["watchers"].items():
        print(f"  {name}: {json.dumps(watcher, default=str)[:400]}")
    responder = value["responder"]
    print(
        f"responder: executed={responder['executed']} monitor-planned={responder['planned_in_monitor']} "
        f"guard-denied={responder['denied_by_guard']}"
    )
    print(f"audit: {value['audit']}")
    if value["poller_errors"]:
        print(f"watcher errors: {value['poller_errors']}")
    print("recent threats:")
    if not value["recent"]:
        print("  (quiet)")
    for entry in value["recent"][-10:]:
        print(
            f"  #{entry['incident']:<4} {entry['attack']:<18} {entry['subject']:<18} "
            f"sev{entry['severity']} {entry['origin']:<14} {','.join(entry['actions'])}"
        )


def render_blocks(value: list) -> None:
    if not value:
        print("no active rules")
        return
    for rule in value:
        remaining = max(0.0, rule["expires_at"] - __import__("time").time())
        print(
            f"{rule['direction']:<4} {rule['cidr']:<20} {remaining:>7.0f}s  "
            f"from {rule['source']:<12} {rule['reason'][:70]}"
        )


def render_incidents(value: list) -> None:
    if not value:
        print("no incidents recorded")
        return
    for item in value:
        stamp = __import__("time").strftime("%m-%d %H:%M:%S", __import__("time").localtime(item["ts"]))
        print(
            f"#{item['id']:<4} {stamp} {item['attack']:<18} {item['subject']:<18} "
            f"sev{item['severity']} {item['state']:<8} hits={item['hits']} {item['evidence'][:70]}"
        )


def render_incident(value: dict | None) -> None:
    if value is None:
        print("no such incident")
        return
    print(json.dumps(value, indent=2, default=str))


def render_generic(value) -> None:
    print(json.dumps(value, indent=2, default=str))


def main(argv=None) -> int:
    from .selftest import run_doctor

    parser = build_parser()
    args = parser.parse_args(argv)
    command = args.command

    if command == "doctor":
        return run_doctor()

    payload = {"command": _wire_command(command), "args": _wire_args(args)}
    result = request(payload, find_socket(args.socket))
    renderer = {
        "status": render_status,
        "blocks": render_blocks,
        "incidents": render_incidents,
        "show": render_incident,
    }.get(command, render_generic)
    return emit(result, args.json, renderer)


def _wire_command(command: str) -> str:
    return {
        "release": "release_node",
        "approve-endpoint": "approve_endpoint",
        "revoke-endpoint": "revoke_endpoint",
        "approve-path": "approve_path",
    }.get(command, command.replace("-", "_"))


def _wire_args(args) -> dict:
    skipped = {"command", "socket", "json"}
    fields = {key: value for key, value in vars(args).items() if key not in skipped and value is not None}
    return fields


if __name__ == "__main__":
    raise SystemExit(main())
