"""Entry points: `swarmd` runs the agent, `swarmctl` drives it.

    python -m secops agent --config /etc/swarm/agent.json      # the daemon
    python -m secops control status                            # operator CLI
    python -m secops doctor                                    # self-test
"""

from __future__ import annotations

import argparse
import os
import sys

from .agent import SwarmAgent
from .cli import main as control_main
from .config import Config, ConfigError
from .selftest import run_doctor


def run_agent(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="swarmd", description="Swarm Defense agent")
    parser.add_argument("--config", default=os.environ.get("SWARM_CONFIG", "/etc/swarm/agent.json"))
    parser.add_argument("--mode", choices=("monitor", "enforce"), default=None, help="override config mode")
    parser.add_argument("--state-dir", default=None, help="override audit/state directory")
    args = parser.parse_args(argv)

    try:
        config = Config.load(args.config) if os.path.exists(args.config) else Config.default()
    except (ConfigError, OSError) as exc:
        print(f"config error: {exc}", file=sys.stderr)
        return 2
    if args.mode:
        config.data["mode"] = args.mode
    if args.state_dir:
        config.data["audit"]["dir"] = args.state_dir
        config.data["firewall"]["state_file"] = os.path.join(args.state_dir, "blocks.json")

    if config.enforce and os.geteuid() != 0:
        print("enforce mode needs root (firewall rules, process kill, file restore). Refusing to start.", file=sys.stderr)
        return 1

    agent = SwarmAgent(config)
    agent.run_forever()
    return 0


def control(argv=None) -> int:
    return control_main(argv)


def doctor(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="swarm-doctor")
    parser.add_argument("--config", default=None)
    args = parser.parse_args(argv)
    return run_doctor(args.config)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="secops",
        description="Swarm Defense: self-organizing defense for networked devices",
    )
    parser.add_argument(
        "command",
        nargs="?",
        default="agent",
        choices=("agent", "control", "doctor", "config-example"),
        help="agent (default) runs the daemon; control is swarmctl; doctor is the self-test",
    )
    args, rest = parser.parse_known_args(list(sys.argv[1:] if argv is None else argv))

    if args.command == "agent":
        return run_agent(rest)
    if args.command == "control":
        return control(rest)
    if args.command == "doctor":
        return doctor(rest)
    from .config import DEFAULTS
    import json

    print(json.dumps(DEFAULTS, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
