"""The agent daemon: one per host, no controller.

Wires the watchers to the responder and to the swarm. Detectors only ever call
`emit(threat)`; a single worker thread then decides, acts, records, and tells
the peers. Local control is a Unix socket (`swarmctl`), never a TCP port, so the
agent adds no new attack surface to the machine it protects.
"""

from __future__ import annotations

import json
import os
import queue
import shutil
import socket
import threading
import time
import traceback

from .audit import Audit
from .config import Config
from .detect.authbrute import AuthRules
from .detect.authlog import AuthWatcher
from .detect.integrity import IntegrityWatcher
from .detect.net import NetWatcher
from .detect.procs import ProcessWatcher
from .firewall import Firewall, normalize
from .netview import EndpointHistory, NetView
from .respond import Guard, Responder
from .signals import ALERT, BLOCK, BLOCK_IN, BLOCK_OUT, BOTH, IN, OUT, Threat, is_address
from .signature import ATTACKS, ThreatSignature
from .tailing import Poller
from .transport import GossipTransport, Peer

ISOLATE = "node_isolate"
POLICY = "policy"
MAX_QUEUE = 500


def to_signature(threat: Threat, node: str) -> ThreatSignature:
    """Project a local threat onto the wire: only what a peer can act on travels."""
    attack = threat.attack if threat.attack in ATTACKS else POLICY
    return ThreatSignature(
        subject=threat.subject,
        attack=attack,
        node=node,
        reason=threat.evidence[:200],
        tag=threat.tag,
        direction=threat.direction,
        ttl=max(threat.ttl, 5.0),
        hop=1,
        ports=tuple(threat.ports)[:16],
    )


class SwarmAgent:
    def __init__(self, config: Config) -> None:
        self.config = config
        self.node = config.node_name()
        self.address = config.advertise_ip()
        self.started_at = time.time()
        self.state_dir = config.audit["dir"]
        os.makedirs(self.state_dir, exist_ok=True)

        self.key = _load_key(config.swarm["key_file"])
        self.audit = Audit(
            self.state_dir,
            self.node,
            syslog=config.audit.get("syslog", True),
            keep=config.audit.get("keep_incidents", 2000),
        )
        self.netview = NetView()
        self.endpoints = EndpointHistory(config.network["approved_file"])
        self.guard = Guard(
            config.guard,
            own_pid=os.getpid(),
            advertise_ip=self.address,
            peers=[peer["address"] for peer in config.swarm["peers"]],
        )
        self.firewall = Firewall.build(config.firewall, allowlist=config.guard["allowlist"])
        self.firewall.dry_run = not config.enforce
        self.integrity = IntegrityWatcher(config.integrity, self.state_dir, emit=self._emit)
        self.responder = Responder(
            config,
            self.firewall,
            self.guard,
            self.audit,
            integrity=self.integrity,
            endpoint_history=self.endpoints,
            netview=self.netview,
        )
        self.auth_rules = AuthRules(config.ssh, self.state_dir, emit=self._emit)
        self.auth_watcher = AuthWatcher(config.ssh, on_event=self.auth_rules.handle, log=self.log)
        self.procs = ProcessWatcher(config.process, self.netview, emit=self._emit)
        self.net_watcher = NetWatcher(
            config.network,
            self.netview,
            self.endpoints,
            self.firewall,
            emit=self._emit,
            assessments=self.procs.assessed,
        )

        self.isolated_nodes: set[str] = set()
        self.isolated_file = os.path.join(self.state_dir, "isolated.json")
        self._load_isolated()

        peers = [
            Peer((peer["address"], int(peer["port"])), peer.get("node", ""))
            for peer in config.swarm["peers"]
        ]
        discovery = config.swarm.get("discovery", {})
        multicast = None
        if discovery.get("enabled"):
            multicast = (discovery["group"], int(discovery.get("port", config.swarm["bind_port"])))
        self.transport = GossipTransport(
            bind=(config.swarm["bind_ip"], int(config.swarm["bind_port"])),
            key=self.key,
            on_signature=self._on_gossip,
            peers=peers,
            max_new_per_second=float(config.swarm.get("max_new_per_second", 25)),
            multicast=multicast,
        )

        self.threats: queue.Queue = queue.Queue(maxsize=MAX_QUEUE)
        self._stop = threading.Event()
        self._workers: list[threading.Thread] = []
        self._pollers: list[Poller] = []
        self.control_socket_path = os.environ.get(
            "SWARM_CONTROL", os.path.join(self.state_dir, "agent.sock")
        )
        self._control: threading.Thread | None = None
        self.counters = {"local_threats": 0, "peer_threats": 0, "peer_rejected": 0, "gossip_sent": 0}
        self.recent: list[dict] = []

    # ---- lifecycle ---------------------------------------------------------
    def start(self) -> None:
        if self.config.enforce:
            installed, detail = self.firewall.install_hooks()
            self.log(f"firewall hooks ready ({detail})" if installed else f"firewall hooks FAILED: {detail}")
            restored = self.firewall.load_state()
            if restored:
                reconciled = self.firewall.reconcile()
                self.log(
                    f"restored {restored} remembered blocks ({reconciled['repaired']} re-asserted in kernel)"
                )
        else:
            self.firewall.load_state()
            self.log("monitor mode: threats are recorded and gossiped, the host is not modified")

        self.transport.start()
        self.procs.start()
        self.auth_watcher.start()

        net_interval = max(float(self.config.network.get("poll_interval", 1.0)), 0.4)
        proc_interval = max(float(self.config.process.get("poll_interval", 0.4)), 0.2)
        self._pollers = [
            Poller(net_interval, self._net_tick, name="netview"),
            Poller(proc_interval, self.procs.tick, name="procs"),
            Poller(net_interval, self.net_watcher.tick, name="netwatch"),
            Poller(float(self.config.integrity.get("interval", 5.0)), self.integrity.tick, name="integrity"),
            Poller(5.0, self._maintenance, name="maintenance"),
        ]
        for poller in self._pollers:
            poller.start()

        self._workers.append(threading.Thread(target=self._work, name="responder", daemon=True))
        if self.config.swarm.get("discovery", {}).get("enabled"):
            self._workers.append(threading.Thread(target=self._discover, name="discovery", daemon=True))
        for worker in self._workers:
            worker.start()

        self._control = threading.Thread(target=self._serve_control, name="control", daemon=True)
        self._control.start()

        self.log(
            f"agent {self.node} on {self.address}: mode={self.config.data['mode']} "
            f"backend={self.firewall.name} peers={self.transport.peer_count()} auth={self.auth_watcher.sources}"
        )

    def stop(self) -> None:
        self._stop.set()
        for poller in self._pollers:
            poller.stop()
        self.auth_watcher.stop()
        self.transport.stop()
        self.threats.put(None)
        for worker in self._workers:
            worker.join(timeout=3.0)
        self.firewall.save_state()
        self.endpoints.save()
        self.audit.close()
        self._remove_control_socket()
        self.log("agent stopped")

    def run_forever(self) -> None:
        self.start()
        try:
            while not self._stop.wait(1.0):
                pass
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()

    def log(self, message: str) -> None:
        print(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} [{self.node}] {message}", flush=True)

    # ---- scheduled work ----------------------------------------------------
    def _net_tick(self) -> None:
        self.netview.refresh()

    def _maintenance(self) -> None:
        for rule in self.firewall.reap():
            self.log(f"released {rule.direction} block on {rule.cidr}: ttl expired")
            self.audit.note(0, f"released {rule.direction} block {rule.cidr}: ttl expired")
        self.endpoints.save()
        if self.config.enforce:
            self.firewall.save_state()
        self.audit.prune()

    def _discover(self) -> None:
        """Optional LAN self-organisation: announce on the multicast group and
        adopt whichever peer answers, so a new device needs no manual config."""
        discovery = self.config.swarm["discovery"]
        group = discovery["group"]
        port = int(discovery.get("port", self.config.swarm["bind_port"]))
        hello = {"hello": self.node, "address": self.address, "port": int(self.config.swarm["bind_port"])}
        while not self._stop.wait(float(discovery.get("interval", 30.0))):
            self.transport.send_raw(json.dumps(hello).encode(), (group, port))

    # ---- threat path -------------------------------------------------------
    def _emit(self, threat: Threat) -> None:
        try:
            self.threats.put_nowait(threat)
        except queue.Full:
            self.log(f"threat queue saturated; dropped {threat.attack} on {threat.subject}")

    def _work(self) -> None:
        while not self._stop.is_set():
            try:
                threat = self.threats.get(timeout=0.5)
            except queue.Empty:
                continue
            if threat is None:
                return
            try:
                self._process(threat)
            except Exception:
                self.log(f"responder error: {traceback.format_exc()[:400]}")

    def _process(self, threat: Threat) -> None:
        self.counters["local_threats"] += 1
        incident_id = self.responder.handle(threat)
        self._remember(threat, incident_id, origin="local")
        if threat.peers_should_learn and is_address(threat.subject):
            self._gossip(threat)

    def _gossip(self, threat: Threat) -> None:
        signature = to_signature(threat, self.node).with_auth(self.key)
        delivered = self.transport.broadcast(signature)
        self.counters["gossip_sent"] += delivered
        if delivered:
            self.log(f"taught {delivered} peer(s): {threat.attack} -> {threat.subject}")

    def _on_gossip(self, sig, sender: tuple[str, int], note: str) -> bool:
        """Apply a peer's rule locally. True means the signature may travel on."""
        if sig is None:
            self.counters["peer_rejected"] += 1
            self.log(f"rejected gossip from {sender[0]}: {note}")
            return False

        if sender[0] in self.isolated_nodes:
            self.counters["peer_rejected"] += 1
            self.log(f"ignoring gossip from isolated node {sender[0]}")
            return False

        if sig.attack == ISOLATE:
            self._isolate(sig.subject, origin=sig.node)
            return True

        if sig.subject == self.address or any(sig.subject == peer["address"] for peer in self.config.swarm["peers"]):
            self.log(f"ignoring peer rule that would block a swarm member: {sig.subject}")
            return False

        if sig.direction == IN:
            actions: tuple[str, ...] = (BLOCK_IN,)
        elif sig.direction == OUT:
            actions = (BLOCK_OUT,)
        else:
            actions = (BLOCK_IN, BLOCK_OUT)

        threat = Threat(
            attack=sig.attack,
            subject=sig.subject,
            evidence=sig.reason or f"learned from {sig.node} (hop {sig.hop})",
            origin=f"peer:{sig.node}",
            tag=sig.tag,
            direction=sig.direction,
            ttl=sig.ttl,
            actions=actions,
            ports=sig.ports,
            details={"hop": sig.hop, "peer": sig.node, "signature": sig.id},
        )
        self.counters["peer_threats"] += 1
        incident_id = self.responder.handle(threat, origin_node=sig.node)
        self._remember(threat, incident_id, origin=f"peer:{sig.node}")
        self.log(f"learned from {sig.node}: {sig.attack} -> refuse {sig.subject} for {sig.ttl:.0f}s")
        return True

    def _remember(self, threat: Threat, incident_id: int, origin: str) -> None:
        self.recent.append(
            {
                "ts": time.time(),
                "attack": threat.attack,
                "subject": threat.subject,
                "severity": threat.severity,
                "origin": origin,
                "incident": incident_id,
                "actions": list(threat.actions),
            }
        )
        del self.recent[:-100]

    # ---- node isolation ----------------------------------------------------
    def _load_isolated(self) -> None:
        try:
            with open(self.isolated_file, encoding="utf-8") as fh:
                self.isolated_nodes = set(json.load(fh).get("nodes", []))
        except (OSError, json.JSONDecodeError):
            self.isolated_nodes = set()

    def _save_isolated(self) -> None:
        tmp = f"{self.isolated_file}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"updated_at": time.time(), "nodes": sorted(self.isolated_nodes)}, fh, indent=2)
        os.replace(tmp, self.isolated_file)

    def isolate(self, address: str, ttl: float = 3600.0, reason: str = "operator command") -> int:
        """Cut a device out of the swarm: refuse its traffic and its gossip."""
        self._isolate(address, origin=self.node)
        threat = Threat(
            attack=ISOLATE,
            subject=address,
            evidence=f"node {address} isolated: {reason}"[:200],
            origin="operator",
            tag=ALERT,
            direction=BOTH,
            ttl=ttl,
            actions=(BLOCK_IN, BLOCK_OUT),
        )
        incident_id = self.responder.handle(threat)
        self._gossip(threat)
        return incident_id

    def _isolate(self, address: str, origin: str) -> None:
        if address in self.isolated_nodes:
            return
        self.isolated_nodes.add(address)
        self._save_isolated()
        self.log(f"isolating node {address} (reported by {origin})")

    def release_node(self, address: str) -> bool:
        existed = address in self.isolated_nodes
        self.isolated_nodes.discard(address)
        self._save_isolated()
        return existed

    # ---- local control socket ----------------------------------------------
    def _serve_control(self) -> None:
        self._remove_control_socket()
        try:
            server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            server.bind(self.control_socket_path)
            os.chmod(self.control_socket_path, 0o600)
            server.listen(8)
            server.settimeout(1.0)
        except OSError as exc:
            self.log(f"control socket unavailable at {self.control_socket_path}: {exc}")
            return
        while not self._stop.is_set():
            try:
                connection, _ = server.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                with connection:
                    connection.settimeout(10.0)
                    request = _read_json(connection)
                    if request is None:
                        continue
                    response = self.dispatch(request)
                    connection.sendall((json.dumps(response, default=str) + "\n").encode())
            except (OSError, json.JSONDecodeError):
                continue
        server.close()
        self._remove_control_socket()

    def _remove_control_socket(self) -> None:
        try:
            os.unlink(self.control_socket_path)
        except OSError:
            pass

    def dispatch(self, request: dict) -> dict:
        command = request.get("command", "status")
        handler = getattr(self, f"do_{command}", None)
        if handler is None:
            return {"ok": False, "error": f"unknown command {command!r}"}
        try:
            return {"ok": True, "result": handler(**request.get("args", {}))}
        except TypeError as exc:
            return {"ok": False, "error": f"bad arguments for {command}: {exc}"}
        except Exception as exc:
            where = traceback.format_exc().strip().splitlines()[-1]
            self.log(f"command {command} failed: {where}")
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    # ---- commands served to swarmctl ---------------------------------------
    def do_status(self) -> dict:
        return {
            "node": self.node,
            "address": self.address,
            "mode": self.config.data["mode"],
            "uptime": round(time.time() - self.started_at, 1),
            "pid": os.getpid(),
            "control_socket": self.control_socket_path,
            "firewall": self.firewall.status(),
            "swarm": {
                "peers": [str(peer) for peer in self.transport.peers],
                "gossip": self.transport.stats.as_dict(),
                "counters": dict(self.counters),
                "isolated": sorted(self.isolated_nodes),
            },
            "watchers": {
                "auth": {
                    "sources": self.auth_watcher.sources,
                    "lines_read": self.auth_watcher.read_lines,
                    "auth_events": self.auth_watcher.matched,
                    **self.auth_rules.snapshot(),
                },
                "process": self.procs.snapshot(),
                "network": {**self.net_watcher.snapshot(), **self.netview.snapshot()},
                "integrity": self.integrity.snapshot(),
            },
            "responder": {
                "executed": self.responder.executed,
                "planned_in_monitor": self.responder.planned,
                "denied_by_guard": self.responder.denied,
                "guard_refusals": self.guard.refusals,
            },
            "audit": self.audit.stats(),
            "poller_errors": [poller.errors for poller in self._pollers if poller.errors],
            "recent": self.recent[-20:],
        }

    def do_incidents(self, limit: int = 25, state: str | None = None) -> list[dict]:
        return self.audit.incidents(limit=limit, state=state)

    def do_show(self, id: int) -> dict | None:
        return self.audit.incident(id)

    def do_blocks(self) -> list[dict]:
        return self.firewall.snapshot()

    def do_block(self, address: str, ttl: float = 3600.0, direction: str = BOTH, reason: str = "manual") -> dict:
        if direction == IN:
            actions = (BLOCK_IN,)
        elif direction == OUT:
            actions = (BLOCK_OUT,)
        else:
            actions = (BLOCK_IN, BLOCK_OUT)
        threat = Threat(
            attack=POLICY,
            subject=address,
            evidence=reason,
            origin="operator",
            tag=BLOCK,
            direction=direction,
            ttl=ttl,
            actions=actions,
        )
        incident_id = self.responder.handle(threat)
        if is_address(address):
            self._gossip(threat)
        return {"incident": incident_id, "blocks": self.firewall.snapshot()}

    def do_unblock(self, address: str, direction: str | None = None) -> dict:
        results = {}
        for candidate in [direction] if direction else [IN, OUT]:
            ok, detail = self.firewall.release_address(address, candidate)
            results[f"{candidate}:{address}"] = detail
            if ok:
                self.audit.note(0, f"operator released {candidate} block on {address}")
        return results

    def do_peers(self) -> dict:
        return {
            "configured": [str(peer) for peer in self.transport.peers],
            "gossip": self.transport.stats.as_dict(),
            "isolated": sorted(self.isolated_nodes),
            "self": {"node": self.node, "address": self.address},
        }

    def do_endpoints(self, limit: int = 40) -> dict:
        return {
            "approved": sorted(self.endpoints.approved),
            "recent": sorted(
                self.endpoints.endpoints.items(), key=lambda item: item[1], reverse=True
            )[:limit],
        }

    def do_approve_endpoint(self, endpoint: str) -> dict:
        self.endpoints.approve(endpoint)
        return {"approved": endpoint}

    def do_revoke_endpoint(self, endpoint: str) -> dict:
        return {"revoked": self.endpoints.revoke(endpoint)}

    def do_approve_path(self, path: str) -> dict:
        ok, detail = self.integrity.approve(path)
        return {"ok": ok, "detail": detail}

    def do_restore(self, path: str) -> dict:
        ok, detail = self.integrity.restore(path)
        return {"ok": ok, "detail": detail}

    def do_integrity(self) -> dict:
        backups = []
        if os.path.isdir(self.integrity.backup_dir):
            backups = sorted(os.listdir(self.integrity.backup_dir))[-20:]
        return {**self.integrity.snapshot(), "recent_backups": backups}

    def do_isolate(self, address: str, ttl: float = 3600.0, reason: str = "operator command") -> dict:
        incident = self.isolate(address, ttl=ttl, reason=reason)
        return {"incident": incident, "isolated": sorted(self.isolated_nodes)}

    def do_release_node(self, address: str) -> dict:
        return {"was_isolated": self.release_node(address), "isolated": sorted(self.isolated_nodes)}

    def do_rollback(self, incident: int | None = None) -> dict:
        """Undo reversible actions, newest first: unblock, return quarantined files."""
        actions = self.audit.recent_actions(limit=200)
        if incident is not None:
            actions = [action for action in actions if action["incident_id"] == incident]
        undone = []
        for action in actions:
            if not action["ok"] or action["rolled_back"]:
                continue
            undo = action["undo"] or {}
            kind = undo.get("kind")
            if kind == "unblock":
                ok, detail = self.firewall.release((undo["direction"], normalize(undo["address"])))
                undone.append({"action": action["id"], "kind": kind, "ok": ok, "detail": detail})
                if ok:
                    self.audit.mark_rolled_back(action["id"])
            elif kind == "restore_file":
                try:
                    shutil.move(undo["from"], undo["to"])
                    self.audit.mark_rolled_back(action["id"])
                    undone.append({"action": action["id"], "kind": kind, "ok": True, "detail": undo["to"]})
                except (OSError, KeyError, TypeError) as exc:
                    undone.append({"action": action["id"], "kind": kind, "ok": False, "detail": str(exc)})
        return {"rolled_back": undone}

    def do_stats(self) -> dict:
        return self.audit.stats()

    def do_flush(self) -> dict:
        """Emergency exit: remove every rule this agent installed."""
        return self.firewall.teardown()


def _load_key(path: str) -> bytes:
    if not os.path.exists(path):
        secret = os.urandom(32)
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descriptor, "wb") as fh:
            fh.write(secret)
        return secret
    with open(path, "rb") as fh:
        return fh.read().strip()


def _read_json(connection: socket.socket) -> dict | None:
    buffer = b""
    while b"\n" not in buffer:
        try:
            chunk = connection.recv(4096)
        except OSError:
            return None
        if not chunk:
            return None
        buffer += chunk
        if len(buffer) > 65536:
            return None
    try:
        return json.loads(buffer.split(b"\n", 1)[0].decode())
    except json.JSONDecodeError:
        return None
