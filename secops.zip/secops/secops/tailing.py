"""Follow a log file the way `tail -F` does, including rotation.

Detection reads the same audit trail a human operator would, so its decisions
can be checked line by line.
"""

from __future__ import annotations

import os
import threading
import time

CHECK_INTERVAL = 0.3
MAX_LINE = 8192


class FileFollower:
    def __init__(self, path: str, on_line, from_start: bool = False) -> None:
        self.path = path
        self.on_line = on_line
        self.from_start = from_start
        self._offset = 0
        self._inode: int | None = None
        self.handle = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.skipped_bytes = 0
        self._opened_once = False
        self._existed_at_start = False

    def start(self) -> None:
        # A log that already exists opens at EOF so old events are not re-lived;
        # one that appears afterwards is read from the top, because its very first
        # lines are the evidence we have been waiting for.
        self._existed_at_start = os.path.exists(self.path)
        self._thread = threading.Thread(target=self._run, name=f"follow:{os.path.basename(self.path)}", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)

    def _open(self):
        try:
            stat = os.stat(self.path)
        except OSError:
            return None
        if self._inode != stat.st_ino:
            self._inode = stat.st_ino
            history = self._existed_at_start and not self._opened_once and not self.from_start
            self._offset = stat.st_size if history else 0
        handle = open(self.path, "r", encoding="utf-8", errors="replace")
        handle.seek(self._offset)
        self._opened_once = True
        return handle

    def _run(self) -> None:
        try:
            while not self._stop.wait(CHECK_INTERVAL):
                if self.handle is None:
                    self.handle = self._open()
                    if self.handle is None:
                        continue
                try:
                    lines = self.handle.readlines()
                except (OSError, UnicodeError):
                    self._close()
                    continue
                if not lines:
                    stat = self._stat()
                    if stat is None or stat.st_ino != self._inode or stat.st_size < self._offset:
                        # Rotated or truncated: reopen and follow the new inode.
                        self._close()
                    continue
                for raw in lines:
                    line = raw.rstrip("\n")
                    if len(line) > MAX_LINE:
                        self.skipped_bytes += len(line) - MAX_LINE
                        line = line[:MAX_LINE]
                    if line:
                        self.on_line(line)
                self._offset = self.handle.tell()
        finally:
            self._close()

    def _close(self) -> None:
        if self.handle is not None:
            try:
                self.handle.close()
            except OSError:
                pass
            self.handle = None

    def _stat(self):
        try:
            return os.stat(self.path)
        except OSError:
            return None

    def close(self) -> None:
        self.stop()


class Poller(threading.Thread):
    """Fixed-cadence sampler used by the process and connection watchers."""

    def __init__(self, interval: float, tick, name: str = "poller") -> None:
        super().__init__(name=name, daemon=True)
        self.interval = interval
        self.tick = tick
        self._stop = threading.Event()
        self.errors: list[str] = []
        self.cycles = 0

    def stop(self) -> None:
        self._stop.set()

    def run(self) -> None:
        while not self._stop.wait(self.interval):
            started = time.monotonic()
            try:
                self.tick()
            except Exception as exc:  # a watcher must never take the agent down
                self.errors.append(f"{type(exc).__name__}: {exc}"[:200])
                del self.errors[:-20]
            self.cycles += 1
            elapsed = time.monotonic() - started
            if elapsed > self.interval:
                self._stop.wait(min(elapsed, 5.0) - self.interval)
