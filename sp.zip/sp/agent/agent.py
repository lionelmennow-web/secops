import logging
import threading
import time
from config import NODE_NAME, REVSHELL_SCAN_INTERVAL
import detectors, responder, swarm, forensics

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
log = logging.getLogger("agent")

seen_blocks = set()

def on_peer_signal(sig):
    """Apply a block announced by another node."""
    if sig.get("type") == "block" and sig.get("ip") not in seen_blocks:
        seen_blocks.add(sig["ip"])
        responder.block_ip(sig["ip"], f"peer {sig.get('node')}: {sig.get('sig')}")
        forensics.log_threat({**sig, "action": "received_block"})

def handle_ssh_bruteforce(ip):
    if ip in seen_blocks:
        return
    seen_blocks.add(ip)
    responder.block_ip(ip, "ssh brute force")
    swarm.broadcast({"type": "block", "ip": ip, "sig": "ssh-bruteforce"})
    forensics.log_threat({"type": "ssh-bruteforce", "ip": ip, "node": NODE_NAME})

def handle_reverse_shell(conn):
    key = f"{conn['remote_ip']}:{conn['remote_port']}"
    if key in seen_blocks:
        return
    seen_blocks.add(key)
    log.warning("reverse shell detected: %s", conn)

    evidence = forensics.collect(conn["remote_ip"], pid=conn["pid"])
    responder.kill_connection(conn["remote_ip"], conn["remote_port"])
    responder.kill_pid(conn["pid"])
    responder.block_ip(conn["remote_ip"], "reverse shell")
    flagged = responder.rollback_persistence()

    event = {"type": "reverse-shell", "node": NODE_NAME, "conn": conn,
             "evidence": evidence, "flagged_persistence": flagged}
    forensics.log_threat(event)
    swarm.broadcast({"type": "block", "ip": conn["remote_ip"], "sig": "reverse-shell"})

def shell_watch_loop():
    while True:
        for conn in detectors.find_reverse_shells():
            handle_reverse_shell(conn)
        time.sleep(REVSHELL_SCAN_INTERVAL)

def main():
    responder.setup_table()
    swarm.start_listener(on_peer_signal)
    threading.Thread(target=shell_watch_loop, daemon=True).start()
    log.info("%s online", NODE_NAME)
    for ip in detectors.ssh_bruteforce_events():
        handle_ssh_bruteforce(ip)

if __name__ == "__main__":
    main()
