import os

SWARM_PORT = 9999
BROADCAST_ADDR = "255.255.255.255"
AUTH_LOG = "/var/log/auth.log"
THREAT_LOG = os.path.join(os.path.dirname(__file__), "..", "logs", "threats.jsonl")
NODE_NAME = os.environ.get("NODE_NAME", "node-1")

SSH_FAIL_THRESHOLD = 5        # failed attempts from one IP
SSH_FAIL_WINDOW = 60          # seconds
REVSHELL_SCAN_INTERVAL = 3    # seconds between process/socket scans
BLOCK_TTL = 3600              # seconds a block stays active
