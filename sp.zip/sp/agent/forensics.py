import json
import os
import subprocess
import time
from config import THREAT_LOG

def collect(remote_ip, pid=None):
    """Gather what we can about the attacker from our side of the link."""
    info = {"remote_ip": remote_ip, "collected_at": time.time()}
    try:
        info["whois"] = subprocess.run(
            ["whois", remote_ip], capture_output=True, text=True, timeout=10
        ).stdout[:2000]
    except Exception as e:
        info["whois_error"] = str(e)
    if pid:
        try:
            info["proc_exe"] = os.readlink(f"/proc/{pid}/exe")
            info["proc_cwd"] = os.readlink(f"/proc/{pid}/cwd")
        except OSError:
            pass
    return info

def log_threat(event: dict):
    os.makedirs(os.path.dirname(THREAT_LOG), exist_ok=True)
    event["logged_at"] = time.time()
    with open(THREAT_LOG, "a") as f:
        f.write(json.dumps(event) + "\n")
