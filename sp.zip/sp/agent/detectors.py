import re
import time
from collections import defaultdict, deque
from config import AUTH_LOG, SSH_FAIL_THRESHOLD, SSH_FAIL_WINDOW

FAIL_RE = re.compile(r"Failed password .* from (\d+\.\d+\.\d+\.\d+)")

def tail(path):
    """Yield new lines appended to a file."""
    with open(path, "r") as f:
        f.seek(0, 2)
        while True:
            line = f.readline()
            if not line:
                time.sleep(0.5)
                continue
            yield line

def ssh_bruteforce_events():
    """Yield IPs that exceed the failed-login threshold in the time window."""
    hits = defaultdict(deque)
    for line in tail(AUTH_LOG):
        m = FAIL_RE.search(line)
        if not m:
            continue
        ip, now = m.group(1), time.time()
        q = hits[ip]
        q.append(now)
        while q and now - q[0] > SSH_FAIL_WINDOW:
            q.popleft()
        if len(q) >= SSH_FAIL_THRESHOLD:
            yield ip
            q.clear()

SUSPICIOUS_PARENTS = {"sshd", "bash", "sh", "nc", "ncat"}
REVSHELL_CMDS = ("/bin/sh", "/bin/bash", "nc ", "ncat", "python -c", "socat")

def find_reverse_shells():
    """Find processes with an outbound established connection whose
    command looks like a shell, pointed at a remote IP. Uses psutil."""
    import psutil
    results = []
    for proc in psutil.process_iter(["pid", "name", "cmdline", "ppid"]):
        try:
            cmd = " ".join(proc.info["cmdline"] or [])
            if not any(c in cmd for c in REVSHELL_CMDS):
                continue
            for conn in proc.net_connections(kind="inet"):
                if conn.status == "ESTABLISHED" and conn.raddr:
                    results.append({
                        "pid": proc.info["pid"],
                        "cmd": cmd,
                        "ppid": proc.info["ppid"],
                        "remote_ip": conn.raddr.ip,
                        "remote_port": conn.raddr.port,
                        "local_port": conn.laddr.port,
                    })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return results
