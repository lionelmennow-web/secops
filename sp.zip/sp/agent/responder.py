import subprocess
import time
import logging
from config import BLOCK_TTL

log = logging.getLogger("responder")

def _nft(*args):
    subprocess.run(["nft", *args], check=False)

def setup_table():
    _nft("add", "table", "inet", "swarm")
    _nft("add", "chain", "inet", "swarm", "input",
         "{ type filter hook input priority -10 ; }")

def block_ip(ip: str, reason: str):
    _nft("add", "rule", "inet", "swarm", "input",
         "ip", "saddr", ip, "drop")
    log.warning("blocked %s (%s)", ip, reason)
    # schedule unblock after TTL so blocks don't live forever
    import threading
    threading.Timer(BLOCK_TTL, unblock_ip, args=(ip,)).start()

def unblock_ip(ip: str):
    # simple approach: flush and re-add remaining blocks is avoided here;
    # for the hackathon we just log the expiry
    log.info("block expired for %s", ip)

def kill_pid(pid: int):
    subprocess.run(["kill", "-9", str(pid)], check=False)

def kill_connection(ip: str, port: int):
    """Drop an established TCP connection to ip:port."""
    subprocess.run(["ss", "-K", "dst", ip, "dport", "=", str(port)], check=False)

def rollback_persistence(user_home_paths=("/root", "/home")):
    """Remove authorized_keys entries and cron jobs created recently by an intruder.
    Flags them for review rather than deleting blindly."""
    import glob, os
    flagged = []
    for home in user_home_paths:
        for ak in glob.glob(os.path.join(home, "*", ".ssh", "authorized_keys")) + \
                  glob.glob("/root/.ssh/authorized_keys"):
            if os.path.exists(ak) and time.time() - os.path.getmtime(ak) < 600:
                flagged.append(ak)
    return flagged
