import json
import socket
import threading
from config import SWARM_PORT, BROADCAST_ADDR, NODE_NAME

def broadcast(signal: dict):
    """Send a threat signal to all peers on the LAN."""
    msg = json.dumps({"node": NODE_NAME, **signal}).encode()
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.sendto(msg, (BROADCAST_ADDR, SWARM_PORT))

def listen(on_signal):
    """Receive signals from peers and hand them to on_signal."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("", SWARM_PORT))
    while True:
        data, _ = s.recvfrom(4096)
        try:
            sig = json.loads(data.decode())
            if sig.get("node") != NODE_NAME:   # ignore our own echoes
                on_signal(sig)
        except (ValueError, UnicodeDecodeError):
            pass

def start_listener(on_signal):
    threading.Thread(target=listen, args=(on_signal,), daemon=True).start()
